var ThemeVar='e'; // переменная темы (e-'entels', i-'incotex')

var starttxt='';

var data30_with_K = [];
var data30_origin = [];

var GetMetro=false;
var req;
var NumDT=0;
var TUName;
var TUSerial;
var KTT;
var KTN;
var TUTipe;
var NM=6;
var NumTU;
var TUUpdate=5;
var Timer=0;
var TypePoll=0; // 0-Polling; 2-HistPage
var GlobPage=1;
var CntInPage = 25;
var UploadFile=null;
var NumLocalVars; // число элементов вообще
var ftmr=-1;
var w_tmr_arr=[];
var w_tmr=-1,w_ttmr=-1,w_tmr2, b_tmr=-1;
var l_tm=-1;
var d_m = []; // график исторический
var plot;
var overview;
var bFirstHistView=true;
var bFstGlob=true;
var updateLegendTimeout = null;
var latestPosition = null;
var legends;
var ig = 0;
var choiceContainer;
var bFileAPISupport = !!(window.File && window.FileReader && window.FileList && window.Blob);
var bCanvasSupport = !!document.createElement('canvas').getContext;	
var GlobTab=1;
var TablMin=-1;
var TablMax=-1;
var bFirstGr=false;//true;
var GetTableStrMode=0; // 0-любая, 1-для глобальных переменных
var bFl=true;
var bReadCntInfo = true;
$$$ = function(id) { return document.getElementById(id); }
var options30 = {
	legend: {container: $("#legend30")},
	xaxis: { mode: "time", tickLength: 5, timeformat:"%y/%m/%d %H/%M/%S"},
	selection: { mode: "x" },
	crosshair: { mode: "x" },
	grid: { markings: weekendAreas, hoverable: true, autoHighlight: false }
};
var glob_options = {
	legend: {container: $("#glob_legend")},
	xaxis: { mode: "time", tickLength: 5, timeformat:"%y/%m/%d %H/%M/%S"},
	selection: { mode: "x" },
	crosshair: { mode: "x" },
	grid: { markings: weekendAreas, hoverable: true, autoHighlight: false }
};

var wb='50px';
var Psw;
var PswLvl=1;
var AccMsg='';

var bEmul=false;
var SrN='';
var RC='';
var ChKoef = false;
var bShowInputFm=false;
var izm_data, diag_data1;
var PswStr="";
var MsgPsw="";
var bNoEditP6;
var bNext=false;

function Themer(name){
         if(name=='entels') {
                $.cookie('themes','entels');
                $('#themes').attr('href','css/entels/jquery.css');
				$$$('header').style.backgroundImage = "url(css/img/logo_entels.jpg)";
        } else if(name=='incotex') {
                $.cookie('themes','incotex');
                $('#themes').attr('href','css/incotex/jquery.css');
				$$$('header').style.backgroundImage = "url(css/img/logo_incotex.jpg)";
        }
        var sco = $.cookie('themes') || 'entels';
        $('#themes').attr('href','css/'+sco+'/jquery.css');  
}

function TrimStr(s) {
  s = s.replace( /^\s+/g, '');
  return s.replace( /\s+$/g, '');
}

String.prototype.trimLeft=function()
// убирает все пробелы в начале строки
{
  var r=/^\s+/g;
  return this.replace(r,'');
}

function AdmTabSelectTU(V)
{
	d_m=[];
	bFirstHistView=true;
	NumDT = V;
	AsyncRequest();
}

function SetUSPDTxt(txt)
{
	if (ThemeVar=='e')
		txt = txt.replace(/\[USPD\]/g, "УСПД \"ЭНТЕК 323\"");
	else
		txt = txt.replace(/\[USPD\]/g, "УСПД \"Меркурий-250\"");
	return txt;
}


function GetTrueNum(Num)
{	
	if (Num<10)return ('0'+Num)
		else return Num;
};
function ShowNumPage(V)
{
	Timer=0;
	if (ftmr>=0)
	{
		window.clearTimeout(ftmr);
		ftmr = -1;
	}
	
	if (V!=6)	document.getElementById("Data_obl").style.margin = "0px";
		else	document.getElementById("Data_obl").style.margin = "10px";
	
	switch (V){
		case 0: var tmp_b = (PswLvl<3);
				if (tmp_b)
				{
					$$$('Data_obl').innerHTML = "<p class='ui-widget-header add_zx' style='padding:10px'>Сетевые настройки</p>"+Cntrlr;
					$$$('setnetbtn').style.visibility="hidden";
				}
					else
				{
					$$$('Data_obl').innerHTML = DevSetsPage;
					$$$('setnetbtn').style.visibility="visible";
				}
				$$$('Adr_IP').disabled = tmp_b;
				$$$('Adr_Mask').disabled = tmp_b;
				$$$('Web_Port').disabled = tmp_b;
				if (tmp_b)
					NumDT=10;
				else
					NumDT=27;
				SetWTm(2,1);
				break;
		case 1: $$$('Data_obl').innerHTML = TUPage;
				$$$('TUName').innerHTML   = TUName;
				$$$('TUSerial').innerHTML = TUSerial;
				$$$('TUKTT').innerHTML = TUKTT;
				$$$('TUKTN').innerHTML = TUKTN;

				jQuery("#diag_tb1").jqGrid({
					cmTemplate:{sortable:false, align:"center"},
					datatype: "local",
					height: "100%",
					data: [],
					colNames:['','I, А','U, В','COS','P, кВт','Q, кВАр','S, кВА'],
					colModel:[
						{name:'V',index:'V', width:30},
						{name:'I',index:'I', width:70},
						{name:'U',index:'U', width:55},
						{name:'C',index:'C', width:45},
						{name:'P',index:'P', width:70},
						{name:'Q',index:'Q', width:55},
						{name:'S',index:'S', width:70}
					]
				});
				/*jQuery("#diag_tb2").jqGrid({
					cmTemplate:{sortable:false, align:"center"},
					datatype: "local",
					height: "100%",
					data: [],
					colNames:['Вид энергии','Текущие','На начало месяца'],
					colModel:[
						{name:'En',index:'En', width:160, align:'left'},
						{name:'Tek',index:'Tek', width:110},
						{name:'BM',index:'BM', width:130}
					]
				});*/
				jQuery("#izm_tb").jqGrid({
					cmTemplate:{sortable:false, align:"center"},
					datatype: "local",
					height: 590,					
					data: [],
					colNames:['Параметр','Значение','Временная метка'],
					colModel:[
						{name:'P',index:'P', width:150, align:'left'},
						{name:'V',index:'V', width:120},
						{name:'T',index:'T', width:170}
					]
				});
				jQuery("#en_tb").jqGrid({
					cmTemplate:{sortable:false, align:"center"},
					datatype: "local",
					height: 586,
					data: [],
					colNames:['Параметр','Суммарный тариф','Тариф 1','Тариф 2','Тариф 3','Тариф 4','Временная метка'],
					colModel:[
						{name:'P',index:'P', width:170, align:'left'},
						{name:'ST',index:'ST', width:120},
						{name:'T1',index:'T1', width:95},
						{name:'T2',index:'T2', width:95},
						{name:'T3',index:'T3', width:95},
						{name:'T4',index:'T4', width:95},
						{name:'T',index:'T', width:150}
					]
				});
				
				if (!bCanvasSupport) $$$('canvas').style.height='0px';
				SetTabs("#TU_tabs");
				//SetBtns("#TU_tabs");
				if ((NumDT==0) || (NumDT==3) || (NumDT==100))
					NumDT = 5;
				SetWTm(8,1);
				break;
		case 2: ftmr = window.setInterval("tm()",1000);				
				if (V!=NM)
				{
					bFirstGr=true;
					bFstGlob=true;
					NumDT=3;
					NumLocalVars = 0;
					$$$('Data_obl').innerHTML=GlobTabs;
					glob_d_m=[];
				}
				SetWTm(4,0);
				break;				
		case 5: $$$('Data_obl').innerHTML = "<table id='TU_tb' style='font-size:120%'></table><div id='TU_nav'></div>";
				SetWTm(6,1);
				NumDT=0;
				break;
		case 6: if (ThemeVar=='e')
					$$$('Data_obl').innerHTML = SetUSPDTxt(Page6_0);
				else
					$$$('Data_obl').innerHTML = SetUSPDTxt(Page6);
				$$$('vers_p').innerHTML = $$$('CntrlrVersion').innerHTML;
				V=27; // получение информации о контроллере
				NumDT=V;
				bNoEditP6=true;
				bGetMetro=true;
				break;
		// Об КСТМ
		case 7: $$$('Data_obl').innerHTML = SetUSPDTxt("<div class='ui-tabs ui-widget ui-widget-content ui-corner-all' id='pribor_tabs'><ul><li><a href='#tb-1'>Об КСТМ</a></li><li><a href='#tb-2'>Модули ввода-вывода</a></li><li><a href='#tb-3'>Модули РЗА</a></li></ul><div id='tb-1' class='ui-widget-content' style='padding:5px'>"+kstminfo+"</div><div id='tb-2' class='ui-widget-content' style='padding:5px'>"+moduloweninfo+"</div><div id='tb-3' class='ui-widget-content' style='padding:5px'>"+rzainfo+"</div>");
				SetWTm(12,1);	
				break;
		case 10: $$$('Data_obl').innerHTML = SetUSPDTxt(moduloweninfo);
				break;
		case 11: $$$('Data_obl').innerHTML = SetUSPDTxt(rzainfo);
				break;
		case 12: $$$('Data_obl').innerHTML = '';
				break;
		case 13: $$$('Data_obl').innerHTML = '';
				break;
		case 14: $$$('Data_obl').innerHTML = '';
				break;
		case 15: var S='';
				S = "<div class='ui-tabs ui-widget ui-widget-content ui-corner-all' id='pribor_tabs'><ul><li><a href='#tb-1'>Информация</a></li><li><a href='#tb-2'>Приборы учета</a></li>"+//<li><a href='#tb-3'>Технология PLC-I</a></li>
				"<li><a href='#tb-3'>Технология PLC-II</a></li></ul><div id='tb-1' class='ui-widget-content' style='padding:5px'>";
				S = S + rtuinfo;
				$$$('Data_obl').innerHTML = SetUSPDTxt(S +"</div><div id='tb-2' class='ui-widget-content' style='padding:5px'>"+countinfo+"</div>"+//<div id='tb-3' class='ui-widget-content' style='padding:5px'>"+plcI+"</div>
				"<div id='tb-3' class='ui-widget-content' style='padding:5px'>"+plcII+"</div></div>");
				SetWTm(12,1);
				break;
	}
	if (V!=null) NM = V;
	if ((V!=3)&&((V<7)||(V>15))) 
		AsyncRequest();
};

function AsyncRequest()
{
	Timer=0;
	req = new XMLHttpRequest();
	if (!bEmul)
		req.onreadystatechange = showAsyncRequestComplete;
	var ReqStr='index.cgi?DT='+NumDT+'&LVL='+PswLvl+'&PSW=';
	if (Psw=="") ReqStr+='0';
			else ReqStr+=Psw;
	switch (NumDT)
	{
		case 11:
			ReqStr=ReqStr+'&New_IP='+$$$('Adr_IP').value+'&New_Mask='+$$$('Adr_Mask').value+'&WPrt='+$$$('Web_Port').value;
			break;
		case 3:// глобальный массив
			if (GlobTab==2) ReqStr=ReqStr+'&LP=0'
				else ReqStr=ReqStr+'&LP='+GlobPage;
			ReqStr=ReqStr+'&CntP='+CntInPage;
			if (glob_d_m.length>0) { // запрос данных для оперативных трендов
				for (i=0; i<glob_d_m.length;i++){
					var val=glob_d_m[i].mylabel;
					var SP=GlobPage*CntInPage;
					if ((GlobTab==2)||(val<=SP)||((SP+CntInPage)<val)) // вне пределов без того запрашиваемого дипазона ?
						ReqStr=ReqStr+'&DM'+i+'='+glob_d_m[i].mylabel;
				}
				ReqStr=ReqStr+'&DL='+glob_d_m.length;
			}
			break;
		case 4:
			window.clearTimeout(ftmr);
			ftmr = -1;
			$$$('ChKoef').parentNode.style.visibility="visible";
			$$$('scrl_upd').innerHTML = "<button id='ref_btn30' style='position:absolute;top:-5px;left:155px' onclick='AdmTabSelectTU(4)'>Запросить</button>";
			var DTime = $$$('sdate').value;
			var D1=DTime.split('.');
			DTime = $$$('stime').value;
			var T1=DTime.split(':');
			DTime = $$$('edate').value;
			var D2=DTime.split('.');
			DTime = $$$('etime').value;
			var T2=DTime.split(':');
			var ReqStr=ReqStr+'&SN='+TUSerial+
					'&Y1='+D1[0]+'&M1='+D1[1]+'&D1='+D1[2]+'&H1='+T1[0]+'&Mn1='+T1[1]+'&S1='+T1[2]+
					'&Y2='+D2[0]+'&M2='+D2[1]+'&D2='+D2[2]+'&H2='+T2[0]+'&Mn2='+T2[1]+'&S1='+T2[2];
			SetWTm(1,1);
			break;
		case 1: case 2: case 5:
			if (ftmr<0)
				ftmr = window.setInterval("tm()",1000);
			if ((NumDT==2) || (NumDT==5))
				$$$('ChKoef').parentNode.style.visibility="hidden";
			else
				$$$('ChKoef').parentNode.style.visibility="visible";

			/*var S="Период обновления  <select id='TUUpdate' onChange='TUUpdate = value'><option value='0'";
			if (TUUpdate==0) S+= " selected='selected'";
			S+=">Нет обновления</option><option value='1'";
			if (TUUpdate==1) S+= " selected='selected'";
			S+=">1 секунду</option><option value='3'";
			if (TUUpdate==3) S+= " selected='selected'";
			S+=">3 секунд</option><option value='5'";
			if (TUUpdate==5) S+= " selected='selected'";
			S+=">5 секунд</option><option value='10'";
			if (TUUpdate==10) S+= " selected='selected'";
			S+=">10 секунд</option><option value='15'";
			if (TUUpdate==15) S+= " selected='selected'";
			S+">15 секунд</option><option value='30'";
			if (TUUpdate==30) S+= " selected='selected'";
			S+">30 секунд</option><option value='60'";
			if (TUUpdate==60) S+= " selected='selected'";
			S+">1 минуту</option><option value='300'";
			if (TUUpdate==300) S+= " selected='selected'";
			S+">5 минут</option><option value='600'";
			if (TUUpdate==600) S+= " selected='selected'";
			S+">10 минут</option><option value='900'";
			if (TUUpdate==900) S+= " selected='selected'";
			S+">15 минут</option><option value='1200'";
			if (TUUpdate==1200) S+= " selected='selected'";
			S+">30 минут</option><option value='2400'"
			if (TUUpdate==2400) S+= " selected='selected'";
			S+">1 час</option></select>";*/			
			
			$$$('scrl_upd').innerHTML = '';//S;
			ReqStr=ReqStr+'&TU='+NumTU;
			break;
		case 17:
			ReqStr=ReqStr+'&SN='+TUSerial;
			break;
		case 22:
			ReqStr=ReqStr+'&SrN='+SrN.replace(/-/g, "");
			break;
		case 23:
			ReqStr=ReqStr+'&RC='+RC.replace(/-/g, "");
			break;
		case 26:			
			ReqStr=ReqStr+PswStr;
			break;
		case 28:// Установить информацию о контроллере
			ReqStr=ReqStr+'&DInf='+$$$('DateInf').value+'&NInf='+$$$('NameInf').value+'&AInf='+$$$('AdresInf').value+'&LInf='+$$$('LocationInf').value+'&PInf='+$$$('PersonInf').value+'&CInf='+$$$('ContactInf').value+'&KInf='+$$$('KodInf').value;
			break;
		case 30:// Установить поверочную информацию
			ReqStr=ReqStr+'&DICal='+$$$('DateIssueCal').value+'&DCCal='+$$$('DateCheckingCal').value+'&DNCal='+$$$('DateNextCheckCal').value;
			break;
		case 128:
			showForm('FloatForm','Контроллер отправлен на перезагрузку<br>Через 60 секунд он полностью перезагрузится<br>','OK','');
			if (ftmr>=0)
			{
				window.clearTimeout(ftmr);
				ftmr = -1;
			}
			break;
	}
	req.open('GET', ReqStr, true);
	ShowWait();
	if (bEmul) {
	  SetWTm(2,1);
	  showAsyncRequestComplete();
	}
		else req.send(null);
}


function CheckPswNum(numpsw)
{
	if ($$$('accs_psw'+numpsw).value == $$$('conf_psw'+numpsw).value)
	{
		if ($$$('accs_psw'+numpsw).value!="")
			PswStr=PswStr+'&psw'+numpsw+'='+MD5_hexhash($$$('accs_psw'+numpsw).value);
		else
			PswStr=PswStr+'&psw'+numpsw+'=0';
	}
	else
		MsgPsw=MsgPsw+'Пароль '+numpsw+': Пароль не совпадает с подтверждением пароля<br>';
}

function SetPassword(SetPswLvl)
{
	PswStr="";
	MsgPsw="";
	CheckPswNum(SetPswLvl);
	if (MsgPsw=="")
	{	
		MsgPsw='Контроллер отправлен на перезагрузку<br>Пароли вступят в силу через 60 секунд<br>';
		NumDT=26;
		AsyncRequest();
		ShowPswDlg();
	};
	
	showForm('FloatForm',MsgPsw,'OK','');
	
}

function weekendAreas(axes) {
	var markings = [];
	var d = new Date(axes.xaxis.min);
	d.setUTCDate(d.getUTCDate() - ((d.getUTCDay() + 1) % 7))
	d.setUTCSeconds(0);
	d.setUTCMinutes(0);
	d.setUTCHours(0);
	var i = d.getTime();
	do {
		markings.push({ xaxis: { from: i, to: i + 2 * 24 * 60 * 60 * 1000 } });
		i += 7 * 24 * 60 * 60 * 1000;
	} while (i < axes.xaxis.max);
	return markings;
}

function obr(a,b) 
{
	if(a[0] > b[0]) return 1;
	if(a[0] ==b[0]) return 0;
	if(a[0] < b[0]) return -1;
}

function redraw(dm) {
	var dt = [];
	for(var j = 0; j < dm.length; ++j){
		dt.push(dm[j]);
		var l=dt.length-1;
		if (dm.length>0){
			// скрываем ?
			if(dm[j].hide)	dt[l].data=[];
					else 	dt[l].data = dt[l].data_ext;
		}
	}
	$.plot($("#glob_gr"), dt, glob_options);
	LegendInit(dt);
}

function updateLegend() {
	updateLegendTimeout = null;
	var pos = latestPosition;
	if (pos){
		//var axes = plot.getAxes();
		//if (pos.x < axes.xaxis.min || pos.x > axes.xaxis.max ||
		//	pos.y < axes.yaxis.min || pos.y > axes.yaxis.max)
		//	return;

		var i, j, dataset = plot.getData();
		for (i = 0; i < dataset.length; ++i) {
			var series = dataset[i];
			for (j = 0; j < series.data.length; ++j)
				if (series.data[j][0] > pos.x)
					break;
			var y, p1 = series.data[j - 1], p2 = series.data[j];
			if (p1 == null)
				y = p2[1];
			else y = p1[1];
			legends.eq(i).text(series.label.replace(/=.*/, '= ' + y));
		}
	}
}

function LegendInit(dm){
	legends = $("#glob_legend .legendLabel");
	var i,j;
	var b=false;
	var Data=[];
	for (i=0;i<dm.length;i++)
		for (j=0;j<dm[i].data.length;j++)
			if (dm[i].lines.show){
				b=true;
				Data.push(dm[i].mylabel);
				Data.push(dm[i].DataTab[j]);
				Data.push(dm[i].data[j][1]);
			}
			
	// рисуем чекбоксы в легенде
	var legend = document.getElementById('glob_legend'); // еще IE не умеет заменять innerHTML в table
	var legend_tbl = legend.getElementsByTagName('table')[0];
	if (legend_tbl){
		var legend_html = '<table style="font-size: smaller; color: rgb(84, 84, 84);"><tbody>';
		for(var i = 0; i < legend_tbl.rows.length; i++) {
			var h='';
			if (!dm[i].hide) h='checked';
			legend_html += '<tr>' +
				'<td><input type="checkbox" onclick="glob_d_m['+ i +'].hide=!glob_d_m['+ i +'].hide;redraw(glob_d_m);"'+h+'></td>'
				+ legend_tbl.rows[i].innerHTML
				+ '</tr>';
		}
		legend_html += "</tbody></table>";
		legend.innerHTML = legend_html;
	}
	updateLegend();
}

function plotAccordingToChoices(dm) {
	for (i=0;i<dm.length;i++)
		dm[i].lines.show=false;
	choiceContainer.find("input:checked").each(function () {
		var key = $(this).attr("name");
		if (key && dm[key])
			dm[key].lines.show=true;
	});
	plot.setData(dm);
	plot.setupGrid();
	redraw(dm);
	LegendInit(dm);
}

function SetValsData(Datas,Num){
	var D, DType=Datas[Num+2],Vl=Datas[Num+3];
	switch (DType){
		case '0': D = 'Float';
				  Vl = Vl.trimLeft();
				  break;
		case '1': D = 'Boolean';
				  if (Vl!='0') Vl='True';
						  else Vl='False';
				  break;
		case '2': D = 'Integer';break;
		case '3': D = 'Unknow';	break;
		case '4': D = 'DateTime';break;
		case '5': D = 'IP Addr';break;
		case '6': D = 'String';	break;
		case '7': D = 'Variant';break;
	};
	jQuery("#loc_tb").jqGrid('setRowData',parseInt(Datas[Num]),{id:Datas[Num],mek_addr:Datas[Num+1],type_val:D,value:Vl,quality:Datas[Num+4],dtime:Datas[Num+5]});
}

function StoN(str,K,ChK,kilo)
{
	if (K==0) K=1;
	StoN.Res = parseFloat(str);
	if (isNaN(StoN.Res))
		StoN.Res = str;
	else
	{
		if (!ChK)
			StoN.Res = StoN.Res/K;
		StoN.Res = StoN.Res*kilo;
		var str2 = str.split('.');
		if ((str2.length == 2) && (StoN.Res != 0))
		{
			if (kilo) 	StoN.Res = StoN.Res.toFixed(2)
				else	StoN.Res = StoN.Res.toFixed(str2[1].length)
		}
		else
			StoN.Res = StoN.Res.toFixed(0)
	}
}

function AddArr30()
{	
	ChKoef = $$$("ChKoef").checked;
	
	// диаграмма
	if (diag_data1!=undefined)
		FillingJQGrid('#diag_tb1',diag_data1,7);
	
	//измерения
	if (izm_data!=undefined)
		FillingJQGrid('#izm_tb',izm_data,3);
	
	// получасовки
	if (data30_origin.length>0)
	{
		$("#Tb30").jqGrid('GridDestroy');
		$$$('table30').innerHTML = "<table id='Tb30' style='font-size:120%'></table>";
				
		// таблица получасовок
		jQuery("#Tb30").jqGrid({
			cmTemplate:{sortable:false,align:"center"},
			datatype: "local",
			height: 540,
			data: [],
			colNames:['Временная метка','А+, кВт','А-, кВт','R+, кВАр','R-, кВАр'],
			colModel:[
				{name:'Time30',index:'Time30', width:150},
				{name:'Ap30',index:'Ap30', width:100},
				{name:'Am30',index:'Am30', width:100},
				{name:'Rp30',index:'Rp30', width:100},
				{name:'Rm30',index:'Rm30', width:100},
			],
			recordtext: "Всего получасовок: {2}",
			viewrecords: true,
			hidegrid:false,
			rowNum:1000,
			altRows: true
		});
		var i30;
		for (i30=0; i30<data30_origin.length; i30++)
			if (ChKoef) jQuery("#Tb30").jqGrid('addRowData',i30,data30_with_K[i30])
				else	jQuery("#Tb30").jqGrid('addRowData',i30,data30_origin[i30]);
		SetWTm(15,1);
	}
}

function FillingJQGrid(NameTab,Datas,C){
	var Data=Datas.split(',');
	var NumRows = Math.round(Data.length/C);
	var Cnt = jQuery(NameTab).jqGrid('getGridParam','records');
	var i=0;
	for (; i<NumRows; i++){
		var row;
		Data[i*C] = Data[i*C].replace(/[@]/g,",");
		var Name = Data[i*C].split(',');
		switch (NameTab){
			case '#diag_tb1':				
				row = {V:Data[i*C], I:Data[i*C+1], U:Data[i*C+2], C:Data[i*C+3], P:Data[i*C+4], Q:Data[i*C+5], S:Data[i*C+6]};
				if (row.I!="&nbsp")
					row.I = parseFloat(row.I).toFixed(1);
				row.U = parseFloat(row.U).toFixed(1);
				row.P = (parseFloat(row.P)/1000).toFixed(1);
				row.Q = (parseFloat(row.Q)/1000).toFixed(1);
				row.S = (parseFloat(row.S)/1000).toFixed(1);
				break;
			case '#diag_tb2': 
				row = {En:Data[i*C], Tek:Data[i*C+1], BM:Data[i*C+2]};
				break;
			case '#izm_tb': 
				if ((i>=4) && (i<=15))
				{
					if (ChKoef) 
					{
						if ((i>=4) && (i<=7)) Name[1]='кВт';
						if ((i>=8) && (i<=11)) Name[1]='кВАр';
						if ((i>=12) && (i<=15)) Name[1]='кВА';
					}
					StoN(Data[i*C+1],TUKTN*TUKTT,ChKoef,(!ChKoef)?1:0.001);
					Data[i*C+1] = StoN.Res;
				}
				else
				if ((i>=16) && (i<=18))
				{
					if (ChKoef) Name[1]='кВ';
					StoN(Data[i*C+1],TUKTN,ChKoef,(ChKoef)?(1/1000):1);
					Data[i*C+1] = StoN.Res;
				}
				if ((i>=19) && (i<=21))
				{
					StoN(Data[i*C+1],TUKTT,ChKoef,1);
					Data[i*C+1] = StoN.Res;
				}
				if (Name.length>1)	Data[i*C]=Name[0]+', '+Name[1];
							else	Data[i*C]=Name[0];
				row = {P:Data[i*C], V:Data[i*C+1], T:Data[i*C+2]};
				break;
			case '#en_tb':
				row = {P:Data[i*C], ST:Data[i*C+1], T1:Data[i*C+2], T2:Data[i*C+3], T3:Data[i*C+4], T4:Data[i*C+5], T:Data[i*C+6]};
				break;
		};
		var Cmd='addRowData';
		if (Cnt>0) Cmd='setRowData';
		jQuery(NameTab).jqGrid(Cmd,i,row);
	};
}

function showAsyncRequestComplete()
{
	var Datas="";
	
	if ((req.readyState == 4) || bEmul)
		HideWait();
	if ((req.readyState == 4)&&(req.status == 200) || bEmul)
	{
	  respText = TrimStr(req.responseText);
	  if (respText.indexOf('Err')+1)
	  {
		Datas= respText.split(',');
		if (Datas[1]=="3"){
			AccMsg = Datas[2];
			SetWTm(9,1);
		} else alert(Datas[2]);
	  }
		else
	  {	  
	  switch (TypePoll){
		case 0: case 2://обмен
			Timer=0;
			switch (NumDT){
			case 0: SetWTm(16,1);
				break;
			case 3: // глобальный массив
  				if (bEmul)
  					Datas=emul_glob.split(',')
				else
					Datas=respText.split(',');
				if (NumLocalVars==0){
					NumLocalVars = Datas[0];
					var TmpArr = [];					
					for (i=0; i<NumLocalVars; i++)
						TmpArr.push({id:i,mek_addr:-1,type_val:'-',value:0,quality:'-',dtime:'-'});
					// таблица
					jQuery("#loc_tb").jqGrid({
						data: TmpArr,
						cmTemplate:{sortable:false, align:"center"},
						datatype: "local",
						height: 575,
						colNames:['№','МЭК-адрес','Тип','Значение','Качество','Временная метка'],
						colModel:[
							{name:'id',index:'id', width:40, resizable:false},
							{name:'mek_addr',index:'mek_addr', width:110, resizable:false},
							{name:'type_val',index:'type_val', width:100},
							{name:'value',index:'value', width:200},
							{name:'quality',index:'quality', width:100},
							{name:'dtime',index:'dtime', width:250}
						],
						rowNum:25,
						rowList:[25,50,100,200,500],
						pager: $('#loc_pager'),
						multiselect: true,
						hidegrid: false,
						onPaging: // смена страницы или числа параметров на странице
							function(pgButton) {
								GlobPage  = $("#loc_tb").getGridParam('page');
								CntInPage = $("#loc_tb").getGridParam('rowNum');
								AsyncRequest();
							},
						onSelectRow: // выделение параметра
							function(rowid,status) {
								if (status){// создание одного графика переменной
									var res=jQuery("#loc_tb").jqGrid('getRowData',rowid);
									var date = new Date(res.dtime.replace(/(\d+).(\d+).(\d+)/, '$3/$2/$1'));
									glob_d_m[glob_d_m.length]={
										label:rowid+" = -000.00",
										mylabel:rowid,
										data:[],
										data_ext:[[date.valueOf(),res.value]],
										DataTab:[],
										lines:{show:true,steps:true},
										hide: false
									}
								}
									else
								{ // поиск и удаление параметра из списка графиков
									var ii;
									for (ii=0; ii<glob_d_m.length; ii++)
										if (glob_d_m[ii].mylabel==rowid) {
											delete glob_d_m.splice(ii,1);
											break;
										};
								};
							}
					});
					SetWTm(5,1);
				}
				Datas.splice(0,1);
				// дополнение отслеживаемых данных для графика и обновление пришедщих данных для таблицы
				bChanges=false;
				var num_d=Datas.length/6;
				for (i=0; i<num_d; i++){
					// график
					if (glob_d_m.length>0) // чтото отслеживается ?
					{	for (ii=0; ii<glob_d_m.length;ii++){
							if (glob_d_m[ii].mylabel==Datas[i*6]){
								var B=Datas[i*6+3], C=Datas[i*6+5];
								var date = new Date(C.replace(/(\d+).(\d+).(\d+)/, '$3/$2/$1'));
								var A = date.valueOf();
								glob_d_m[ii].data_ext.push([A, B]);
								glob_d_m[ii].DataTab.push(C);
								bChanges=true;
								break;
							}
						}
					}
					// обновить параметр в таблице
					SetValsData(Datas,i*6);
				}
				// сортировка данных графика по номеру в глоб массиве
				if (bChanges) glob_d_m.sort(
					function(a,b) {
						return a.mylabel-b.mylabel
					}
				);

				/*// график
				if (bFirstGr){
					bFirstGr=false;
					//plot.setData(glob_d_m);
					plot.setupGrid();
					redraw(glob_d_m);;
					overview.setData(glob_d_m);
					overview.setupGrid();
					overview.draw();
					//plotAccordingToChoices(glob_d_m);				
				} else
				{
					if (bChanges)
					{
						for (i=0; i<glob_d_m.length; i++)
						glob_d_m[i].data = glob_d_m[i].data.sort(obr);
						//plot.setData(glob_d_m);
						plot.setupGrid();
						redraw(glob_d_m);
						overview.setData(glob_d_m);
						overview.setupGrid();
						overview.draw();
					}
					LegendInit(glob_d_m);
				}
				if (glob_d_m.length==0) {
					$$$('glob_msg').innerHTML="Не выбраны данные для построения графика.<br>Отметьте элементы в списке для отображения.";
					$$$('glob_gr').style.visibility="hidden";
					$$$('glob_overview').style.visibility="hidden";
				}
					else
				{	$$$('glob_msg').innerHTML="";
					$$$('glob_gr').style.visibility="visible";
					$$$('glob_overview').style.visibility="visible";
				}*/				
				break;

				if (Timer>=TUUpdate) tm();
				break;
			case 5: // Диаграмма
				if (bEmul)
					Datas=emul_diag.split(';');
				else
					Datas=respText.split(';');
				
				Datas[2]=Datas[2].replace(/Pa/g,"Прямая активная@ кВт");
				Datas[2]=Datas[2].replace(/Oa/g,"Обратная активная@ кВт");
				Datas[2]=Datas[2].replace(/Pr/g,"Прямая реактивная@ кВт");
				Datas[2]=Datas[2].replace(/Or/g,"Обратная реактивная@ кВт");
				
				diag_data1=Datas[1];
				FillingJQGrid('#diag_tb1',diag_data1,7);
				//FillingJQGrid('#diag_tb2',Datas[2],3);
				if (bCanvasSupport) OutPower(Datas[0]);				
				break;
			case 1: // Измерения
				if (bEmul)
					izm_data=emul_izm;
				else
					izm_data=respText;
				FillingJQGrid('#izm_tb',izm_data,3);
				break;
			case 2: // Энергия
				if (bEmul)
					FillingJQGrid('#en_tb',emul_en,7);
				else
					FillingJQGrid('#en_tb',respText,7);
				break;
			case 4: // получасовки
				if (bEmul)
					Dat=emul_30.split(',');
				else
					Dat=respText.split(',');

				var bChanges = false;
				if (Dat.length>2){
					var ID_Str;
					var d=-1;
					var bFirst=false;
					i=1;
					while (i<(Dat.length-1)){
						// создание/дополнение одного графика переменной
						if (Dat[i].substring(0,1)=='d') {
							ID_Str = Dat[i].slice(1);
							i++; d++;
							if (!d_m[d]){
								bFirst=true;
								d_m[d]={
									label:"№"+ID_Str+" = -000.00",
									mylabel:ID_Str,
									data:[],
									data_ext:[],
									DataTab:[],
									lines:{show:true,steps:true},
									hide: false,
									tmpfor: 0
								};
							}
						}
						// проверка на существование такого же тега
						var bExist=false;
						if (d>=0){
							j=0;
							var B=Dat[i+1], C=Dat[i];
							var date = new Date(C.replace(/(\d+).(\d+).(\d+)/, '$3/$2/$1'));
							var A = date.valueOf();
							var jl=d_m[d].data_ext.length;
							while ((j<jl)&&(!bExist)){
								if ((d_m[d].data_ext[j][0]==A)&&(d_m[d].data_ext[j][1]==B)) bExist=true;
								j++;
							}
						}
						// добавление
						if (!bExist){
							d_m[d].data_ext.push([A, B]);
							d_m[d].DataTab.push(C);
							bChanges=true;
						}
						i=i+2;
					}
					// Заполнение таблицы
				};
				
				//{			
					/*// кнопки
					$( "#h_btns" ).buttonset();
					$( "#h_b1" ).button({
						text: false,
						icons: {primary: "ui-icon-arrowthick-1-w"}
					});
					$$$('h_b1').style.width = wb;
					$( "#h_b2" ).button({
						text: false,
						icons: {primary: "ui-icon-seek-prev"}
					});
					$$$('h_b2').style.width = wb;
					$( "#h_b3" ).button({
						text: false,
						icons: {primary: "ui-icon-arrowthickstop-1-w"}
					});
					$$$('h_b3').style.width = wb;
					$( "#h_b4" ).button({
						text: false,
						icons: {primary: "ui-icon-arrowthick-2-n-s"}
					});
					$$$('h_b4').style.width = wb;
					$( "#h_b5" ).button({
						text: false,
						icons: {primary: "ui-icon-arrowthickstop-1-e"}
					});					
					$$$('h_b5').style.width = wb;
					
					$( "#h_b6" ).button({
						text: false,
						icons: {primary: "ui-icon-seek-next"}
					});					
					$$$('h_b6').style.width = wb;
					
					$( "#h_b7" ).button({
						text: false,
						icons: {primary: "ui-icon-arrowthick-1-e"}
					});
					$$$('h_b7').style.width = wb;
					
					$( "#h_b8" ).button({
						text: false,
						icons: {primary: "ui-icon-refresh"}
					});
					$$$('h_b8').style.width = wb;
					
					// графики
					plot = $.plot($("#graph30"), d_m, options30);
					overview = $.plot($("#overview"), d_m, {
						series: {
							lines: { show: true, lineWidth: 1 },
							shadowSize: 0
						},
						xaxis: { ticks: [], mode: "time" },
						yaxis: { ticks: [], min: 0, autoscaleMargin: 0.1 },
						selection: { mode: "x" },
						legend: {show: false}
					});
					$("#graph30").bind("plotselected", function (event, ranges) {
						plot = $.plot($("#graph30"), d_m,
							$.extend(true, {}, options30, {
								xaxis: { min: ranges.xaxis.from, max: ranges.xaxis.to }
							}));
						overview.setSelection(ranges, true);
						LegendInit(d_m);
					});
					$("#overview").bind("plotselected", function (event, ranges) {
						plot.setSelection(ranges);
						LegendInit(d_m);
					});
					
					ig = 0;
					$.each(d_m, function(key, val) {
						val.color = ig;
						++ig;
					});
					$("#graph30").bind("plothover",  function (event, pos, item) {
						latestPosition = pos;
						if (!updateLegendTimeout)
							updateLegendTimeout = setTimeout(updateLegend, 50);
					});
					choiceContainer = $("#choices");
					$.each(d_m, function(key, val) {
						choiceContainer.append(	'<input type="checkbox" name="' + key +
												'" checked="checked" id="id' + key + '">' +
												'<label for="id' + key + '">'
												+ val.mylabel + '</label><br/>');
					});
					choiceContainer.find("input").click(plotAccordingToChoices(d_m));
					plotAccordingToChoices(d_m);*/					
				//} else
				//{
					/*if (bChanges)
					{
						for (i=0; i<d_m.length; i++)
						  d_m[i].data_ext = d_m[i].data_ext.sort(obr);
						plot.setData(d_m);
						plot.setupGrid();
						redraw(d_m);
						overview.setData(d_m);
						overview.setupGrid();
						overview.draw();
					}
					LegendInit(d_m);*/
				//}
				var i30, j30, curmintime=0;
				// поиск минимальной временной метки
				for (i30=0; i30<d_m.length; i30++)
				{
					if ((curmintime == 0) || (curmintime > d_m[i30].data_ext[0][0]))
						curmintime = d_m[i30].data_ext[0][0];
				}
				
				// заполнение таблицы получасовок
				data30_with_K = [];
				data30_origin = [];
				var fNoExit;
				ChKoef = $$$("ChKoef").checked;
				if (d_m.length>0)
				do {
					fNoExit = false;
					var data30 = {Time30:'-', Ap30:'-', Am30:'-', Rp30:'-', Rm30:'-'};
					var data30_orig = {Time30:'-', Ap30:'-', Am30:'-', Rp30:'-', Rm30:'-'};
					for (i30=0; i30<d_m.length; i30++)
					{
						if (d_m[i30].tmpfor < d_m[i30].data_ext.length)
						{
							if (d_m[i30].data_ext[d_m[i30].tmpfor][0] == curmintime)
							{
								fNoExit = true;
								data30.Time30 = d_m[i30].DataTab[d_m[i30].tmpfor];
								data30_orig.Time30 = data30.Time30;
								StoN(d_m[i30].data_ext[d_m[i30].tmpfor][1],1/(TUKTN*TUKTT), false,1);
								if (d_m[i30].mylabel == "A+") 
								{
									data30.Ap30 = StoN.Res;
									data30_orig.Ap30 = d_m[i30].data_ext[d_m[i30].tmpfor][1];
								}
									else
								if (d_m[i30].mylabel == "A-")
								{
									data30.Am30 = StoN.Res;
									data30_orig.Am30 = d_m[i30].data_ext[d_m[i30].tmpfor][1];
								}
									else
								if (d_m[i30].mylabel == "R+")
								{
									data30.Rp30 = StoN.Res;
									data30_orig.Rp30 = d_m[i30].data_ext[d_m[i30].tmpfor][1];
								}
									else
								if (d_m[i30].mylabel == "R-")
								{
									data30.Rm30 = StoN.Res;
									data30_orig.Rm30 = d_m[i30].data_ext[d_m[i30].tmpfor][1];
								}
								d_m[i30].tmpfor++;
							}
							if (d_m[i30].tmpfor < d_m[i30].data_ext.length) fNoExit = true; // на случай если получасовок для данного интервала нет, но не все данные обработаны
						}
					}
					curmintime += 1800000;
					// добавить
					if (fNoExit) 
					{
						if (!isNaN(data30_orig.Ap30))
							data30_orig.Ap30	=	parseFloat(data30_orig.Ap30).toFixed(3);
						if (!isNaN(data30_orig.Am30))
							data30_orig.Am30	=	parseFloat(data30_orig.Am30).toFixed(3);
						if (!isNaN(data30_orig.Rp30))
							data30_orig.Rp30	=	parseFloat(data30_orig.Rp30).toFixed(3);
						if (!isNaN(data30_orig.Rm30))
							data30_orig.Rm30	=	parseFloat(data30_orig.Rm30).toFixed(3);
						data30_origin.push(data30_orig);
												
						if (!isNaN(data30.Ap30))
							data30.Ap30	=	parseFloat(data30.Ap30).toFixed(3);
						if (!isNaN(data30.Am30))
							data30.Am30	=	parseFloat(data30.Am30).toFixed(3);
						if (!isNaN(data30.Rp30))
							data30.Rp30	=	parseFloat(data30.Rp30).toFixed(3);
						if (!isNaN(data30.Rm30))
							data30.Rm30	=	parseFloat(data30.Rm30).toFixed(3);
						data30_with_K.push(data30);
					}
				}
				while (fNoExit);				
				AddArr30();				
				break;
			case 10:// case 11:
				if (bEmul)
					Datas="192.168.0.105,255.255.255.0".split(',');
				else
					Datas=respText.split(',');
				
				$$$('Adr_IP').value = Datas[0];
				$$$('Adr_Mask').value = Datas[1];
				$$$('Web_Port').value = Datas[2];
				break;
			case 15:
				S="Неизвестное устройство";
				if (bEmul){
					S="Emulation";
					$$$('CntrlrVersion').innerHTML=S;
				}
					else
				{
					$$$('CntrlrVersion').innerHTML=respText;
					S=respText.toLowerCase();
					// MOXA
					if(S.indexOf('moxa') + 1) {
						if(S.indexOf('240') + 1) S='УСПД \"ЭНТЕК IA240\"'
					}else
					if(S.indexOf('entek323') + 1) S='УСПД \"ЭНТЕК 323\"'
					else
					if(S.indexOf('M250') + 1) S='УСПД \"Меркурий-250\"';
				}
				document.title=S;
				break;
				
			case 22: case 23: case 24:
				Datas=respText.split(',');
				var bActivated = false;
				if (Datas.length >= 4)
				{
					bActivated = Datas[0] == "1";
					if (Datas[1].length != 19)
						$$$('SerialNum').value = "0000-0000-0000-0000";
					else
						$$$('SerialNum').value = Datas[1];

					if (Datas[2].length != 29)
						$$$('ActCode').innerHTML = "0000-0000-0000-0000-0000-0000";
					else
						$$$('ActCode').innerHTML = Datas[2];
					if (Datas[3].length != 39)
						$$$('RegCode').value = "0000-0000-0000-0000-0000-0000-0000-0000";
					else
						$$$('RegCode').value = Datas[3];
					if (bActivated) 
					{
						$$$('ActSost').innerHTML = "Активирована";
						document.getElementById("ActSost").style.color = 'green';
					}
						else	
					{
						$$$('ActSost').innerHTML = "Не активирована";
						document.getElementById("ActSost").style.color = 'red';
					}
					if (Datas.length == 4)
						$$$('TypeLic').innerHTML = "Неизвестный";
					else
						$$$('TypeLic').innerHTML = Datas[4];
				} else 
				{
					$$$('ActSost').innerHTML = "Запрос не выполнен";
					document.getElementById("ActSost").style.color = '#FF6A00';
				}
				break;

			case 25:
				if ((parseInt(respText) == 0) && !bEmul)
				{
					AccMsg = 'Неверный пароль';
					SetWTm(9,1500);
				}
					else
				{
					var S="Уровень доступа: ";
					switch (PswLvl){
						case 1: S+='1 - Доступ к данным';
								$$$('btn_reset').style.visibility="hidden";
								break;
						case 2: S+='2 - Конфигурирование';
								$$$('btn_reset').style.visibility="visible";
								break;
						case 3: S+='3 - Администрирование';
								$$$('btn_reset').style.visibility="visible";
								break;
					}
					//if (PswLvl>2) $$$('adm_btn').style.visibility="visible"
					//		else $$$('adm_btn').style.visibility="hidden";
					$$$('acc_mes').innerHTML = S;
					NM=6;
					SetWTm(10,1);
				}
				break;
				
			case 27:// Информация о контроллере
				Datas=respText.split('#');
				if (bNoEditP6)
				{
					$$$('Data_obl').innerHTML = $$$('Data_obl').innerHTML+"<h2>Информация о месте установки</h2><table style='border-spacing:0px' class='ui-widget-content'><tr><td class='ui-widget-content' width='170px'><strong>Дата установки</strong></td><td class='ui-widget-content'>"+Datas[0]+"</td></tr><tr><td class='ui-widget-content'><strong>Название владельца</strong></td><td class='ui-widget-content'>"+Datas[1]+"</td></tr><tr><td class='ui-widget-content'><strong>Юридический адрес</strong></td><td class='ui-widget-content'>"+Datas[2]+"</td></tr><tr><td class='ui-widget-content'><strong>Адрес установки</strong></td><td class='ui-widget-content'>"+Datas[3]+"</td></tr><tr><td class='ui-widget-content'><strong>Ответственное лицо</strong></td><td class='ui-widget-content'>"+Datas[4]+"</td></tr><tr><td class='ui-widget-content'><strong>Контактная информация</strong></td><td class='ui-widget-content'>"+Datas[5]+"</td></tr><tr><td class='ui-widget-content'><strong>Код (лиц. счет) потребителя</strong></td><td class='ui-widget-content'>"+Datas[6]+"</td></tr></table>";
				}
					else
				{
					$$$('DateInf').value = Datas[0];
					$$$('NameInf').value = Datas[1];
					$$$('AdresInf').value = Datas[2];
					$$$('LocationInf').value = Datas[3];
					$$$('PersonInf').value = Datas[4];
					$$$('ContactInf').value = Datas[5];
					$$$('KodInf').value = Datas[6];
				}
				NumDT=29;SetWTm(11,1);
				break;

			case 29:// Поверочная информация
				Datas=respText.split('#');
				
				if (bNoEditP6)
				{
					$$$('Data_obl').innerHTML = $$$('Data_obl').innerHTML+"<h2>Поверочные данные</h2><table style='border-spacing:0px' class='ui-widget-content'><tr><td width='170px' class='ui-widget-content'><strong>Дата выпуска</strong></td><td class='ui-widget-content'>"+Datas[0]+"</td></tr><tr><td class='ui-widget-content'><strong>Дата поверки</strong></td><td class='ui-widget-content'>"+Datas[1]+"</td></tr><tr><td class='ui-widget-content'><strong>Дата очередной поверки</strong></td><td class='ui-widget-content'>"+Datas[2]+"</td></tr></table>";
				}
					else
				{
					$$$('DateIssueCal').value = Datas[0];
					$$$('DateCheckingCal').value = Datas[1];
					$$$('DateNextCheckCal').value = Datas[2];
				}
				if (bGetMetro)
				{
					NumDT=124;SetWTm(11,1);
					bGetMetro=false;
				}				
				break;
			case 124:// Метрологическая информация
				if (bEmul)
					Datas = "8DF6EDC5020E87136B73F8051BFA2CA2,8DF6EDC5020E87136B73F8051BFA2CA2".split(',');
					//Datas = "8DF6EDC5020E87136B73F8051BFA2CA2,55F6EDC5020E87136B73F8051BFA2C45".split(',')";
					//Datas = "1";
				else
					Datas = req.responseText.split(',');
				S = "<h2>Метрологическая информация</h2><div style='border-spacing:0px' class='ui-widget-content'><strong>Драйвер опроса 'enlogic-drv'</strong><br><strong>";
				switch (Datas.length){
					case 2: S=S+"Контрольная сумма MD5:</strong>"+Datas[0]+"<br>";
							if (TrimStr(Datas[0]) == Datas[1])
								S=S+"Подсчитанное значение MD5 соответствует метрологически поверенному"
							else
								S=S+"Подсчитанное значение MD5 <strong>НЕ СООТВЕТСТВУЕТ</strong> метрологически поверенному ("+Datas[1]+")"
							break
					default: S=S+"Не удалось получить метрологическую информацию</strong> Код ошибки:"+Datas[0];
				}				
				S = S+"</div>";
				$$$('Data_obl').innerHTML = $$$('Data_obl').innerHTML+S;
				break;				
			};
			break;
	  }
	  }
	}
}

function SetWTm(NumFn, delay)
{
	if (NumFn>=0)
		w_tmr_arr.push({Fn:NumFn, Tm:delay});
	if ((w_tmr_arr.length>0) && (w_tmr<0))
		w_tmr = window.setInterval("work_tm("+w_tmr_arr[0].Fn+")", w_tmr_arr[0].Tm);		
}

function d_m_Exist(Str){
  for (var ii=0; ii<d_m.length;ii++)
    if (d_m[ii].mylabel==Str) 
	  return true;
  return false;  
}

// SetsStr - настройки
// HdndlsArr - массив заголовков
// DatasArr - массив данных
// DataRowsInTab - число строк данных в подтаблице (0 - деления нет)
function GetTableStr(SetsStr, SetsStr2, HdndlsArr, DatasArr, DataRowsInTab, ShowCheckBoxes){
	// настройки таблицы
	if (SetsStr=="") SetsStr="border=1 cellpadding=3 cellspacing=0";
	// начальная часть таблицы
	var StrHandl="<table "+SetsStr+"><tr>";
	// заголовок
	if (ShowCheckBoxes) StrHandl = StrHandl+"<th>&nbsp</th>";
	var HLen=HdndlsArr.length;
	for (i=0;i<HLen;i++)
		StrHandl = StrHandl + "<th>"+HdndlsArr[i]+"</th>";
	StrHandl = StrHandl + "</tr>";
	
	var Str='';
	var i,j,ii,l, bUseSubTabs;
	var NumRows = Math.round(DatasArr.length/HLen);
	bUseSubTabs	= (DataRowsInTab>0) && (NumRows>DataRowsInTab);
	
	if (bUseSubTabs) Str="<table><tr>"
				else DataRowsInTab=NumRows;
	var CurRow=0, ToRow;
	var bUseDopData = (TablMin>=0) && (TablMax>=0);
	while (CurRow<NumRows){
		// данные
		ToRow = CurRow+DataRowsInTab;
		if (ToRow>NumRows) ToRow = NumRows;
		
		var SubTabStr = StrHandl;	
		for (i=CurRow;i<ToRow;i++){
			var bAdd=true;
			if (bUseDopData){
				var DataID=DatasArr[i*HLen];
				bAdd= (DataID>=TablMin)&&(DataID<=TablMax);
			};			
			if (bAdd) SubTabStr = SubTabStr + "<tr>";
			var NameStr;
			if (ShowCheckBoxes){
				var b = true;
				if (GetTableStrMode==1) b = (parseInt(DatasArr[2+i*HLen])<=2);
				NameStr= 'c'+DatasArr[i*HLen];
				var ChkStr='';
				if (b) if (d_m_Exist(DatasArr[i*HLen])) ChkStr='checked ';
				if (bAdd) {if (b) SubTabStr = SubTabStr+'<td><input type=checkbox '+ChkStr+'onChange="OnClickCheckBoxTable(\''+NameStr+'\','+(Number(DatasArr[2+i*HLen])==1)+')" id="'+NameStr+'"></td>';
							 else SubTabStr = SubTabStr+'<td>&nbsp</td>';}
			}
			var TypeVar=0;
			for (j=0;j<HLen;j++){
				var SubStr='', D = DatasArr[j+i*HLen];
				if (ShowCheckBoxes){
					switch (j){
					  case 2: switch (GetTableStrMode){
								case 0:break;
								case 1: TypeVar = Number(D);
										switch (TypeVar){
											case 0: D = 'Float';	break;
											case 1: D = 'Boolean';	break;
											case 2: D = 'Integer';	break;
											case 3: D = 'Unknow';	break;
											case 4: D = 'DateTime';	break;
											case 5: D = 'IP Addr';	break;
											case 6: D = 'String';	break;
											case 7: D = 'Variant';	break;
										};
									break;
							  };
							  break;
					  case 3: SubStr = ' id=c'+NameStr;
					  		  if ((GetTableStrMode==1) && (TypeVar==1)) {
								if (D=='1')  D='True';
										else D='False';
							  }
							  break;
					  case 4: SubStr = ' id=q'+NameStr;
					  		  break;
					  case 5: SubStr = ' id=d'+NameStr;
					  		  break;
					}
				}
				if (bAdd) SubTabStr = SubTabStr + "<td"+SubStr+">"+D+"</td>";
			}
			if (bAdd) SubTabStr = SubTabStr + "</tr>";
		}
		SubTabStr = SubTabStr + "</table>";
		CurRow = ToRow;
		if (bUseSubTabs) Str=Str+"<td "+SetsStr2+">"+SubTabStr+"</td>";
					else Str=Str+SubTabStr;
	}
	if (bUseSubTabs) Str=Str+"</tr></table>";
	TablMin=-1;
	TablMax=-1;
	return Str;
}

function DrawCircle(rc, x,y, radius, grad, napravlenie)
{
	rc.strokeStyle = "#000";
	rc.fillStyle = "#FFF";
	rc.lineWidth = 2;
	rc.arc(x, y, radius, 0,2*Math.PI, true);
	rc.stroke();
	rc.fillStyle = "#000";
	rc.font = 'bold 16px arial';
	rc.textBaseline = 'top';
	rc.lineWidth = 0.5;
	var Pi6=Math.PI/6,j;
	for (i=0; i<2*Math.PI; i+=Pi6){
		for (j=radius; j>=7; j-=7){
			rc.beginPath();
			rc.moveTo(x+j*Math.sin(i), y+j*Math.cos(i));
			rc.lineTo(x+(j-3)*Math.sin(i), y+(j-3)*Math.cos(i));
			rc.closePath();
			rc.stroke();
		};
		rc.beginPath();
		rc.fillText(grad+'°',x+(radius+20)*Math.sin(i)-15, y+(radius+17)*Math.cos(i)-10);
		rc.closePath();
		rc.stroke();
		if (napravlenie>0) grad+=30
					  else grad-=30;
		if (grad==360) grad=0;
		if (grad<0) grad=330;
	};
};

function DrawArrow(rc, x,y, Radius, Angle, Color, Width){
	rc.strokeStyle = Color;	
	rc.fillStyle = Color;
	rc.lineWidth = Width;
	var r=7, dA = Math.PI/8, rA = Angle-Math.PI;
	var x1 = x+Radius*Math.cos(Angle), y1=y-Radius*Math.sin(Angle);
	var xA = x1+r*Math.cos(rA+dA), yA = y1-r*Math.sin(rA+dA);
    var xB = x1+r*Math.cos(rA-dA), yB = y1-r*Math.sin(rA-dA);  

	rc.beginPath();
	rc.moveTo(x,y);
	rc.lineTo(x1,y1);
	rc.closePath();
	rc.stroke();
	rc.beginPath();
	rc.moveTo(xA,yA);
	rc.lineTo(x1,y1);
	rc.lineTo(xB,yB);
	rc.lineJoin = "miter";
	rc.closePath();
	rc.stroke();
}

function OutText(text,rc,x,y,color){
	rc.strokeStyle = color;	
	rc.fillStyle = color;
	rc.fillText(text,x,y);
}

function OutPower(PointsStr)
{  
  if (bCanvasSupport){
	$$$('canva').innerHTML="<canvas id='canvas' width=720 height=340></canvas>";
	var C=PointsStr.split(',');
	if (C.length>0){
		var canvas = $$$('canvas');
		if(canvas.getContext){
			var rc=canvas.getContext('2d');
			DrawCircle(rc, 180,170, 140, 180, -1);
			DrawCircle(rc, 540,170, 140, 270, 1);
			DrawArrow(rc, 180,170, 137, Math.PI/2, "#880",2);
			DrawArrow(rc, 180,170, 137, Math.PI/2+2*Math.PI/3, "#F00",2);
			DrawArrow(rc, 180,170, 137, Math.PI/2+4*Math.PI/3, "#8F8",2);
			
			DrawArrow(rc, 180,170, C[0], C[1], "#880",3);
			DrawArrow(rc, 180,170, C[0], C[2], "#F00",3);
			DrawArrow(rc, 180,170, C[0], C[3], "#8F8",3);
			
			DrawArrow(rc, 540,170, 137, C[4], "#000",3);
			var x1 = 137*Math.cos(C[4]), y1=137*Math.sin(C[4]);
			DrawArrow(rc, 540,170, y1, Math.PI/2, "#00F",2);
			DrawArrow(rc, 540,170, x1, 0, "#F00",2);
			OutText('Ua',rc, 190,10,  "#880");
			OutText('Ub',rc, 317,220, "#8F8");
			OutText('Uc',rc, 23,220,  "#F00");
			OutText('Q',rc, 550,10,  "#00F");
			OutText('P',rc, 705,160,  "#F00");
		}
	}
  }
}

function tm(){
    Timer++;
	if (TUUpdate>0)
	{
		if  (Timer>=TUUpdate)
		{
			Timer = 0;
			if ((NumDT==3)&&(NM==2))
			{
				AsyncRequest();
			}
			else
			{
				if (NM==1)
					switch (NumDT){
						case 1: case 2: case 4:
						{
							AsyncRequest();
							break;
						}
						case 5: case 100:
						{
							NumDT=5;
							AsyncRequest();
							break;
						}
					}
			}
		}
	}
};

function showForm(block, FValue, flag, act)
{
	element = $$$(block);
	element.innerHTML = FValue;
	switch (flag)
	{
		case 'OK':
			element.innerHTML += "<button onclick=\"$$$('"+block+"').style.visibility='hidden';"+act+"\">OK</button>";
			 break;
		case 'OK_CANCEL':
			element.innerHTML += "<table align=center cols=2><tr><td width=50><button onclick=\"$$$('"+block+"').style.visibility='hidden'; "+act+"\">OK</button></td><td><button onclick=\"$$$('"+block+"').style.visibility='hidden'\">Отмена</button></td></tr></table>";
			break;
	}
	element.style.left=(element.parentElement.clientWidth-element.clientWidth)/2+"px";
	element.style.top=(element.parentElement.clientHeight-element.clientHeight)/2+"px";
	element.style.visibility="visible";
}

function fUploadFile(idF,idB,idPB) {
	var reader;
	var progress = document.querySelector('.percent');
	var file;
	var startByte=0;
	var fs=0;
	var blob;
	var lngth;
	var SendLen=1024; //1kb
	var xhr;
	var percentLoaded;
	var AccesStr;

	function errorHandler(evt) {
		window.clearTimeout(ftmr);
		ftmr = -1;
		fs=0;
		$$$(idB).innerHTML='Передать';
		$$$(idF).className = '.percent';
		startByte = -1;
		
		switch(evt.target.error.code) {
			case evt.target.error.NOT_FOUND_ERR:
				alert('Файл не найден!');
				break;
			case evt.target.error.NOT_READABLE_ERR:
				alert('Файл не доступен на чтение');
				break;
			case evt.target.error.ABORT_ERR:
				alert('Отмена чтения файла');
				break;
			default:
				alert('Произошла ошибка при чтении файла.');
		};
	}

	function AsyncPostSend(Str)
	{
		xhr.open('POST','index.cgi',true);
		xhr.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
		xhr.setRequestHeader("Content-Length", Str.length);
		xhr.send(Str);
	}

	function ReadBlobFile()
	{
		if ((startByte+SendLen)<fs) lngth= SendLen
			else lngth= fs-startByte;
		if (file.slice) blob=file.slice(startByte, lngth);
		else {
			if (file.webkitSlice) blob=file.webkitSlice(startByte, startByte+lngth);
			else {
				if (file.mozSlice) blob=file.mozSlice(startByte, startByte+lngth);
			}
		}
	reader.readAsBinaryString(blob);
	if ((startByte+SendLen)==fs) lngth = SendLen+1;
	}

	function uploadAsyncBlobFileComplete()
	{
		if ((xhr.readyState == 4)&&(xhr.status == 200)&&(startByte>=0))
		{
			if (xhr.responseText == AccesStr) // ответ правильный ?
			{
				window.clearTimeout(ftmr);
				ftmr = window.setInterval("f_tm()",1000); // сброс таймера
				startByte+=lngth;
				// прогресс
				percentLoaded = Math.round((startByte/fs) * 100);
				progress.style.width = percentLoaded + '%';
				progress.textContent = percentLoaded + '%';	

				if (startByte < fs) {
					// чтение следующей части файла
					ReadBlobFile();
				};
			}
			if ((xhr.responseText=='OK_RD')&&(lngth==(fs-startByte)))
			{// контроллер принял файл
				window.clearTimeout(ftmr);
				ftmr = -1;
				AsyncPostSend('DT=21');
				fs=0;
				startByte = -1;
				$$$(idB).innerHTML='Передать';
				$$$(idPB).className = '.percent';
				alert('Загрузка в контроллер завершена');
			};
		}
	}

	function BlobLoadDone(evt) {
	// отправка в асинхронном режиме
		if (reader.result.length>0){
			var HexStr='';// преобразование в HEX строку
			blob=null;
			for (i=0; i<reader.result.length; i++){
				var Ch = reader.result.charCodeAt(i).toString(16);
				if (Ch.length<2) Ch = '0'+Ch;
				if (Ch.length>2) Ch = Ch[2]+Ch[3];
				HexStr = HexStr+Ch;
			};
			AsyncPostSend('DT=20&FS='+startByte+'&FL='+lngth+'&FD='+HexStr);
			AccesStr = startByte.toString() + lngth.toString();
		}
	}

	function handleFileLoad(evt) {
		b=false;
		if ($$$(idB).innerHTML !== 'Отмена передачи')
		{
			var b = (file !== undefined);
			if (b)
			{// инициализация
				reader = new FileReader();
				reader.onerror = errorHandler;
				reader.onload = BlobLoadDone;
				reader.onloadstart = function(e) {
					$$$(idPB).className = 'loading';
				};

				fs = file.size;
				b = fs>0;
				if (b)
				{
					$$$(idB).innerHTML='Отмена передачи';

					progress.style.width = '0%';
					progress.textContent = '0%';

					// старт чтения
					startByte = 0;

					xhr = new XMLHttpRequest();
					xhr.onreadystatechange = uploadAsyncBlobFileComplete;

					ReadBlobFile();
					ftmr = window.setInterval("f_tm()",1000);
				}
			}
		}
		if (!b){
			$$$(idB).innerHTML='Передать';
			alert('Не возможно передать файл');
		}
	}

	function handleFileSelect(evt){
		file = evt.target.files[0];
	};

	$$$(idB).addEventListener('click', handleFileLoad, false);
	$$$(idF).addEventListener('change', handleFileSelect, false);
};

function f_tm(){
	// стоп таймера
	window.clearTimeout(ftmr);
	ftmr = -1;
	startByte = -1;
	$$$('PollBtn').innerHTML='Передать';
	alert('Ошибка передачи файла');	
	$$$('progress_bar').className = '.percent';
}

function work_tm(fn){
	// стоп таймера	
	window.clearTimeout(w_tmr);
	
	switch (fn){
		case 1:
		{
			var S=$$$('sdate').value;
			var E=$$$('edate').value;
			$( "#sdate" ).datepicker({
				defaultDate: "+1w",
				changeMonth: true,
				numberOfMonths: 3,
				onSelect: function( selectedDate ) {
					$( "#edate" ).datepicker( "option", "minDate", selectedDate );
				}
			});
			$( "#edate" ).datepicker({
				defaultDate: "+1w",
				changeMonth: true,
				numberOfMonths: 3,
				onSelect: function( selectedDate ) {
					$( "#sdate" ).datepicker( "option", "maxDate", selectedDate );
				}
			});
			$( "#sdate" ).datepicker( "option", "dateFormat", "yy.mm.dd");
			$( "#edate" ).datepicker( "option", "dateFormat", "yy.mm.dd");
			$$$('sdate').value = S;
			$$$('edate').value = E;
			$( "#ref_btn30" ).button({
				text: true,
				icons: {primary: "ui-icon-refresh"}
			});
			break;
		};
		case 2: SetTabs("#adm_tabs");
				//SetBtns("#adm_tabs");
				//SetBtns("#maind");
				SetMask("#Adr_IP","999.999.999.999");
				SetMask("#Adr_Mask","999.999.999.999");
				SetMask("#Web_Port","9999");
				SetMask("#DNS_Srv","999.999.999.999");
				SetMask("#Shluz","999.999.999.999");
				$( "#DateInf" ).datepicker({
					defaultDate: "+1w",
					changeMonth: true,
					numberOfMonths: 3
				});
				$( "#DateIssueCal" ).datepicker({
					defaultDate: "+1w",
					changeMonth: true,
					numberOfMonths: 3
				});
				$( "#DateCheckingCal" ).datepicker({
					defaultDate: "+1w",
					changeMonth: true,
					numberOfMonths: 3
				});
				$( "#DateNextCheckCal" ).datepicker({
					defaultDate: "+1w",
					changeMonth: true,
					numberOfMonths: 3
				});
				
				$( "#DateInf" ).datepicker( "option", "dateFormat", "yy.mm.dd");
				$( "#DateIssueCal" ).datepicker( "option", "dateFormat", "yy.mm.dd");
				$( "#DateCheckingCal" ).datepicker( "option", "dateFormat", "yy.mm.dd");
				$( "#DateNextCheckCal" ).datepicker( "option", "dateFormat", "yy.mm.dd");
		        break;
		/*case 4: // глобальные данные
				if (bFstGlob)
				{
					bFstGlob = false;
					// график
					glob_options.legend.container = $("#glob_legend");
					plot = $.plot($("#glob_gr"), glob_d_m, glob_options);					
					overview = $.plot($("#glob_overview"), glob_d_m, {
						series: {
							lines: { show: true, lineWidth: 1 },
							shadowSize: 0
						},
						xaxis: { ticks: [], mode: "time" },
						yaxis: { ticks: [], min: 0, autoscaleMargin: 0.1 },
						selection: { mode: "x" },
						legend: {show: false}
					});
					$("#glob_gr").bind("plotselected", function (event, ranges) {
						plot = $.plot($("#glob_gr"), glob_d_m,
							$.extend(true, {}, glob_options, {
								xaxis: { min: ranges.xaxis.from, max: ranges.xaxis.to }
							}));
						overview.setSelection(ranges, true);
						LegendInit(glob_d_m);
					});
					$("#glob_overview").bind("plotselected", function (event, ranges) {
						plot.setSelection(ranges);
						LegendInit(glob_d_m);
					});
					ig = 0;
					$.each(glob_d_m, function(key, val) {
						val.color = ig;
						++ig;
					});					
					$("#glob_gr").bind("plothover",  function (event, pos, item) {
						latestPosition = pos;
						if (!updateLegendTimeout)
							updateLegendTimeout = setTimeout(updateLegend, 50);
					});
					// кнопки
					$( "#glob_btns" ).buttonset();
					$( "#g_b1" ).button({
						text: false,
						icons: {primary: "ui-icon-arrowthick-1-w"}
					});
					$$$('g_b1').style.width = wb;
					$( "#g_b2" ).button({
						text: false,
						icons: {primary: "ui-icon-seek-prev"}
					});
					$$$('g_b2').style.width = wb;
					$( "#g_b3" ).button({
						text: false,
						icons: {primary: "ui-icon-arrowthickstop-1-w"}
					});
					$$$('g_b3').style.width = wb;
					$( "#g_b4" ).button({
						text: false,
						icons: {primary: "ui-icon-arrowthick-2-n-s"}
					});
					$$$('g_b4').style.width = wb;
					$( "#g_b5" ).button({
						text: false,
						icons: {primary: "ui-icon-arrowthickstop-1-e"}
					});
					$$$('g_b5').style.width = wb;
					$( "#g_b6" ).button({
						text: false,
						icons: {primary: "ui-icon-seek-next"}
					});
					$$$('g_b6').style.width = wb;
					$( "#g_b7" ).button({
						text: false,
						icons: {primary: "ui-icon-arrowthick-1-e"}
					});
					$$$('g_b7').style.width = wb;
				}
				
				SetTabs("#glob_tabs");
				SetBtns("#glob_tabs");
				break;*/
		case 5: // донастройка глобальной таблицы (т.к. в первый раз она еще не создалась)
				$$$('loc_tb').style.fontSize="120%";
				$$$('jqgh_loc_tb_id').parentElement.parentElement.style.fontSize="80%";
				break;
		case 6: // список ТУ
				jQuery("#TU_tb").jqGrid({
					cmTemplate:{align:"center"},
					datatype: "local",
					height: 605,
					data: [],
					colNames:['№','','Наименование','Тип','Серийный №','Адрес','КТН','КТТ','Сум.тариф','Тариф 1','Тариф 2','Тариф 3','Тариф 4','Временная метка','П','И'],
					colModel:[
						{name:'Num',index:'Num', width:20, sorttype:'int'},
						{name:'Conn',index:'Conn', width:11},
						{name:'NameTU',index:'NameTU', width:90, editable:true, edittype:"text"},
						{name:'Tipe',index:'Tipe', width:90},
						{name:'SN',index:'SN', width:90, sorttype:'int', editable:false, edittype:"text",editrules:{integer:true, required:true, minValue:0, maxValue:18446744073709551615}},
						{name:'Addr',index:'Addr', width:1/*45*/},
						{name:'KTN',index:'KTN', width:30, editable:true, edittype:"text", sorttype:'int',editrules:{integer:true, required:true, minValue:1, maxValue:65535}, editoptions:{defaultValue:1}},
						{name:'KTT',index:'KTT', width:30, editable:true, edittype:"text", sorttype:'int',editrules:{integer:true, required:true, minValue:1, maxValue:65535}, editoptions:{defaultValue:1}},
						{name:'TarSum',index:'TarSum', width:69, sorttype:'float'},
						{name:'Tar1',index:'Tar1', width:60, sorttype:'float'},
						{name:'Tar2',index:'Tar2', width:60, sorttype:'float'},
						{name:'Tar3',index:'Tar3', width:60, sorttype:'float'},
						{name:'Tar4',index:'Tar4', width:60, sorttype:'float'},
						{name:'Time',index:'Time', width:105},
						{name:'Rd30',index:'Rd30',width:13,align:'center',editable: true, edittype: 'checkbox',formatter: 'checkbox',editoptions:{value:'<input type="checkbox" value="false" offval="no" disabled="disabled"/>:-'}},
						{name:'RdInfo',index:'RdInfo',width:14,align:'center',editable: true, edittype: 'checkbox',formatter: 'checkbox',editoptions:{value:'<input type="checkbox" value="false" offval="no" disabled="disabled"/>:-'}}
					],
					recordtext: "Всего узлов учета: {2}",
					viewrecords: true,
					hidegrid:false,
					ondblClickRow: // выделение параметра
						function(rowid) {
							ShowNumPage(1);
						},
					onSelectRow: // выделение параметра
						function(rowid) {
							var row=jQuery('#TU_tb').jqGrid('getLocalRow',parseInt(rowid));
							NumTU = rowid;
							TUName = row.NameTU;
							TUSerial = row.SN;
							TUKTT = row.KTT;
							TUKTN = row.KTN;
							TUTipe = row.Tipe;
							bFl = (row.Tipe != undefined) && (row.Tipe.indexOf("PLC2") < 0);
							if (!bFl)
							{
								Rd30 = row.Rd30;
								RdInfo = row.RdInfo;
							}
						},
					pager:'#TU_nav',
					rowNum:1000,
					editurl: 'index.cgi'
				});
				
				if (PswLvl>1)
				{
					jQuery("#TU_tb").jqGrid('navGrid','#TU_nav',
						{edit:true,add:true,del:true,search:false}, //options
						{modal:true, savekey: [true, 13], closeOnEscape: true, reloadAfterSubmit:true,recreateForm:true,width:400,
						 afterSubmit:function(data,postd){
							if (postd.Rd30) postd.Rd30 = '1'
										else postd.Rd30 = '0';
							if (postd.RdInfo) postd.RdInfo = '1'
										else postd.RdInfo = '0';
							var su=jQuery("#TU_tb").jqGrid('setRowData',parseInt(postd.id),postd);
							
							if (data.status==200)
								bNext=true;
							return {0:true};
						 },
						 afterComplete: function (response, postdata, formid) 
						 {
							bNext=false;
							SetWTm(14,1000);
						 },
						 //beforeInitData : function(formid) 
						 afterclickPgButtons : function(whichbutton, formid, rowid)
						 {
							var row = jQuery('#TU_tb').jqGrid('getLocalRow', parseInt(rowid));
							bFl = (row.Tipe!=undefined) && (row.Tipe.indexOf("PLC2") < 0);
							$('#Rd30')[0].disabled = bFl;
							$('#RdInfo')[0].disabled = bFl;
							$$$('edithdTU_tb').childNodes[0].innerHTML = 'Редактировать запись '+(parseInt(rowid)+1)+' серийный №'+row.SN;
						 },
						 beforeSubmit:function(data,postd){
							if (data.KTN<=0) data.KTN = '1';
							if (data.KTT<=0) data.KTT = '1';
							return {0:true};
						 },
						 afterShowForm: function (formid) {
							$$$('Rd30').parentNode.parentNode.childNodes[0].innerHTML = 'Чтение профиля мощности';
							$$$('RdInfo').parentNode.parentNode.childNodes[0].innerHTML = 'Чтение информации телеизмерений';
							$('#Rd30')[0].disabled = bFl;
							$('#RdInfo')[0].disabled = bFl;
							$$$('edithdTU_tb').childNodes[0].innerHTML = 'Редактировать запись '+(parseInt(NumTU)+1)+' серийный №'+TUSerial;
							element = $$$('editmodTU_tb');
							element.style.left=(element.parentElement.clientWidth-element.clientWidth)/2+"px";
							element.style.top=(element.parentElement.clientHeight-element.clientHeight)/2+"px";
						},
						beforeCheckValues : 
							function(postdata, formid, mode) {
								postdata.SN = TUSerial;
								postdata.PSW = Psw;
								postdata.LVL = PswLvl;
								if ((TUTipe!=undefined) && (TUTipe.indexOf("PLC2") >= 0))
								{									
									postdata.Rd30 = $$$('Rd30').checked;
									postdata.RdInfo = $$$('RdInfo').checked;
								}
							}
						},// edit options
						{	closeOnEscape:true, recreateForm:true, width:400,
							beforeCheckValues:
							function(postdata, formid, mode) {
								postdata.PSW = Psw;
								postdata.LVL = PswLvl;
								if ((TUTipe!=undefined) && (TUTipe.indexOf("PLC2") >= 0))
								{
									postdata.Rd30 = $$$('Rd30').checked;
									postdata.RdInfo = $$$('RdInfo').checked;
								}
							},
							afterShowForm: function (formid) {
								$$$('Rd30').parentNode.parentNode.childNodes[0].innerHTML = 'Чтение профиля мощности';
								$$$('RdInfo').parentNode.parentNode.childNodes[0].innerHTML = 'Чтение информации телеизмерений';
								element = $$$('editmodTU_tb');
								element.style.left=(element.parentElement.clientWidth-element.clientWidth)/2+"px";
								element.style.top=(element.parentElement.clientHeight-element.clientHeight)/2+"px";
							}
						}, // add options
						{
							afterComplete : 
								function(response, postdata, formid) { 
									NumDT = 17; // удалить ТУ
									AsyncRequest();
								},
							afterShowForm: function (formid) {
								element = $$$('delmodTU_tb');
								element.style.left=(element.parentElement.clientWidth-element.clientWidth)/2+"px";
								element.style.top=(element.parentElement.clientHeight-element.clientHeight)/2+"px";
							}
						}, // del options
						{} // search options
					);
				}
				$$$('TU_nav_center').style.visibility="hidden";
				SetWTm(7,1);
				break;
		case 7: // донастройка списка ТУ
				$$$('TU_nav_right').style.fontSize="80%";
				$$$('jqgh_TU_tb_Num').parentNode.parentNode.style.fontSize="110%";
				$$$('TU_nav_right').parentNode.parentNode.style.fontSize="150%";
				break;
		case 8: // донастройка таблиц диаграммы
				$$$('diag_tb1').style.fontSize="120%";
				$$$('jqgh_diag_tb1_V').parentElement.parentElement.style.fontSize="80%";
				$$$('jqgh_diag_tb1_V').parentNode.parentNode.style.fontSize="110%";
				/*$$$('diag_tb2').style.fontSize="120%";
				$$$('jqgh_diag_tb2_En').parentElement.parentElement.style.fontSize="80%";
				$$$('jqgh_diag_tb2_En').parentNode.parentNode.style.fontSize="110%";*/
				$$$('izm_tb').style.fontSize="120%";
				$$$('jqgh_izm_tb_P').parentElement.parentElement.style.fontSize="80%";
				$$$('jqgh_izm_tb_P').parentNode.parentNode.style.fontSize="110%";
				$$$('en_tb').style.fontSize="120%";
				$$$('jqgh_en_tb_P').parentElement.parentElement.style.fontSize="80%";
				$$$('jqgh_en_tb_P').parentNode.parentNode.style.fontSize="110%";

				var D1 = new Date();
				var NumMs = D1.getTime()-86400000;
				D1.setTime(NumMs);
				var DateStr1 = D1.getFullYear()+'.'+GetTrueNum(D1.getMonth()+1)+'.'+GetTrueNum(D1.getDate());
				var D2 = new Date();
				var DateStr2 = D2.getFullYear()+'.'+GetTrueNum(D2.getMonth()+1)+'.'+GetTrueNum(D2.getDate());
				$$$('sdate').value = DateStr1;
				$$$('edate').value = DateStr2;				
				break;
		case 9: // диалог ввода пароля				
				if (ftmr>=0)
				{
					window.clearTimeout(ftmr);
					ftmr = -1;
				}
				bShowInputFm=true;
				Psw='00000000000000000000000000000000';
				$$$('acctxt').innerHTML = AccMsg;
				if (AccMsg.length>0)
					$( "#acc_dlg" ).dialog({
						height: 180
						,width: 380
						,modal: true
						,resizable: false
						,closeOnEscape: false
						,draggable: false
						,hide: "slide"
						,create: function(event, ui) {$('.ui-dialog-titlebar-close', $(this).closest('.ui-dialog') ).remove();}
					})
				else
					$( "#acc_dlg" ).dialog({
						height: 160
						,width: 380
						,modal: true
						,resizable: false
						,closeOnEscape: false
						,draggable: false
						,hide: "slide"
						,create: function(event, ui) {$('.ui-dialog-titlebar-close', $(this).closest('.ui-dialog') ).remove();}
					})
				$$$('acc_psw').value='';
				if (bReadCntInfo)
				{
					bReadCntInfo=false;
					NumDT=15;AsyncRequest();
				}
				break;
		case 10:
				ShowNumPage(NM);
				break;
		case 11:// выполнение запроса с номером NumDT
				AsyncRequest();
				break;
		case 12:SetTabs("#pribor_tabs");
				//SetBtns("#pribor_tabs");
				//SetBtns("#maind");
				break;
		case 14:$('#nData').trigger('click');
				break;
		case 15: $$$('jqgh_Tb30_Time30').parentNode.parentNode.style.fontSize="110%";
				break;
		case 16: if (bEmul)
				{
					for (i=0; i<50; i++)
					{
						var d = new Date();
						Datas += Math.random(0,1).toFixed(0)+',ТП фидер '+i+',PLC2_M203,'+Math.floor(Math.random()*1000000000)+','+(Math.random(0,100)*100).toFixed(0)+','+(Math.random(0,100)*100).toFixed(0)+','+(Math.random()*1000+1000).toFixed(2)+','+(Math.random()*1000).toFixed(2)+','+(Math.random()*1000).toFixed(2)+','+(Math.random()*1000).toFixed(2)+','+(Math.random()*1000).toFixed(2)+','+d.getDate()+'.'+d.getMonth()+'.'+d.getFullYear()+' '+d.toTimeString()+','+(((Math.random()*100)>=50)?'1':'0')+','+(((Math.random()*100)>=50)?'1':'0')+',';
						delete d;
					};
				}
				  else Datas=respText;
				
				// замена нечитаемых символов
				Datas = Datas.replace(/�/g, '№');
				Datas=Datas.split(',');
				//Datas.pop();

				if (Datas.length>0){
					var Cols=14;					
					var NumStr = Datas.length/Cols;
					var HideRdFlags = true;
					for (i=0; i<NumStr; i++)
					{
						var datarow = {Num:i+1, Conn:(Datas[i*Cols]==1 ? "<img src='css/img/C.png'/>":"<img src='css/img/DC.png'/>"), NameTU:Datas[i*Cols+1], Tipe:Datas[i*Cols+2], SN:Datas[i*Cols+3], /*Addr:Datas[i*Cols+???],*/ KTN:Datas[i*Cols+4], KTT:Datas[i*Cols+5], TarSum:Datas[i*Cols+6], Tar1:Datas[i*Cols+7], Tar2:Datas[i*Cols+8], Tar3:Datas[i*Cols+9], Tar4:Datas[i*Cols+10],Time:Datas[i*Cols+11],Rd30:Datas[i*Cols+12],RdInfo:Datas[i*Cols+13]};
						if ((datarow.Tipe!=undefined) && (datarow.Tipe.indexOf("PLC2") >= 0))
							HideRdFlags = false;
						var su=jQuery("#TU_tb").jqGrid('addRowData',i,datarow);
					};
					if (HideRdFlags)
					{
						jQuery("#TU_tb").hideCol(["Rd30"]);
						jQuery("#TU_tb").hideCol(["RdInfo"]);
					}
				}
				if (NM==1)
				{
					NumDT=5;
					AsyncRequest();
				}
				break;
	};
	
	w_tmr = -1;
	w_tmr_arr.shift();
	SetWTm(-1);
}

// debug
function work_tm2(){
	// стоп таймера	
	window.clearTimeout(w_tmr2);
	showAsyncRequestComplete();
}

function SetBtns(clas) {
	$( "input:submit, input:file, a, button", clas ).button(); 
};
function SetMask(clas,msk) {
	$(clas).mask(msk);
};
function SetTabs(clas) {
	$(clas).tabs();
};

function CheckFileAPISup(){
	// Проверяем поддержку File API 
	if (bFileAPISupport) {
		UploadFile = new fUploadFile('filestr','PollBtn','progress_bar');
	}//else {alert('File API не поддерживается данным браузером');}
}

function CheckPsw(){
	if ($$$('acc_psw').value!="")
		Psw = MD5_hexhash($$$('acc_psw').value);
	$( "#acc_dlg" ).dialog('close');
	// проверка пароля
	NumDT=25;
	AsyncRequest();
}

function ShowPswDlg(){
	if (ftmr>=0)
	{
		window.clearTimeout(ftmr);
		ftmr = -1;
	}
	AccMsg = '';
	SetWTm(9,500);
}

function SetMasksInReg(){
	SetMask("#SerialNum","****-****-****-****");
	SetMask("#RegCode","****-****-****-****-****-****-****-****");
	$$$('ActSost').innerHTML='Запрос состояния';
	document.getElementById("ActSost").style.color = 'black';
	NumDT=24;	
	AsyncRequest();
}

function Load_tm()
{
	window.clearTimeout(l_tm);
	l_tm = -1;
	if (l_tm>=0)
	{
		element = $$$('ws');
		if (element.style.visibility=="visible")
			element.style.opacity=0.3;
	}
}

function ShowWait()
{
	element = $$$('wm');
	element.style.left=(document.body.clientWidth-element.clientWidth)/2+"px";
	element.style.top=(window.innerHeight-element.clientHeight)/2+"px";
	element.style.visibility="visible";
	$$$('ws').style.visibility="visible";
	$$$('ws').style.opacity=0.0;
	l_tm = window.setInterval("Load_tm()",1000);
}

function HideWait()
{
	if (l_tm>=0)
	{
		window.clearTimeout(l_tm);
		l_tm = -1;
	}
	$$$('wm').style.visibility="hidden";
	$$$('ws').style.visibility="hidden";
}

var time;

function bagtm()
{
	if ((l_tm<0) && ("visible" == $$$('ws').style.visibility))
		$$$('ws').style.visibility="hidden";
}

function SelMMBtn(Obj)
{
	var mm=$$$('mmenu');
	for (i=0;i<mm.childNodes.length;i++)
	{
		if (mm.childNodes[i].type == 'submit')
		{
			if (mm.childNodes[i] == Obj)
				mm.childNodes[i].className = 'ui-state-default ui-corner-left ui-tabs-active ui-state-active ui-state-focus';
			else
				mm.childNodes[i].className = 'ui-button ui-widget ui-state-default ui-corner-all ui-button-text-only';
		}
	}
}

window.onload = function()
{
	if (ThemeVar=='i')
		Themer('incotex')
	else
		Themer('entels');
	$( "#dialog:ui-dialog" ).dialog( "destroy" );
	document.body.innerHTML=document.body.innerHTML+"<div id='acc_div'>"+AcsDlg+"</div>";
	ShowPswDlg();
	var Upd_Tab="<p class='ui-widget-header add_zx'>Загрузка исполнительной системы в контроллер</p><div style='padding:5px'><div class='d_val'>Файл конфигурации:</div><input type='file' id='filestr' size='90'/><br><br>";
	var S;
	if (bFileAPISupport) S="<div>"+Upd_Tab+"<div align='right'><button id='PollBtn'>Передать</button></div></div><div id='progress_bar'><div class='percent'>0%</div></div></div>"
					else S="<form action='index.cgi?DT=22' enctype='multipart/form-data' method='post'>"+Upd_Tab+"<div align='right'><input type='submit' value='Передать'/></div></div></form>";
	//$$$('TUUpdate').value = TUUpdate;	
	SetTabs("#TU_tabs");
	b_tmr = window.setInterval("bagtm()",1000);
	SelMMBtn($$$('StMBtn'));
	//SetBtns("#mmenu");
	//$( "#menu_tabs" ).tabs().addClass( "ui-tabs-vertical ui-helper-clearfix" );
    //$( "#menu_tabs li" ).removeClass( "ui-corner-top" ).addClass( "ui-corner-left" );
}