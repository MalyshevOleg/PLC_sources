echo $1 $2
/sbin/ip link set can0 down
baud=$2"000"
echo $baud
/sbin/ip link set can0 type can bitrate $baud
/sbin/ip link set can0 up
