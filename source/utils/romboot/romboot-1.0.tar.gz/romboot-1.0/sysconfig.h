#ifndef __SYSCONFIG_H
#define __SYSCONFIG_H

#define PLLA_VAL     0x202c8f04
#define PLLA_MCK     0x202	  // processor clock = master_clock * 3

#if defined(RAM_SIZE_16M)
// XTAL f=16MHZ!!!
// for 180 mhz:
// divider value = 4
// multiplier value = 45 (MULA = 0x2c)
// for 200 mhz:
// divider value = 2
// multiplier value = 25 (MULA = 0x18)
//#define PLLA_VAL     0x20188f02
#define SDRAM_CFG    0x33224AD4
#define USERFS_BASE  0xc03a0200
#define AT91C_UBOOT_ADDR 0x20FD0000
#else
//#define PLLA_VAL     0x20188f02
#define SDRAM_CFG    0x33224AD0
#define USERFS_BASE  0xc0209d00
#define AT91C_UBOOT_ADDR 0x207D0000
#endif

#endif
