#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <time.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <sys/time.h>
#include <linux/rtc.h>
#include <errno.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <unistd.h>

#include "cgic.h"

extern char *crypt(const char *key, const char *setting);

#define LF 10
#define CR 13

#define MAX_STRING_LEN 256

int tfd;
char temp_template[] = "/tmp/htp.XXXXXX";

/* From local_passwd.c (C) Regents of Univ. of California blah blah */
static unsigned char itoa64[] =         /* 0 ... 63 => ascii - 64 */
        "./0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";

static void to64(register char *s, register long v, register int n) {
    while (--n >= 0) {
        *s++ = itoa64[v&0x3f];
        v >>= 6;
    }
}

static void
add_password( char* user,char *pw, FILE* f )
{
    char pass[100];
    char* cpw;
    char salt[3];

    (void) srandom( (int) time( (time_t*) 0 ) );
    to64( &salt[0], random(), 2 );
    cpw = crypt( pw, salt );
    (void) fprintf( f, "%s:%s\n", user, cpw );
}

char *exip(char *ip,int ip_part,char *res)
{
    int i=0;
    char *tmp=strstr(ip,"\"")+1;
    while(ip_part--)
    {
      tmp=strstr(tmp,".")+1;
    }
    for(i=0;i<4;i++)
    {
		res[i]=tmp[i];
		if((tmp[i]=='\"') || (tmp[i]=='.'))
		{
			res[i]=0;
			break;
		}
    }
    return res;
}

char *dhcp_vars[] = {
	"skip",
	"used"
};

char *rs_mode_vars[] = {
	"232",
	"485"
};

char *com_lst_vars[] = {
	"COM1",
	"COM4"
};

char *com_lst_nms[] = {
	"/dev/ttyS1",
	"/dev/ttyS4"
};

int cgiMain ()
{
	int 				fnd=0,k,j;
	char 				dhcp[20];
	char 				ip[40],msk[40],gw[40];
	char 				dns1[40],dns2[40];
	char 				host_nm[40];
	char 				tmp_str[400];
	int 				is_dhcp;
	struct timeval 		tv;
	struct rtc_time 	org_time;
	int 				rs_mode[4];
	int 				do_chk;

	char 				res1[4],res2[4],res3[4],res4[4];

	FILE 				*tempfile;
	int 				fd;
	char 				fname[150];
	struct tm 			*tmn;

	cgiHeaderContentType("text/html; char-set=windows-1251");
	fprintf(cgiOut,"<html>\n");

	fprintf(cgiOut,"<script language=\"JavaScript\"\n>");
	fprintf(cgiOut,"<!-- hiding\n");
	fprintf(cgiOut,"var timerID ;\n");
	fprintf(cgiOut,"function UpdateClocks()\n");
	fprintf(cgiOut,"{\n");
	fprintf(cgiOut,"if(document.getElementById(\"sync_clk\").checked){\n");
	fprintf(cgiOut,"dt = new Date();\n");
	fprintf(cgiOut,"document.getElementById(\"clk_1\").value =dt.getHours();\n");
	fprintf(cgiOut,"document.getElementById(\"clk_2\").value =dt.getMinutes();\n");
	fprintf(cgiOut,"document.getElementById(\"clk_3\").value =dt.getSeconds();\n");
	fprintf(cgiOut,"document.getElementById(\"dat_1\").value =dt.getDate();\n");
	fprintf(cgiOut,"document.getElementById(\"dat_2\").value =dt.getMonth() + 1 ;\n");
	fprintf(cgiOut,"document.getElementById(\"dat_3\").value =dt.getFullYear();\n");
	fprintf(cgiOut,"}\n");

	fprintf(cgiOut,"timerID = window.setTimeout(\"UpdateClocks()\", 1001) ;\n");
	fprintf(cgiOut,"}\n");
	fprintf(cgiOut,"// End -->\n");
	fprintf(cgiOut,"function chk_r(field,v_min,v_max)\n");
	fprintf(cgiOut,"{\n");
	fprintf(cgiOut,"	if(!((field.value>=v_min) && (field.value<=v_max)))\n");
	fprintf(cgiOut,"	{\n");
	fprintf(cgiOut,"		field.value=v_min;\n");
	fprintf(cgiOut,"	}\n");
	fprintf(cgiOut,"}\n");
	fprintf(cgiOut,"function vld(evt) {\n");
	fprintf(cgiOut,"  var theEvent = evt || window.event;\n");
	fprintf(cgiOut,"  var key = theEvent.keyCode || theEvent.which;\n");
	fprintf(cgiOut,"  key = String.fromCharCode( key );\n");
	fprintf(cgiOut,"  var regex = /[0-9]|\\./;\n");
	fprintf(cgiOut,"  if( !regex.test(key) ) {\n");
	fprintf(cgiOut,"    theEvent.returnValue = false;\n");
	fprintf(cgiOut,"    theEvent.preventDefault();\n");
	fprintf(cgiOut,"  }\n");
	fprintf(cgiOut,"}\n");
	fprintf(cgiOut,"function vld2(evt) {\n");
	fprintf(cgiOut,"  var theEvent = evt || window.event;\n");
	fprintf(cgiOut,"  var key = theEvent.keyCode || theEvent.which;\n");
	fprintf(cgiOut,"  key = String.fromCharCode( key );\n");
	fprintf(cgiOut,"  var regex = /[A-Za-z0-9_]/;\n");
	fprintf(cgiOut,"  if( !regex.test(key) ) {\n");
	fprintf(cgiOut,"    theEvent.returnValue = false;\n");
	fprintf(cgiOut,"    theEvent.preventDefault();\n");
	fprintf(cgiOut,"  }\n");
	fprintf(cgiOut,"}\n");

	fprintf(cgiOut,"</script>\n");

	fprintf(cgiOut,"<head>");

	fprintf(cgiOut,"<TITLE>��������� ��� ��� 110</TITLE>");

	if(strstr(cgiPathInfo,"chng_pwd")) // Loading password page
	{
		fprintf(cgiOut,"<body>");
		fprintf(cgiOut,"<h1>��������� ������ ��� ������������ www-data </h1>");
		fprintf(cgiOut,"<form method=\"POST\" action=\"/cgi/setup.cgi\" ID=\"setup\">");
		fprintf(cgiOut,"������� ������         <input name=\"pwd1\" type=\"password\" value=\"\" size=\"9\" maxlength=\"8\"> ");
		fprintf(cgiOut,"������� ������ ��������<input name=\"pwd2\" type=\"password\" value=\"\" size=\"9\" maxlength=\"8\"><br>");
		fprintf(cgiOut,"<a href=\"setup.cgi\"> ������� �������� </a><br> ");
		fprintf(cgiOut,"<INPUT type=\"submit\" name=\"Submit_pwd\" VALUE=\"�������� ������\"></FORM>");
		fprintf(cgiOut,"</form>");
		fprintf(cgiOut,"</body> </html>\n");
		return;
	}

	if (cgiFormSubmitClicked("Submit_pwd") == cgiFormSuccess) // Loading password form user
	{
		fprintf(cgiOut,"<body>");
		cgiFormStringNoNewlines("pwd1",ip, 8);
		cgiFormStringNoNewlines("pwd2",msk, 8);

		if(strcmp(ip,msk)!=0)
		{
			fprintf(cgiOut,"������ �� �������<br>");
			fprintf(cgiOut,"<a href=\"setup.cgi/chng_pwd\"> ����� ������ </a><br> ");
			fprintf(cgiOut,"<a href=\"setup.cgi\"> ������� �������� </a><br> ");
		}
		else
		{
			tempfile=fopen("/root/www/.htpasswd","w+");

			if(  tempfile == NULL)
			{
				fprintf(cgiOut,"<p>Can not open file .htpasswd\n");
				fprintf(cgiOut,"</body></html>");
				return;
			}

			add_password("www-data",ip,tempfile);

			fclose(tempfile);

			fprintf(cgiOut,"<h1>������ �������!</h1><br>");
			fprintf(cgiOut,"<a href=\"setup.cgi\"> ������� �������� </a><br> ");
		}

		fprintf(cgiOut,"</body> </html>\n");
		return;
	}
   
	if (cgiFormSubmitClicked("Submit_all_set") == cgiFormSuccess) // Loading data form user
	{
		fprintf(cgiOut,"<body>");

		if(cgiFormCheckboxSingle("upd_clk")==0)
		{
			time_t a = time(0);
			tmn=localtime((const time_t *)&a);

			cgiFormStringNoNewlines("dat_1",res1, 4);
			tmn->tm_mday=atoi(res1);

			cgiFormStringNoNewlines("dat_2",res1, 4);
			tmn->tm_mon=atoi(res1)-1;

			cgiFormStringNoNewlines("dat_3",ip, 5);
			tmn->tm_year=atoi(ip)-1900;

			cgiFormStringNoNewlines("clk_1",res1, 4);
			tmn->tm_hour=atoi(res1);

			cgiFormStringNoNewlines("clk_2",res1, 4);
			tmn->tm_min= atoi(res1);

			cgiFormStringNoNewlines("clk_3",res1, 4);
			tmn->tm_sec= atoi(res1);

			tv.tv_sec = mktime(tmn);

			if(tv.tv_sec==-1)
			{
				fprintf(cgiOut, "wrong date time: %d/%d/%d: %d:%d:%d<p>",
				tmn->tm_mday, tmn->tm_mon,  tmn->tm_year+1900,
				tmn->tm_hour, tmn->tm_min, tmn->tm_sec);
			}
			else
			{
				fd = open("/dev/rtc",O_RDWR);

				if (fd == -1)
				{
					fprintf(cgiOut,"rtv open Failed. errno: %d</body></html>", errno);
					return;
				}

				org_time.tm_year=tmn->tm_year;
				org_time.tm_mon=tmn->tm_mon;
				org_time.tm_mday=tmn->tm_mday;

				org_time.tm_hour=tmn->tm_hour;
				org_time.tm_min=tmn->tm_min;
				org_time.tm_sec=tmn->tm_sec;

				ioctl(fd, RTC_SET_TIME, &org_time);
				close(fd);
			}
		}

		strcpy(fname, "/etc/network.conf");

		tempfile = fopen (fname, "w");

		if(tempfile==0)
		{
			return;
		}
       
		fprintf(tempfile, "# The parameters IPADDR, NETMASK, GWADDR are required.\n");
		fprintf(tempfile, "# Parameters MAC_ADDR, DHCP are optional.\n");
		fprintf(tempfile, "\n");

		cgiFormSelectSingle("dhcp1", dhcp_vars, 2, &is_dhcp, 0);
		fprintf(tempfile, "DHCP=%s\n",is_dhcp ? "1":"0");

		cgiFormStringNoNewlines("ip_1_1",res1, 4);
		cgiFormStringNoNewlines("ip_1_2",res2, 4);
		cgiFormStringNoNewlines("ip_1_3",res3, 4);
		cgiFormStringNoNewlines("ip_1_4",res4, 4);
		fprintf(tempfile, "IPADDR=\"%s.%s.%s.%s\"\n",res1,res2,res3,res4);

		cgiFormStringNoNewlines("msk_1_1",res1, 4);
		cgiFormStringNoNewlines("msk_1_2",res2, 4);
		cgiFormStringNoNewlines("msk_1_3",res3, 4);
		cgiFormStringNoNewlines("msk_1_4",res4, 4);
		fprintf(tempfile, "NETMASK=\"%s.%s.%s.%s\"\n",res1,res2,res3,res4);

		cgiFormStringNoNewlines("gw_1_1",res1, 4);
		cgiFormStringNoNewlines("gw_1_2",res2, 4);
		cgiFormStringNoNewlines("gw_1_3",res3, 4);
		cgiFormStringNoNewlines("gw_1_4",res4, 4);
		fprintf(tempfile, "GWADDR=\"%s.%s.%s.%s\"\n",res1,res2,res3,res4);

		cgiFormStringNoNewlines("dns_1_1",res1, 4);
		cgiFormStringNoNewlines("dns_1_2",res2, 4);
		cgiFormStringNoNewlines("dns_1_3",res3, 4);
		cgiFormStringNoNewlines("dns_1_4",res4, 4);
		fprintf(tempfile, "DNS1=\"%s.%s.%s.%s\"\n",res1,res2,res3,res4);

		cgiFormStringNoNewlines("dns_1_1",res1, 4);
		cgiFormStringNoNewlines("dns_1_2",res2, 4);
		cgiFormStringNoNewlines("dns_1_3",res3, 4);
		cgiFormStringNoNewlines("dns_1_4",res4, 4);

		fprintf(tempfile, "DNS2=\"%s.%s.%s.%s\"\n",res1,res2,res3,res4);

		cgiFormStringNoNewlines("host",host_nm, 10);
		fprintf(tempfile, "HOST_NAME=\"%s\"\n",host_nm);

		fflush(tempfile);
		fclose(tempfile);

		fprintf(cgiOut, "<h1>��������� ���������!</h1>");
		fprintf(cgiOut,"<a href=\"setup.cgi\"> ��������� �� ������� �������� </a><br> ");

		system("sh -c \"PATH=/sbin/:$PATH; /etc/rc.net\"");

		sleep(1);
		return;
	}
	else
	{
		fprintf(cgiOut,cgiQueryString);

		fprintf(cgiOut,"<body onLoad=\"UpdateClocks()\">");
		strcpy(fname, "/etc/network.conf");

		tempfile = fopen (fname, "r");

		if(  tempfile == NULL)
		{
			fprintf(cgiOut,"<p>Can not open file network.conf\n");
			fprintf(cgiOut,"</body></html>");
			return;
		}
		else
		{
			fgets(tmp_str,400,tempfile); // skip "# The parameters IPADDR, NETMASK, GWADDR are required."
			fgets(tmp_str,400,tempfile); // skip "# Parameters MAC_ADDR, DHCP are optional."
			fgets(tmp_str,400,tempfile); // skip ""

			if(!feof(tempfile))
				fgets(dhcp,20,tempfile);

			if(!feof(tempfile))
				fgets(ip,40,tempfile);

			if(!feof(tempfile))
				fgets(msk,40,tempfile);

			if(!feof(tempfile))
				fgets(gw,40,tempfile);

			if(!feof(tempfile))
				fgets(dns1,40,tempfile);

			if(!feof(tempfile))
				fgets(dns2,40,tempfile);

			if(!feof(tempfile))
				fgets(host_nm,40,tempfile);

			fclose(tempfile);

			if((strstr(host_nm,"\"")-host_nm)<40)
			{
				strcpy(host_nm,strstr(host_nm,"\"")+1);
				if((strstr(host_nm,"\"")-host_nm)<40)
					strstr(host_nm,"\"")[0]=0;
				else
					strcpy(host_nm,"plc110");
			}
			else
			{
				strcpy(host_nm,"plc110");
			}

			if( strstr(dhcp,"1") )
				is_dhcp=1;
			else
				is_dhcp=0;
		}

		fprintf(cgiOut,"<H1>��������� ��� %s</H1><p>","��� 110");

		fprintf(cgiOut,"<form method=\"POST\" action=\"/cgi/setup.cgi\" ID=\"setup\">");
		fprintf(cgiOut,"<p>");

		fd = open("/dev/rtc",O_RDWR);

		if (fd == -1)
		{
			fprintf(cgiOut,"rtv open Failed. errno: %d</body></html>", errno);
			return;
		}

		ioctl(fd, RTC_RD_TIME, &org_time);

		close(fd);
	
		fprintf(cgiOut,	"<TABLE rules=\"all\"><THEAD><THEAD><CAPTION><STRONG>��������� ������� � ���</STRONG></CAPTION></THEAD><TBODY><TR><TD>");
		fprintf(cgiOut,"��������� �������  <input name=\"clk_1\" ID=\"clk_1\" type=\"text\" value=\"%d\" size=\"2\" onkeyup=\"chk_r(this,0,23)\" onkeypress=\"vld(event)\">:<input name=\"clk_2\" ID=\"clk_2\" type=\"text\" value=\"%d\" size=\"2\" onkeyup=\"chk_r(this,0,59)\" onkeypress=\"vld(event)\">:<input name=\"clk_3\" ID=\"clk_3\" type=\"text\" value=\"%d\" size=\"2\" onkeyup=\"chk_r(this,0,59)\" onkeypress=\"vld(event)\">",org_time.tm_hour, org_time.tm_min, org_time.tm_sec);
		fprintf(cgiOut,"</TR></TD><TR><TD>���� <input name=\"dat_1\" ID=\"dat_1\" type=\"text\" value=\"%d\" size=\"2\" onkeyup=\"chk_r(this,1,31)\" onkeypress=\"vld(event)\">/<input name=\"dat_2\" ID=\"dat_2\" type=\"text\" value=\"%d\" size=\"2\" onkeyup=\"chk_r(this,1,12)\" onkeypress=\"vld(event)\">/<input name=\"dat_3\" ID=\"dat_3\" type=\"text\" value=\"%d\" size=\"4\" onkeyup=\"chk_r(this,2010,2100)\" onkeypress=\"vld(event)\">",org_time.tm_mday, org_time.tm_mon+1,org_time.tm_year+1900 );
		fprintf(cgiOut,"</TR></TD><TR><TD>�������� ����� � ��� <input name=\"upd_clk\" type=\"checkbox\" unchecked>");
		fprintf(cgiOut,"���������������� � PC<input name=\"sync_clk\" ID=\"sync_clk\" type=\"checkbox\" unchecked>");
		fprintf(cgiOut,"</TR></TD></TABLE><p>");
	
		fprintf(cgiOut,"<TABLE rules=\"all\"><THEAD><THEAD><CAPTION><STRONG>��������� ����</STRONG></CAPTION></THEAD>");
		fprintf(cgiOut,"<TBODY>");

		fprintf(cgiOut,"<TR><td>Host Name:");
		fprintf(cgiOut,"<input name=\"host\" type=\"text\" value=\"%s\" size=\"10\" maxlength=\"10\" onkeypress=\"vld2(event)\"><br>",host_nm);
		fprintf(cgiOut,"</td><td></td></tr>");
	

		fprintf(cgiOut,	"<TR><TD>");

		fprintf(cgiOut,	"DHCP Yes<input name=\"dhcp1\" type=\"radio\" %s value=\"used\" >",is_dhcp ? "CHECKED":" ");
		fprintf(cgiOut,	"No<input name=\"dhcp1\" type=\"radio\" %s value=\"skip\" ><br>",is_dhcp ? " ":"CHECKED");
		fprintf(cgiOut,	"IP adress 1:");
		fprintf(cgiOut,	"<input name=\"ip_1_1\" type=\"text\" value=\"%s\" size=\"3\" onkeyup=\"chk_r(this,0,255)\" onkeypress=\"vld(event)\">.<input name=\"ip_1_2\" type=\"text\" value=\"%s\" size=\"3\"  onkeyup=\"chk_r(this,0,255)\" onkeypress=\"vld(event)\">.",exip(ip,0,res1),exip(ip,1,res2));
		fprintf(cgiOut,	"<input name=\"ip_1_3\" type=\"text\" value=\"%s\" size=\"3\" onkeyup=\"chk_r(this,0,255)\" onkeypress=\"vld(event)\">.<input name=\"ip_1_4\" type=\"text\" value=\"%s\" size=\"3\" onkeyup=\"chk_r(this,0,255)\" onkeypress=\"vld(event)\"><br>",exip(ip,2,res3),exip(ip,3,res4));
		fprintf(cgiOut,	"<br>IP mask 1:");
		fprintf(cgiOut,	"<input name=\"msk_1_1\" type=\"text\" value=\"%s\" size=\"3\" onkeyup=\"chk_r(this,0,255)\" onkeypress=\"vld(event)\">.<input name=\"msk_1_2\" type=\"text\" value=\"%s\" size=\"3\" onkeyup=\"chk_r(this,0,255)\" onkeypress=\"vld(event)\">.",exip(msk,0,res1),exip(msk,1,res2));
		fprintf(cgiOut,	"<input name=\"msk_1_3\" type=\"text\" value=\"%s\" size=\"3\" onkeyup=\"chk_r(this,0,255)\" onkeypress=\"vld(event)\">.<input name=\"msk_1_4\" type=\"text\" value=\"%s\" size=\"3\" onkeyup=\"chk_r(this,0,255)\" onkeypress=\"vld(event)\"><br>",exip(msk,2,res3),exip(msk,3,res4));
		fprintf(cgiOut,	"<br>IP gateway 1:");
		fprintf(cgiOut,	"<input name=\"gw_1_1\" type=\"text\" value=\"%s\" size=\"3\" onkeyup=\"chk_r(this,0,255)\" onkeypress=\"vld(event)\">.<input name=\"gw_1_2\" type=\"text\" value=\"%s\" size=\"3\" onkeyup=\"chk_r(this,0,255)\" onkeypress=\"vld(event)\">.",exip(gw,0,res1),exip(gw,1,res2));
		fprintf(cgiOut,	"<input name=\"gw_1_3\" type=\"text\" value=\"%s\" size=\"3\" onkeyup=\"chk_r(this,0,255)\" onkeypress=\"vld(event)\">.<input name=\"gw_1_4\" type=\"text\" value=\"%s\" size=\"3\" onkeyup=\"chk_r(this,0,255)\" onkeypress=\"vld(event)\"><br>",exip(gw,2,res3),exip(gw,3,res4));
		fprintf(cgiOut,	"<br>IP DNS 1:");
		fprintf(cgiOut,	"<input name=\"dns_1_1\" type=\"text\" value=\"%s\" size=\"3\" onkeyup=\"chk_r(this,0,255)\" onkeypress=\"vld(event)\">.<input name=\"dns_1_2\" type=\"text\" value=\"%s\" size=\"3\" onkeyup=\"chk_r(this,0,255)\" onkeypress=\"vld(event)\">.",exip(dns1,0,res1),exip(dns1,1,res2));
		fprintf(cgiOut,	"<input name=\"dns_1_3\" type=\"text\" value=\"%s\" size=\"3\" onkeyup=\"chk_r(this,0,255)\" onkeypress=\"vld(event)\">.<input name=\"dns_1_4\" type=\"text\" value=\"%s\" size=\"3\" onkeyup=\"chk_r(this,0,255)\" onkeypress=\"vld(event)\"><br>",exip(dns1,2,res3),exip(dns1,3,res4));
		fprintf(cgiOut,	"<br>IP DNS 2:");
		fprintf(cgiOut,	"<input name=\"dns_2_1\" type=\"text\" value=\"%s\" size=\"3\" onkeyup=\"chk_r(this,0,255)\" onkeypress=\"vld(event)\">.<input name=\"dns_2_2\" type=\"text\" value=\"%s\" size=\"3\" onkeyup=\"chk_r(this,0,255)\" onkeypress=\"vld(event)\">.",exip(dns2,0,res1),exip(dns2,1,res2));
		fprintf(cgiOut,	"<input name=\"dns_2_3\" type=\"text\" value=\"%s\" size=\"3\" onkeyup=\"chk_r(this,0,255)\" onkeypress=\"vld(event)\">.<input name=\"dns_2_4\" type=\"text\" value=\"%s\" size=\"3\" onkeyup=\"chk_r(this,0,255)\" onkeypress=\"vld(event)\"><br>",exip(dns2,2,res3),exip(dns2,3,res4));
		fprintf(cgiOut,	"</td>");

		fprintf(cgiOut,	"</TABLE><p>");

		fprintf(cgiOut,"<input name=\"plc_type\" type=\"hidden\" value=\"plc304\" >");

        fprintf(cgiOut,	"</TABLE><p>\n");

        fprintf(cgiOut,"<a href=\"setup.cgi/chng_pwd\"> ����� ������</a><br> ");
        fprintf(cgiOut,"<INPUT type=\"submit\" name=\"Submit_all_set\" VALUE=\"�������� ������ � ���\"></FORM>");
        fprintf(cgiOut,"</form>");
   }
   fprintf(cgiOut,"</body> </html>\n");
}

