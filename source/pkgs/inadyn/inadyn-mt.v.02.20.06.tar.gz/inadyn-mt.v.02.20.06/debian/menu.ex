?package(inadyn-mt):needs="X11|text|vc|wm" section="Applications/see-menu-manual"\
  title="inadyn-mt" command="/usr/bin/inadyn-mt"
