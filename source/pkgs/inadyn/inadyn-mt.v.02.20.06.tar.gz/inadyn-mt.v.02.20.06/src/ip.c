/*
Copyright (C) 2003-2004 Narcis Ilisei
Modifications by Bryan Hoover (bhoover@wecs.com)
Copyright (C) 2009 Bryan Hoover (bhoover@wecs.com)

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
	Dyn Dns update main implementation file 
	Author: narcis Ilisei
	Date: May 2003

	History:
        - Sept. 2009
	  - Windows socket layer shutdown per startup
	  - Oct. 2009
	  - ip_initialize async
*/
#define MODULE_TAG "IP: "

#ifndef EXCLUDE_CONFIG_H

#include "config.h"

#endif

#ifdef _WIN32
#include <windows.h>
#include <winuser.h>
#endif

#include <stdlib.h>
#include <string.h>

#include "debug_if.h"
#include "ip.h"
#include "safe_mem.h"

#ifdef USE_THREADS

#include "gethostname.h"
#include "threads_wrapper.h"

#ifdef HAVE_FUNC_GETHOSTBYNAME_R_NOT

#ifndef ASYNC_LOOKUP

static mutex_t	gethostname_mutex=MUTEX_T_INIT;

#endif

#endif

#endif


/*public functions*/


/*
	 basic resource allocations for the ip object
*/
RC_TYPE ip_construct(IP_SOCKET *p_self)
{
	if (p_self == NULL)
	{
		return RC_INVALID_POINTER;
	}

	memset(p_self, 0, sizeof(IP_SOCKET));

	p_self->initialized = FALSE;
	p_self->socket = 0;
	memset( &p_self->remote_addr, 0,sizeof(p_self->remote_addr));
	p_self->timeout = IP_DEFAULT_TIMEOUT;

	return RC_OK;
}

/*
	Resource free.
*/	
RC_TYPE ip_destruct(IP_SOCKET *p_self)
{
	if (p_self == NULL)
	{
		return RC_OK;
	}

	if (p_self->initialized == TRUE)
	{
		ip_shutdown(p_self);
	}

	return RC_OK;
}

#ifdef _WIN32

static LRESULT CALLBACK window_proc(HWND hwnd,UINT uMsg,WPARAM wParam,LPARAM lParam)
{
	int	lp;


	if (uMsg==WM_USER) {
		

		if (lParam)
			lp=WSAGETASYNCERROR(lParam);

		if (lp==WSAHOST_NOT_FOUND)
			lp=lp;
	}

	return DefWindowProc(hwnd,uMsg,wParam,lParam);
}

static HWND create_window(WNDCLASS *window_class)
{
	HWND	hWindow;


	memset(window_class,0,sizeof(WNDCLASS));

	(window_class)->lpfnWndProc=window_proc;
	(window_class)->hInstance=GetModuleHandle(NULL);
	(window_class)->lpszClassName="ip_window";

	RegisterClass(window_class);

	hWindow=CreateWindow("ip_window",NULL,0,CW_USEDEFAULT,CW_USEDEFAULT,CW_USEDEFAULT,CW_USEDEFAULT,
				NULL,NULL,(window_class)->hInstance,NULL);


	return hWindow;
}

static int get_win_async_host_name(const char *p_remote_host_name,HOSTENT **p_remotehost)
{

	WNDCLASS	window_class;
	HWND		hWindow;
	HANDLE	async_ret=0;
	MSG		msg;


	hWindow=create_window(&window_class);


	async_ret=WSAAsyncGetHostByName(hWindow,WM_USER,p_remote_host_name,((char *) (*p_remotehost)),MAXGETHOSTSTRUCT);

	memset(&msg,0,sizeof(MSG));

	while (1) {

		PeekMessage(&msg,hWindow,0,0,PM_REMOVE);

		if (msg.message) {

			TranslateMessage(&msg);
			DispatchMessage(&msg);

			if (msg.message==WM_USER) {

				DestroyWindow(hWindow);

				break;
			}
		}

		os_sleep_ms(500);
	}	

	return (!((*p_remotehost)->h_name==NULL));
}

#endif

/*
	Sets up the object.
	
	- ...
*/
RC_TYPE ip_initialize(IP_SOCKET *p_self)
{
	RC_TYPE	rc=RC_OK;
	HOSTENT	*p_remotehost=NULL;
	int		get_host_ret=0;
	unsigned	long addr=0;

#ifndef HAVE_FUNC_GETHOSTBYNAME_R_NOT

	char		*tmphstbuf=NULL;
	size_t		hstbuflen=0;
#endif


	if (p_self->initialized == TRUE)
	{
		return RC_OK;
	}

/*
	--	*nix/BSD use gethostbyname_r if have, otherwise, degrade to using gethostbyname (cygwin's 
		supposedly thread safe), with a mutex

	--	windows, use WSAAsyncGetHostByName
*/
#if (defined (HAVE_FUNC_GETHOSTBYNAME_R_NOT) && defined (USE_THREADS) && !defined ASYNC_LOOKUP)

	DBG_PRINTF((LOG_INFO,"I:" MODULE_TAG "Getting (%d) gethostname_mutex for serial lookup in function ip_initialize...\n",p_self));

	get_mutex(&gethostname_mutex);

	DBG_PRINTF((LOG_INFO,"I:" MODULE_TAG "Got (%d) gethostname_mutex in ip_initialize...\n",p_self));
#endif

	do
	{
		rc = os_ip_support_startup();
		if (rc != RC_OK)
		{
			break;
		}

		/*remote addres */
		if (p_self->p_remote_host_name != NULL)
		{

#if (defined (_WIN32))

			p_remotehost=safe_malloc(MAXGETHOSTSTRUCT);
			memset(p_remotehost,0,MAXGETHOSTSTRUCT);

			get_host_ret=get_win_async_host_name(p_self->p_remote_host_name,&p_remotehost);

#elif (defined (HAVE_FUNC_GETHOSTBYNAME_R_NOT) || !defined (USE_THREADS))

			get_host_ret=(!(NULL==(p_remotehost=(HOSTENT *) gethostbyname(p_self->p_remote_host_name))));
#else
			HOSTENT	hostbuf;			

			get_host_ret=(!(NULL==(p_remotehost=(HOSTENT *) gethostname_re(p_self->p_remote_host_name,&hostbuf,&tmphstbuf,&hstbuflen))));
#endif


			if (!(get_host_ret))
			{
				rc = os_convert_ip_to_inet_addr(&addr, p_self->p_remote_host_name);
				if (rc != RC_OK)
				{
					DBG_PRINTF((LOG_WARNING,"W:" MODULE_TAG "Error 0x%x resolving host name '%s'\n",
					            os_get_socket_error(),
					            p_self->p_remote_host_name));
					rc = RC_IP_INVALID_REMOTE_ADDR;
					break;
				}
			}

			p_self->remote_addr.sin_family = AF_INET;
			p_self->remote_addr.sin_port = htons(p_self->port);
			p_self->remote_addr.sin_addr.s_addr = (addr == 0) ?
			                                      *((unsigned long *) p_remotehost->h_addr_list[0]) : addr;
		}
	}
	while(0);

#if (defined (_WIN32))

	if (p_remotehost)
		free(p_remotehost);

#elif (!defined (HAVE_FUNC_GETHOSTBYNAME_R_NOT))

	if (hstbuflen)
		free(tmphstbuf);

#elif (defined (USE_THREADS) && !defined (ASYNC_LOOKUP))

	DBG_PRINTF((LOG_INFO,"I:" MODULE_TAG "Releasing (%d) gethostname_mutex in ip_initialize...\n",p_self));

	release_mutex(&gethostname_mutex);
#endif


	if (rc != RC_OK)
	{
		ip_shutdown(p_self);
	}
	else
	{
		p_self->initialized = TRUE;
	}

	return rc;
}

/*
	Disconnect and some other clean up.
*/
RC_TYPE ip_shutdown(IP_SOCKET *p_self)
{
	if (p_self == NULL)
	{
		return RC_INVALID_POINTER;
	}

	if (p_self->socket)
	{
		closesocket(p_self->socket);
		p_self->socket = 0;
	}

	os_ip_support_cleanup();

	p_self->initialized = FALSE;
	return RC_OK;
}

RC_TYPE ip_send(IP_SOCKET *p_self, const char *p_buf, int len)
{
	if (p_self == NULL)
	{
		return RC_INVALID_POINTER;
	}

	if (!p_self->initialized)
	{
		return RC_IP_OBJECT_NOT_INITIALIZED;
	}

	if( send(p_self->socket, (char*) p_buf, len, 0) == SOCKET_ERROR )
	{
		DBG_PRINTF((LOG_WARNING,"W:" MODULE_TAG "Error 0x%x in send()\n", os_get_socket_error()));
		return RC_IP_SEND_ERROR;
	}
	return RC_OK;
}

/*
	Receive data into user's buffer.
	return 
		if the max len has been received 
		if a timeout occures
	In p_recv_len the total number of bytes are returned.
	Note:
		if the recv_len is bigger than 0, no error is returned.
*/
RC_TYPE ip_recv(IP_SOCKET *p_self, char *p_buf, int max_recv_len, int *p_recv_len)
{
	RC_TYPE rc = RC_OK;
	int remaining_buf_len = max_recv_len;
	int total_recv_len = 0;
	int recv_len = 0;

	if (p_self == NULL || p_buf == NULL || p_recv_len == NULL)
	{
		return RC_INVALID_POINTER;
	}

	if (!p_self->initialized)
	{
		return RC_IP_OBJECT_NOT_INITIALIZED;
	}

	while (remaining_buf_len > 0)
	{
		int chunk_size = remaining_buf_len > IP_DEFAULT_READ_CHUNK_SIZE ?
		                 IP_DEFAULT_READ_CHUNK_SIZE : remaining_buf_len;
		recv_len = recv(p_self->socket, p_buf + total_recv_len, chunk_size, 0);
		if (recv_len < 0)
		{

			{
				DBG_PRINTF((LOG_WARNING,"W:" MODULE_TAG "Error 0x%x in recv()\n", os_get_socket_error()));
				rc = RC_IP_RECV_ERROR;
			}
			break;
		}

		if (recv_len == 0)
		{
			if (total_recv_len == 0)
			{
				rc = RC_IP_RECV_ERROR;
			}
			break;
		}

		total_recv_len += recv_len;
		remaining_buf_len = max_recv_len - total_recv_len;
	}


	*p_recv_len = total_recv_len;
	return rc;
}


/*Accessors */

RC_TYPE ip_set_port(IP_SOCKET *p_self, int p)
{
	if (p_self == NULL)
	{
		return RC_INVALID_POINTER;
	}

	if (p < 0 || p > IP_SOCKET_MAX_PORT)
	{
		return RC_IP_BAD_PARAMETER;
	}
	p_self->port = p;
	return RC_OK;
}

RC_TYPE ip_set_remote_name(IP_SOCKET *p_self, const char* p)
{
	if (p_self == NULL)
	{
		return RC_INVALID_POINTER;
	}
	p_self->p_remote_host_name = p;
	return RC_OK;
}

RC_TYPE ip_set_remote_timeout(IP_SOCKET *p_self, int t)
{
	if (p_self == NULL)
	{
		return RC_INVALID_POINTER;
	}
	p_self->timeout = t;
	return RC_OK;
}

RC_TYPE ip_get_port(IP_SOCKET *p_self, int *p_port)
{
	if (p_self == NULL || p_port == NULL)
	{
		return RC_INVALID_POINTER;
	}
	*p_port = p_self->port;
	return RC_OK;
}

RC_TYPE ip_get_remote_name(IP_SOCKET *p_self, const char* *p)
{
	if (p_self == NULL || p == NULL)
	{
		return RC_INVALID_POINTER;
	}
	*p = p_self->p_remote_host_name;
	return RC_OK;
}

RC_TYPE ip_get_remote_timeout(IP_SOCKET *p_self, int *p)
{
	if (p_self == NULL || p == NULL)
	{
		return RC_INVALID_POINTER;
	}
	*p = p_self->timeout;
	return RC_OK;
}

