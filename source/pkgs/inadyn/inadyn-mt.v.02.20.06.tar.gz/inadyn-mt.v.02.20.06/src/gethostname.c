/*
# LICENSE
#
#   Copyright (c) 2008 Caolan McNamara <caolan@skynet.ie>
#   Copyright (c) 2008 Daniel Richard G. <skunk@iskunk.org>
#
#   This program is free software; you can redistribute it and/or modify it
#   under the terms of the GNU General Public License as published by the
#   Free Software Foundation; either version 2 of the License, or (at your
#   option) any later version.
#
#   This program is distributed in the hope that it will be useful, but
#   WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
#   Public License for more details.
#
#   You should have received a copy of the GNU General Public License along
#   with this program. If not, see <http://www.gnu.org/licenses/>.
#
#   As a special exception, the respective Autoconf Macro's copyright owner
#   gives unlimited permission to copy, distribute and modify the configure
#   scripts that are the output of Autoconf when processing the Macro. You
#   need not follow the terms of the GNU General Public License when using
#   or distributing such scripts, even though portions of the text of the
#   Macro appear in them. The GNU General Public License (GPL) does govern
#   all other use of the material that constitutes the Autoconf Macro.
#
#   This special exception to the GPL applies to versions of the Autoconf
#   Macro released by the Autoconf Archive. When you make and distribute a
#   modified version of the Autoconf Macro, you may extend this special
#   exception to the GPL to apply to your modified version as well.
*/

#ifndef EXCLUDE_CONFIG_H

#include "config.h"

#endif

#include <netdb.h>
#include <errno.h>
#include <memory.h>
#include "safe_mem.h"

#ifdef HAVE_FUNC_GETHOSTBYNAME_R_6
struct hostent * gethostname_re (const char *host,struct hostent *hostbuf,char **tmphstbuf,size_t *hstbuflen)
{
	struct hostent *hp;
	int herr,res;

	if (*hstbuflen == 0)
	{
		*hstbuflen = 1024; 
		*tmphstbuf = (char *) safe_malloc (*hstbuflen);
	}

	while (( res = 
		gethostbyname_r(host,hostbuf,*tmphstbuf,*hstbuflen,&hp,&herr))
		&& (errno == ERANGE))
	{
		/* Enlarge the buffer. */
		*hstbuflen *= 2;
		*tmphstbuf = (char *) safe_realloc (*tmphstbuf,*hstbuflen);
	}
	if (res)
		return NULL;
	return hp;
}
#endif
#ifdef HAVE_FUNC_GETHOSTBYNAME_R_5
struct hostent * gethostname_re (const char *host,struct hostent *hostbuf,char **tmphstbuf,size_t *hstbuflen)
{
	struct hostent *hp;
	int herr;

	if (*hstbuflen == 0)
	{
		*hstbuflen = 1024;
		*tmphstbuf = (char *) safe_malloc (*hstbuflen);
	}

	while ((NULL == ( hp = 
		gethostbyname_r(host,hostbuf,*tmphstbuf,*hstbuflen,&herr)))
		&& (errno == ERANGE))
	{
		/* Enlarge the buffer. */
		*hstbuflen *= 2;
		*tmphstbuf = (char *) safe_realloc (*tmphstbuf,*hstbuflen);
	}
	return hp;
}
#endif
#ifdef HAVE_FUNC_GETHOSTBYNAME_R_3
struct hostent * gethostname_re (const char *host,struct hostent *hostbuf,char **tmphstbuf,size_t *hstbuflen)
{
	if (*hstbuflen == 0)
	{
		*hstbuflen = sizeof(struct hostent_data);
		*tmphstbuf = (char *) safe_malloc (*hstbuflen);
	}
	else if (*hstbuflen < sizeof(struct hostent_data))
	{
		*hstbuflen = sizeof(struct hostent_data);
		*tmphstbuf = (char *) safe_realloc(*tmphstbuf, *hstbuflen);
	}
	memset((void *)(*tmphstbuf),0,*hstbuflen);

	if (0 != gethostbyname_r(host,hostbuf,(struct hostent_data *)*tmphstbuf))
		return NULL;
	return hostbuf;
}
#endif
