/*
 *
 *	Utility for checking buttons status on PLC240 boards
 *		based on h2o's btcmd application
 *
 *  Created on: June 17, 2010
 *      Author: mishal
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include <errno.h>
#include <getopt.h>
#include <fcntl.h>
#include <linux/input.h>

//#define _DEBUG


#ifdef _DEBUG
#define TRACE(x) fprintf x
#else
#define TRACE(x)
#endif

#define NUM_EVENTS 1
#define DELAY_IN_SECONDS 3

static unsigned short check_button, timeout;
int kb_mask;
struct input_event kb_event;

void nsleep (unsigned int msec)
{
	struct timespec ts;

	if (msec <10)
	{
		msec = 10;
	}
	ts.tv_sec = msec / 1000;
	ts.tv_nsec = msec % 1000;
	ts.tv_nsec = ts.tv_nsec * 1000 * 1000;

	//printf ("calling nanosleep msec %d sec %d nsec %d\n", msec, ts.tv_sec, ts.tv_nsec );
	nanosleep (&ts, NULL);
}


////////////////////////////////////////////////////////////////////////////////
int btn_open (void)
{
	FILE *devfp;
	char *buf=NULL;
	char *start;
	char inpdev[80];
	char devname[8];
	size_t bsize;
	int fd;

	if ((devfp = fopen ("/proc/bus/input/devices", "r")) != NULL)
		{
			while (getline (&buf, &bsize, devfp) != -1)
			{
				if (buf == NULL) continue;
				if (strncmp (buf, "N: Name=\"gpio-keys\"",19)==0)
				{
					getline (&buf, &bsize, devfp);
					getline (&buf, &bsize, devfp);
					getline (&buf, &bsize, devfp);
					getline (&buf, &bsize, devfp);
					if (strncmp (buf, "H: Handlers=", 12) == 0)
					{
						if ((start = strstr (buf, "event")) != NULL)
						{
							strncpy (devname, start, 7);
							devname[6] = '\0';
						}
					}
				}
				free (buf);
				buf = NULL;
			}

			fclose (devfp);
		}
		strncpy (inpdev, "/dev/input/", 70);
		strncat (inpdev, devname, 7);
		TRACE((stderr, "ACC_DEV => [%s]\n", inpdev));

/* Open the keyboard and get it ready for use */
	fd = open (inpdev, O_RDONLY | O_NONBLOCK);

	if (fd < 0) {
		perror ("open");
		return -1;
	}

	return fd;
}

////////////////////////////////////////////////////////////////////////////////
int btn_close (int fd)
{
	if (close (fd)) {
		perror ("close");
		return -1;
	}
	return 0;
}

////////////////////////////////////////////////////////////////////////////////
int process_kb_event(int type, int key)
{
	TRACE((stderr, "!!!<KEY PRESS> code=%03d %s\n", type, key ? "up" : "down"));
	return (type == KEY_KPENTER && key == 1) ? 0 : 1;
}

int btn_read (int fd)
{
	int nread, key, val;
	int len;
	int run, ret=0;
	struct input_event *events;

	len = sizeof (struct input_event) * NUM_EVENTS;
	events = malloc (len);
	if (!events) {
		perror ("malloc");
		return -1;
	}
	run = 1;
	key = 0; val = 0;
	for (run = 0; run < (timeout * 10); run++)
	{
		if ((nread = read (fd, events, NUM_EVENTS * sizeof (struct input_event))) == -1) {
			if (errno == EINTR || errno == EAGAIN) {
				nsleep (100);
				continue;
			}
			perror("read");
			free (events);
			return -1;
		}

		TRACE((stderr, "%s - We've got %d bytes finally\n", __FUNCTION__, nread));
		nread /= sizeof (struct input_event);
		for (len = 0; len < nread; len ++) {
			if (events[len].type == EV_KEY && events[len].code == check_button) {
				key = events[len].code;
				val = events[len].value;
				//printf("<KEY PRESS> code=%03d %s\n", events[len].code, !events[len].value ? "up" : "down");
				TRACE((stderr, "status: %x \n", events[len].value ));
				ret = events[len].code;
				break;
			}
		}
	}
	free (events);
	return ret;
}

void print_usage(const char *prog)
{
	printf("Usage: %s [-tS12345]\n", prog);
	puts("  -S --SYS   button SYS check\n"
	     "  -1 --F1    button F1 check\n"
	     "  -2 --F2    button F2 check\n"
	     "  -3 --F3    button F3 check\n"
	     "  -4 --F4    button F4 check\n"
	     "  -5 --F5    button F5 check\n"
		 "  -t --timeout timeout in seconds\n");
	exit(1);
}

void parse_opts(int argc, char *argv[])
{
	while (1) {
		static const struct option lopts[] = {
			{ "SYS",  0, 0, 'S' },
			{ "F1",   0, 0, '1' },
			{ "F2",   0, 0, '2' },
			{ "F3",   0, 0, '3' },
			{ "F4",   0, 0, '4' },
			{ "F5",   0, 0, '5' },
			{ "timeout", 1, 0, 't' },
			{ NULL, 0, 0, 0 },
		};
		int c;

		c = getopt_long(argc, argv, "t:S12345", lopts, NULL);

		if (c == -1)
			break;

		switch (c) {
		case 'S':
			check_button = BTN_0;
			break;
		case '1':
			check_button = BTN_1;
			break;
		case '2':
			check_button = BTN_2;
			break;
		case '3':
			check_button = BTN_3;
			break;
		case '4':
			check_button = BTN_4;
			break;
		case '5':
			check_button = BTN_5;
			break;
		case 't':
			timeout = atoi(optarg);
			break;
		default:
			print_usage(argv[0]);
			break;
		}
	}
}

int main (int argc, char *argv[])
{
	int ret;
	int fd_btn;

	parse_opts(argc, argv);

	fd_btn = btn_open();

	ret = btn_read(fd_btn);

	btn_close (fd_btn);
	TRACE((stderr, "Button Task: Stopped., ret= %i\n",ret));
	printf("%i\n",ret);
	return 0;
	//return (ret>255)?ret-255:ret; //it appears that main can't return integer bigger than 255!!!!
}

