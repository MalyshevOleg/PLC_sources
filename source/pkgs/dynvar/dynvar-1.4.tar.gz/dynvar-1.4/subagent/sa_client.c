#include <net-snmp/net-snmp-config.h>
#include <net-snmp/net-snmp-includes.h>
#include <net-snmp/agent/net-snmp-agent-includes.h>

#include <signal.h>
#include <pthread.h>
#include <string.h>
#include <errno.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <unistd.h>
#include <stdio.h>
#include <sys/select.h>

#include "linux_list.h"

#include "snmpdv_sa.h"

#include "sa_mib.h"
#include "sa_client.h"

typedef struct sa_client {
	struct llist_head list;
	int id;						/* just client's no. [1..max_count] */
	int socket;
	pthread_t thread;

	union {
		char raw[SNMPDV_SA_MAX_LEN_REQ_MSG];
		snmpdv_sa_msg_hdr mh;
	} in_msg;					/* receive  buffer */
	union {
		char raw[SNMPDV_SA_MAX_LEN_RESP_MSG];
		snmpdv_sa_msg_hdr mh;
	} out_msg;					/* send buffer */

	struct {
		unsigned run: 1;			/* run until this is not false: RO for CLIENT: WO for manager */
		unsigned terminated: 1;	/* thread terminated and needs cleanup: WO for CLIENT: RO for manager */
	} flags;
} sa_client;

typedef struct sa_clients_context {
	struct llist_head clients;
	int count;
	int max_count;
	int next_id;
} sa_clients_context;

static sa_clients_context c_ctx;

/* local methods declarations */
static void* client_run(void* arg);
static void client_destroy(sa_client *client);
static int client_process_request(sa_client *client, int timeout_sec);

static int client_wait_incoming_data(sa_client *client, int timeout_sec);
static int client_recv(sa_client *client, char *buf, unsigned short len, int wait_first_chunk);
static int client_recv_msg(sa_client *client);
static int client_make_reply_msg(sa_client *client, unsigned short len);
static void client_make_reply_msg_rc(sa_client *client, unsigned char rc);
static int client_send_msg(sa_client *client);
static void client_make_reply_msg_mib_name(sa_client *client);
static int client_send_mib_file(sa_client *client);

/* local methods */
static void* client_run(void* arg)
{
	sa_client *client = (sa_client *)arg;

	snmp_log(LOG_INFO, "client: %d: started\n", client->id);

	while (client->flags.run) {
		if (client_process_request(client, 0) != 0) {
			break;
		}
	}

	snmp_log(LOG_INFO, "client: %d exiting\n", client->id);
	client->flags.terminated = 1;

	pthread_exit(NULL);
}

static void client_destroy(sa_client *client)
{
	if (client) {
		llist_del(&client->list);
		close(client->socket);
		free(client);
	}
}

/**
 * @param timeout_sec timeout in seconds to wait data, if <= 0 - use NULL to block until incoming data are ready
 */
static int client_process_request(sa_client *client, int timeout_sec)
{
	int r;

	r = client_wait_incoming_data(client, timeout_sec);
	if (!r) {
		return 0; /* if timeout is used - this is timeout - no error, may do some other work and wait data again */
	} if (r < 0) {
		snmp_log(LOG_ERR, "client %d terminating: select failed: %s\n", client->id, strerror(errno));
		return -SNMPDV_SA_EFAIL;
	}

	/* read client's request */
	r = client_recv_msg(client);
	if (r < 0) {
		return r;
	} else if (r > 0) {
		snmp_log(LOG_ERR, "client %d: ignoring invalid message, reply with err code\n", client->id);
		client_make_reply_msg_rc(client, r);
	} else {
		switch (client->in_msg.mh.msg_type) {
			case SNMPDV_SA_MSG_ADD_VAR:
				snmp_log(LOG_DEBUG, "client %d: add var:'%s'\n", 
					client->id, ((snmpdv_sa_var *)(client->in_msg.mh.data))->name);
				r = sa_mib_add_var(client->id, &client->in_msg.mh);
				client_make_reply_msg_rc(client, r);
				break;
			case SNMPDV_SA_MSG_ADD_TRAP:
				snmp_log(LOG_DEBUG, "client %d: add trap:'%s'\n", 
					client->id, ((snmpdv_sa_trap *)(client->in_msg.mh.data))->name);
				r = sa_mib_add_trap(client->id, &client->in_msg.mh);
				client_make_reply_msg_rc(client, r);
				break;
			case SNMPDV_SA_MSG_DEL_ITEM:
				snmp_log(LOG_DEBUG, "client %d: del item:'%s'\n", 
					client->id, ((snmpdv_sa_var *)(client->in_msg.mh.data))->name);
				r = sa_mib_del_item(client->id, &client->in_msg.mh);
				client_make_reply_msg_rc(client, r);
				break;

			case SNMPDV_SA_MSG_GET_MIB_NAME:
				client_make_reply_msg_mib_name(client);
				break;
				
			case SNMPDV_SA_MSG_GET_MIB:
				return client_send_mib_file(client);
				break;

			default:
				snmp_log(LOG_WARNING, "client %d: ignoring unknown msg type\n", client->id);
				client_make_reply_msg_rc(client, SNMPDV_SA_EINVAL);
				break;
		}
	}
	
	return client_send_msg(client);
}

/**
 * @param timeout_sec timeout in seconds to wait data, if <= 0 - use NULL to block until incoming data are ready
 * @return result of select() 
 * @note select() is run on only one file descriptor, so if result > 0 we assume that data are ready on this only file-
 *          which is the client's socket.
 */
static int client_wait_incoming_data(sa_client *client, int timeout_sec)
{
	fd_set fdset;
	struct timeval timeout, *tv = NULL;

	FD_ZERO(&fdset);
	FD_SET(client->socket, &fdset);
	if (timeout_sec > 0) {
		timeout.tv_sec = timeout_sec;
		timeout.tv_usec = 0;
		tv = &timeout;
	}
	/* block or wait for specified time */
	snmp_log(LOG_DEBUG, "client %d entering into select (TO=%d)\n", 
			client->id, timeout_sec);
	return select(client->socket + 1, &fdset, NULL, NULL, tv);
}

/**
 * @param wait_first_chunk - whether or not to wait first chunk of data with recv timeout
 */
static int client_recv(sa_client *client, char *buf, unsigned short len, int wait_first_chunk)
{
	int r;
	ssize_t rcv_len;
	char *pos = buf;
	unsigned short left_len = len;

	while (left_len > 0) {
		if (wait_first_chunk) {
			r = client_wait_incoming_data(client, SNMPDV_SA_MSG_RECV_TIMEOUT_SEC);
			if (!r) {
				snmp_log(LOG_ERR, "client %d: receiving message timed out\n", client->id);
				return -SNMPDV_SA_EFAIL;
			} else if (r < 0) {
				snmp_log(LOG_ERR, "client %d: select error: %s\n", client->id, strerror(errno));
				return -SNMPDV_SA_EFAIL;
			}
		} else {
			/* set the flag to wait all the next chunks */
			wait_first_chunk = 1;
		}

		rcv_len = recv(client->socket, pos, left_len, 0);
		if (!rcv_len) {
			snmp_log(LOG_INFO, "client %d: disconnected\n", client->id);
			return -SNMPDV_SA_EFAIL; /* return err in order to stop this cleint */
		} else if (rcv_len < 0) {
			snmp_log(LOG_ERR, "client %d: failed to read msg: %s\n", client->id, strerror(errno));
			return -SNMPDV_SA_EFAIL;
		}
		left_len -= rcv_len;
		pos += rcv_len;
	}
	
	return 0;
}

/* return < 0 - error, no send answer, destroy client
                0 - success
                > 0 send this error code to client
*/
static int client_recv_msg(sa_client *client)
{
	int r;
	ssize_t len;
	snmpdv_sa_msg_hdr* mh = &client->in_msg.mh;
	unsigned short cs;

	/* receive msg header first, don't wait here for timeout- we already know that data are present */
	r = client_recv(client, (char*)mh, sizeof(*mh), 0);
	if (r) {
		return r;		/* fatal for the client */
	}

	/* expected total length */
	len = sizeof(*mh) + mh->len;

	snmp_log(LOG_DEBUG, "client %d: receiving msg: id=%d, type=%d, data_len=%d, expected total len=%d\n", 
		client->id, mh->msg_id, mh->msg_type, mh->len, len);
	
	/* receive payload if it is expected to be in this message */
	if (len > sizeof(*mh)) {
		/* wait for recv timeout */
		r = client_recv(client, mh->data, mh->len, 1);
		if (r) {
			return r;		/* fatal for the client */
		}
	}
	snmp_log(LOG_DEBUG, "client %d: msg: id=%d received OK\n", client->id, mh->msg_id);
	
	/* check the received message */
	if (mh->version != SNMPDV_SA_IF_VERSION) {
		snmp_log(LOG_ERR, "client %d: received msg of wrong version: 0x%04x\n", 
			client->id, mh->version);
		return SNMPDV_SA_EVERSION;
	}

	/* calc checksum and verify with expected value */
	cs = SNMPDV_SA_MSG_CS(mh, len);
	if (cs != SNMPDV_SA_MSG_CS_VALUE) {
		snmp_log(LOG_ERR, "client %d: received msg checksum is invalid: 0x%04X\n", 
			client->id, cs);
		return SNMPDV_SA_EINVAL;
	}

	return 0;
}

static int client_make_reply_msg(sa_client *client, unsigned short len)
{
	snmpdv_sa_msg_hdr *in_mh, *out_mh;

	out_mh = &client->out_msg.mh;
	if (len + sizeof(*out_mh) > sizeof(client->out_msg)) {
		snmp_log(LOG_ERR, "can't make message: requested length %d too big\n", len);
		return -SNMPDV_SA_EINVAL;
	}

	in_mh = &client->in_msg.mh;
	memcpy(out_mh, in_mh, sizeof(*out_mh));
	out_mh->len = len;
	out_mh->rc = 0;
	return 0;
}

static void client_make_reply_msg_rc(sa_client *client, unsigned char rc)
{
	snmpdv_sa_msg_hdr *in_mh, *out_mh;

	in_mh = &client->in_msg.mh;
	out_mh = &client->out_msg.mh;
	memcpy(out_mh, in_mh, sizeof(*out_mh));

	out_mh->rc = rc;
	out_mh->len = 0;
}

static int client_send_msg(sa_client *client)
{
	int r;
	size_t len;
	snmpdv_sa_msg_hdr *mh;

	mh = &client->out_msg.mh;
	len = sizeof(*mh) + mh->len;

	/* prepare cs in response */
	mh->cs = SNMPDV_SA_MSG_CS_VALUE;
	mh->cs = SNMPDV_SA_MSG_CS(mh, len);

	r = send(client->socket, mh, len, MSG_NOSIGNAL);

	if (r < 0) {
		snmp_log(LOG_ERR, "client %d: failed to send msg id=%d: %s\n", 
			client->id, mh->msg_id, strerror(errno));
		return r;
	}

	if (r != len) {
		snmp_log(LOG_ERR, "client %d: failed to send msg id=%d completely\n", 
			client->id, mh->msg_id);
		return -1;
	}

	snmp_log(LOG_DEBUG, "client %d: sent msg: length=%d, type=%d, id=%d, data_len=%d\n", 
		client->id, r, mh->msg_type, mh->msg_id, mh->len);
	return 0;
}

static void client_make_reply_msg_mib_name(sa_client *client)
{
	snmpdv_sa_msg_hdr *out_mh;
	int r;
	const char *name = sa_mib_get_mib_name();
	
	if (!name) {
		snmp_log(LOG_ERR, "failed to get MIB name\n");
		client_make_reply_msg_rc(client, SNMPDV_SA_EFAIL);
		return;
	}

	r = client_make_reply_msg(client, strlen(name) + 1);
	if (r) {
		client_make_reply_msg_rc(client, SNMPDV_SA_EFAIL);
		return;
	}

	out_mh = &client->out_msg.mh;
	strcpy(out_mh->data, name);
}

static int client_send_mib_file(sa_client *client)
{
	int r;
	FILE *fp;
	size_t count;

	r = client_make_reply_msg(client, SNMPDV_SA_MAX_LEN_FILE_DATA_CHUNK);
	if (r) {
		client_make_reply_msg_rc(client, SNMPDV_SA_EFAIL);
		return client_send_msg(client);
	}

	fp = sa_mib_file_open(client->id);
	if (!fp) {
		client_make_reply_msg_rc(client, SNMPDV_SA_EFAIL);
		return client_send_msg(client);
	}

	do {
		count = fread(client->out_msg.mh.data, 1, SNMPDV_SA_MAX_LEN_FILE_DATA_CHUNK, fp);

		if (!count && ferror(fp)) {
			/* error, not eof */
			client->out_msg.mh.rc = SNMPDV_SA_EFAIL;
			client->out_msg.mh.len = 0;
			snmp_log(LOG_ERR, "failed to read chunk of MIB-file by client=%d\n", client->id);
			sa_mib_file_close(client->id, fp);
			return client_send_msg(client);
		}

		client->out_msg.mh.len = count;
		r = client_send_msg(client);
		if (r) {
			snmp_log(LOG_ERR, "failed to send chunk of MIB-file to client=%d\n", client->id);
			sa_mib_file_close(client->id, fp);
			return r;
		}
	} while (count > 0);

	sa_mib_file_close(client->id, fp);
	return 0;
}


/* Interface methods */

int sa_clients_init(int max_count)
{
	memset(&c_ctx, 0, sizeof(c_ctx));

	if (max_count < 0) {
		snmp_log(LOG_ERR, "invalid max_count arg = %d\n", max_count);
		return -1;
	}

	c_ctx.max_count = max_count;
	c_ctx.next_id = 1;
	INIT_LLIST_HEAD(&c_ctx.clients);
	return 0;
}

void sa_clients_uninit(void)
{
}

int sa_start_new_client(int socket)
{
	sa_client *client = NULL;
	int r = -1;

	snmp_log(LOG_DEBUG, "starting new client..\n");
	c_ctx.count++;

	do {
		int my_socket;
		my_socket = accept(socket, NULL, NULL);
		if (my_socket < 0) {
			snmp_log(LOG_ERR, "failed to accept connection: %s\n", strerror(errno));
			break;
		}
		
		if (c_ctx.max_count > 0 && c_ctx.count > c_ctx.max_count) {
			snmp_log(LOG_ERR, "client limit exceeded, rejecting\n");
			close(my_socket);
			break;
		}

		client = malloc(sizeof(*client));
		if (!client) {
			snmp_log(LOG_ERR, "failed to alloc client: no memory\n");
			close(my_socket);
			break;
		}
		memset(client, 0, sizeof(*client));
		client->socket = my_socket;
		client->flags.run = 1;
		client->id = c_ctx.next_id++;
		llist_add_tail(&client->list, &c_ctx.clients);
		
		r = pthread_create(&client->thread, NULL, &client_run, client);
		if (r) {
			snmp_log(LOG_ERR, "failed to create client thread: %d(%s)\n", r, strerror(r));
		}
	} while(0);

	/* cleanup on error */
	if (r) {
		client_destroy(client);
		c_ctx.count--;
		c_ctx.next_id--;
	}

	return r;
}

void sa_stop_clients(void)
{
	sa_client *client;
	llist_for_each_entry(client, &c_ctx.clients, list) {
		client->flags.run = 0;
		pthread_kill(client->thread, SIGINT);
	}
}

void sa_cleanup_clients(int wait)
{
	sa_client *client, *tmp;

	llist_for_each_entry_safe(client, tmp, &c_ctx.clients, list) {
		if (client->flags.terminated || wait) {
			pthread_join(client->thread, NULL);
			snmp_log(LOG_DEBUG, "destroying client %d\n", client->id);
			client_destroy(client);
			c_ctx.count--;
		}
	}
}

