#ifndef _SA_CLIENT_H_
#define _SA_CLIENT_H_

extern int sa_clients_init(int max_count);
extern void sa_clients_uninit(void);

extern int sa_start_new_client(int socket);
extern void sa_stop_clients(void);
extern void sa_cleanup_clients(int wait);

#endif /* _SA_CLIENT_H_ */
