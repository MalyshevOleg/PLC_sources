#!/bin/sh

#sudo SNMPCONFPATH=/home/alex/owen/app/dynvar_snmp/subagent ./snmpdv_sa -Le -f

sudo SNMPCONFPATH=/home/alex/owen/app/dynvar_snmp/subagent ./snmpdv_sa 
