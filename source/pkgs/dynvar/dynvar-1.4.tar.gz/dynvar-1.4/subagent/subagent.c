#include <net-snmp/net-snmp-config.h>
#include <net-snmp/net-snmp-includes.h>
#include <net-snmp/agent/net-snmp-agent-includes.h>

#include <pthread.h>
#include <signal.h>
#include <sys/select.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>

#include "sa_client.h"

#include "snmpdv_sa.h"
#include "sa_mib.h"
#include "snmpdv_sa_int.h"

/* in seconds */
#define SA_CLIENT_CLEANUP_TIMEOUT 2

/* type & data definitions */
typedef struct sa_context {
	/* config */
	int max_clients;

	/* state */
	int srv_socket;

	struct {
		/* config flags */
		unsigned stderr: 1;
		unsigned daemon: 1;

		/* state flags */
		unsigned sa_initialized: 1;
		unsigned run: 1;
	} flags;

	pthread_mutex_t agentx_lock;
} sa_context;

static sa_context sa_ctx = {
	.max_clients = 3,

	.flags = {
		.stderr = 0,
		.daemon = 1,
	},
};

/* local methods declarations */
static int parse_args(int argc, char *argv[]);
static int parse_log_option(const char *arg);
static int init_ctl_socket();

static int sa_snmp_init();
static void sa_snmp_uninit();
static int sa_app_init();
static void sa_app_uninit();

static int process_requests();

static void usage()
{
	printf("Use:\n"
		SNMPDV_SA_NAME "[-h] [-L<e|s|f:file>] [-f]\n"
		"\twhere\n"
		"\t-h                print this help and exit\n"
		"\t-L\n"
		"\t    e              log to stderr\n"
		"\t    s              log to syslog with facility LOG_DAEMON\n"
		"\t    f:file         log to specified file <file>\n"
		"\t-f                 don't fork from the shell\n"
		);
}

static void stop_sa(int n)
{
	sa_ctx.flags.run = 0;
}

/* program start */
int main(int argc, char * argv[])
{
	int r;

	snmp_disable_log();

	r = parse_args(argc, argv);
	if (r) {
		usage();
		return r < 0 ? -1: 0;
	}

	if (sa_ctx.flags.daemon) {
		r = netsnmp_daemonize(1, sa_ctx.flags.stderr);
		if (r) {
			return -2;
		}
	}

	snmp_log(LOG_INFO, SNMPDV_SA_NAME " started\n");

	/* catch signals */
	sa_ctx.flags.run = 1;
	signal(SIGINT, stop_sa);
	signal(SIGTERM, stop_sa);

	/* init snmp staff */
	netsnmp_enable_subagent();
	init_agent(SNMPDV_SA_NAME);

	/* init sa-snmp staff*/
	r = sa_snmp_init();
	if (r) {
		shutdown_agent();
		return -3;
	}

	/* init snmp - part 2 */
	init_snmp(SNMPDV_SA_NAME);

	/* initialize sa app data, e.g. mib data, control interface, clients framework */
	r = sa_app_init();
	if (r) {
		/* shutting down */
		snmp_shutdown(SNMPDV_SA_NAME);
		sa_snmp_uninit();
		shutdown_agent();
		return -4;
	}

	snmp_log(LOG_INFO, "running..\n");
	
	/* process requests */
	while (sa_ctx.flags.run) {
		process_requests();
	}

	snmp_log(LOG_INFO, SNMPDV_SA_NAME " finalizing...\n");

	/* shutting down SA app, .. */
	sa_app_uninit();

	/* .. snmp staff */
	snmp_shutdown(SNMPDV_SA_NAME);

	/* .. SA snmp staff */
	sa_snmp_uninit();

	/* .. agent */
	shutdown_agent();

	/* exit */
	return 0;
}

static int parse_log_option(const char *arg)
{
	const char *p;
	/* -L params:
	 * s - via syslog (default facility - daemon)
	 * e - stderr
	 * f:file - to specified file
	 * Ex. -Lef:/tmp/log.txt or -Les
	 */

	p = arg;
	while (*p != 0) {
		if (*p == 'f') {
			/* f can be last arg only becasue it has own arg - filename */
			p++;
			if (*p++ != ':') {
				return -1;
			}
			if (*p == 0) {
				return -1;
			}
			snmp_enable_filelog(p, 0);
			break;
		}
		
		switch (*p) {
			case 's':
				snmp_enable_syslog_ident(SNMPDV_SA_NAME, LOG_DAEMON);
				break;

			case 'e':
				snmp_enable_stderrlog();
				sa_ctx.flags.stderr = 1;
				break;

			default:
				return -1;
		}
		p++;
	}
	return 0;
}

/* local methods implementation */
static int parse_args(int argc, char *argv[])
{
	int opt;
	opterr = 0;

	while ((opt = getopt(argc, argv, "L:fc:h")) != -1) {
		switch (opt) {
			case 'L':
				if (parse_log_option(optarg) != 0) {
					fprintf(stderr, SNMPDV_SA_NAME ": failed to parse log option -L %s\n", optarg);
					return -1;
				}
				break;
				
			case 'f':
				sa_ctx.flags.daemon = 0;
				break;

			case 'c':
				sa_ctx.max_clients = atoi(optarg);
				break;
				
			case 'h':
				return 1;
				break;
			
			case '?':
			default:
				fprintf(stderr, SNMPDV_SA_NAME ": invalid option '%c' or argument missing\n", optopt);
				return -1;
				break;
		} /*switch */
	} /* while */
	
	return 0;
}

static int init_ctl_socket()
{
	int r;
	struct sockaddr_un addr;
	int len;

	unlink(SNMPDV_SA_SOCKET);

	/* open socket */
	sa_ctx.srv_socket = socket(AF_UNIX, SOCK_STREAM, 0);
	if (sa_ctx.srv_socket < 0) {
		snmp_log(LOG_ERR, "failed to open ctl socket: %s\n", strerror(errno));
		return -1;
	}

	/* bind addr */
	addr.sun_family = AF_UNIX;
	memcpy(addr.sun_path, SNMPDV_SA_SOCKET, sizeof(SNMPDV_SA_SOCKET));
	len = sizeof(addr);

	r = bind(sa_ctx.srv_socket, &addr, len);
	if (r) {
		snmp_log(LOG_ERR, "failed to bind ctl socket: %s\n", strerror(errno));
		close(sa_ctx.srv_socket);
		return -1;
	}
	
	/* listen */
	r = listen(sa_ctx.srv_socket, 5);
	if (r) {
		snmp_log(LOG_ERR, "failed to listen on ctl socket: %s\n", strerror(errno));
		close(sa_ctx.srv_socket);
		unlink(SNMPDV_SA_SOCKET);
		return -1;
	}

	return 0;
}

static int sa_snmp_init()
{
	int r;

	snmp_log(LOG_DEBUG, "%s: called\n", __func__);
	
	r = pthread_mutex_init(&sa_ctx.agentx_lock, NULL);
	if (r) {
		snmp_log(LOG_ERR, "failed to init agentx mutex\n");
		return -1;
	}

	r = sa_mib_snmp_init();
	if (r) {
		pthread_mutex_destroy(&sa_ctx.agentx_lock);
		return -1;
	}

	return 0;
}
static void sa_snmp_uninit()
{
	pthread_mutex_destroy(&sa_ctx.agentx_lock);

	snmp_log(LOG_DEBUG, "%s: done\n", __func__);
}

static int sa_app_init()
{
	int r;

	snmp_log(LOG_DEBUG, "%s: called\n", __func__);

	r = sa_mib_init();
	if (r) {
		return -1;
	}

	r = sa_clients_init(sa_ctx.max_clients);
	if (r) {
		sa_mib_uninit();
		return -1;
	}

	r = init_ctl_socket();
	if (r) {
		sa_clients_uninit();
		sa_mib_uninit();
		return -1;
	}

	sa_ctx.flags.sa_initialized = 1;
	return 0;
}
static void sa_app_uninit()
{
	if (sa_ctx.flags.sa_initialized) {
		/* uninit ctl socket */
		close(sa_ctx.srv_socket);
		unlink(SNMPDV_SA_SOCKET);

		sa_stop_clients();
		sa_cleanup_clients(1);
		sa_clients_uninit();
		sa_mib_uninit();
	}
}

static int process_requests()
{
	int nfds;
	fd_set fdset;
	struct timeval timeout = { 0x7fffffff, 0 };
	int fake_block = 0;
	int count;
	int r;

	nfds = 0;
	FD_ZERO(&fdset);
	snmp_select_info(&nfds, &fdset, &timeout, &fake_block);

	FD_SET(sa_ctx.srv_socket, &fdset);
	if (nfds < sa_ctx.srv_socket + 1) {
		nfds = sa_ctx.srv_socket + 1;
	}

	/* non-blocking select - timeout = SA_CLIENT_CLEANUP_TIMEOUT */
	timeout.tv_sec = SA_CLIENT_CLEANUP_TIMEOUT;
	timeout.tv_usec = 0;
	count = select(nfds, &fdset, NULL, NULL, &timeout);

	sa_cleanup_clients(0);
	
	if (count < 0) {
		if (errno == EINTR) {
			snmp_log(LOG_DEBUG, "select interrupted\n");
		} else {
			snmp_log(LOG_ERR, "select: %s\n", strerror(errno));
		}
		return -1;
	}

	if (count) {
		if (FD_ISSET(sa_ctx.srv_socket, &fdset)) {
			sa_start_new_client(sa_ctx.srv_socket);
		}
		
		sa_agentx_lock();
		r = agent_check_and_process(0);
		sa_agentx_unlock();
		
		return r;
	}

	return 0;
}

/* exported functions */
void sa_agentx_lock()
{
	pthread_mutex_lock(&sa_ctx.agentx_lock);
}

void sa_agentx_unlock()
{
	pthread_mutex_unlock(&sa_ctx.agentx_lock);
}

