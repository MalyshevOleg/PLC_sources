#ifndef _SA_MIB_H_
#define _SA_MIB_H_

/* MIB item types */
#define SA_MIT_VARIABLE	0
#define SA_MIT_TRAP			1

/* init snmp staff, e.g. registering config handlers - shoudl be called between init_agent() and init_snmp() */
extern int sa_mib_snmp_init(void);
/* init app data */
extern int sa_mib_init(void);
/* uninit app data */
extern void sa_mib_uninit(void);

extern int sa_mib_add_var(int client_id, snmpdv_sa_msg_hdr* mh);
extern int sa_mib_add_trap(int client_id, snmpdv_sa_msg_hdr* mh);
extern int sa_mib_del_item(int client_id, snmpdv_sa_msg_hdr* mh);

extern const char *sa_mib_get_mib_name(void);

/** Opens shadow MIB-file to read
 * @return FILE * file stream pointer wich can be then read with fread() or fgets() or NULL on error
 */
extern FILE* sa_mib_file_open(int client_id);

/** Closes and removed shadow MIB-file */
extern void sa_mib_file_close(int client_id, FILE *fp);

#endif /* _SA_MIB_H_ */
