/** 
 * @file snmpdv_sa.h
 * @brief Interface of net-snmp subagent for dynamic variables management.
 *
 * Internal interface between net-snmp subagent for dynamic variables management
 * and C Library giving API for user applications.
 *
 * @author Alex Dsugan, Softerra LLC
 * @date 2011-06-14
 */

#ifndef _SNMPDV_SA_H_
#define _SNMPDV_SA_H_

#define SNMPDV_SA_NAME "snmpdv_sa"						/**< SA name */

//#define SA_SOCKET "\0" SA_NAME
#define SNMPDV_SA_SOCKET "/var/run/" SNMPDV_SA_NAME ".socket"	/**< interface unix-socket path */

#define SNMPDV_SA_IF_VERSION	0x010e			/**< SA interface version */

#define SNMPDV_SA_MAX_LEN_VAR_NAME	31		/**< max length of a variable name (w/o terminating 0) */
#define SNMPDV_SA_MAX_LEN_MIB_NAME	31		/**< max length of a name of the supported MIB (w/o terminating 0) */
#define SNMPDV_SA_MAX_LEN_VAR_DESC	255		/**< max length of a variable description (w/o terminating 0) */
#define SNMPDV_SA_MAX_LEN_FPATH		255		/**< max length of path/file (w/o terminating 0) */

#define SNMPDV_SA_MAX_LEN_FILE_DATA_CHUNK 1024		/**< max size of length of MIB-file name */

/** max length of value of string variable (w/o terminating 0), no more than 255.
 * Max value is restricted by DisplayString MIB type and 
 * data type for length of this field - 'unsigned char' 
 */ 
#define SNMPDV_SA_MAX_LEN_VAL_STRING	255

/** max length (for our SA) of value of binary variable (which is ASN.1 OCTET STRING) */
#define SNMPDV_SA_MAX_LEN_VAL_BINARY	0xffff

/** Maximal length of message sent to SA from client (determines SA input buffer size).
 *
 * All request messages consist of:
 * snmpdv_sa_msg_hdr + payload, where 
 * payload is one of:
 *     @li snmpdv_sa_var  + optional (description + 1 char - terminating zero)
 *     @li just var name: SNMPDV_SA_MAX_LEN_VAR_NAME + 1 (for delete operation)
 */
#define SNMPDV_SA_MAX_LEN_REQ_MSG	(sizeof(snmpdv_sa_msg_hdr) + \
										sizeof(snmpdv_sa_var) + \
										SNMPDV_SA_MAX_LEN_VAR_DESC + 1)

/** Maximal length of message sent from SA to client (determines SA output buffer size).
 *
 * All response messages consist of:
 * snmpdv_sa_msg_hdr + payload, where 
 * payload is one of:
 *     @li just MIB-file name: SNMPDV_SA_MAX_LEN_FPATH + 1 (for delete operation)
 *     @li just data chunk contents of max length SNMPDV_SA_MAX_LEN_FILE_DATA_CHUNK
 */
#define SNMPDV_SA_MAX_LEN_RESP_MSG	(sizeof(snmpdv_sa_msg_hdr) + \
										SNMPDV_SA_MAX_LEN_FILE_DATA_CHUNK)

/** Message types/commands to SA, responses have the same types */
enum snmpdv_sa_msg_type {
	SNMPDV_SA_MSG_ADD_VAR	= 1,		/**< Add variable: Payload: snmpdv_sa_var structure, Response: only rc in header */
	SNMPDV_SA_MSG_ADD_TRAP,			/**< Add a trap: Payload:  snmpdv_sa_trap, Response: only rc in header  */
	SNMPDV_SA_MSG_DEL_ITEM,			/**< Delete variable or trap: Payload: zero-terminated string - name of the item, Response: only rc in header */

	/** Get name of MIB supported by the SA: Payload: nothing, Response: rc + zero-termminated string - name 
	 * @note replaced SNMPDV_SA_MSG_GET_MIB_FNAME: if you need good file name just add ".txt" to this name.
	 */
	SNMPDV_SA_MSG_GET_MIB_NAME,

	/** Get MIB file contents: Payload: nothing, sequence of Responses: rc, len, data 
	 * If rc = 0 (OK), see len to know how much data is valid, len = 0 in this case means stop read more - no data left.
	 * Client must read until rc=0 && len=0 - end-of-file
	 */
	SNMPDV_SA_MSG_GET_MIB,

};

/** Supported variable types */
enum snmpdv_sa_var_type {
	SNMPDV_SA_VT_INTEGER		= 1,		/**< Integer32 from SNMPv2-SMI.txt */
	SNMPDV_SA_VT_STRING,				/**< DisplayString from SNMPv2-TC.txt (which is OCTET STRING(0..255)) */
	SNMPDV_SA_VT_BINARY,				/**< OCTET STRING */
//	SNMPDV_SA_VT_FLOAT,				/** @todo: what use for float ? REAL or Float from NET-SNMP-TC.txt or something else */
};

/** Interface error codes: 0 - is success, negative value is error code 
 * @addtogroup sa_err_codes
 * @{
 */
#define SNMPDV_SA_EFAIL		1	/**< any other error */
#define SNMPDV_SA_EINVAL		2	/**< invalid args - incompatibility */
#define SNMPDV_SA_EVERSION	3	/**< invalid version - incompatibility */

/** @} */

/** Acceptable timeout between two parts of a message if it is not received as a whole.
 * If we start receiving a message it can be received incomplete, so we need to recv more.
 * Wait no more than this timeout for the next message part.
 */
#define SNMPDV_SA_MSG_RECV_TIMEOUT_SEC	5

/** Message checksum
 * @see snmpdv_sa_msg_hdr 
 */
#define SNMPDV_SA_MSG_CS_VALUE	0xFACE

/** Message checksum calculating macros
 * Checksum is calculated as XOR of 2-byte words. 
 * If count of bytes in the message is odd, the last word is formed as if the missing byte were 0.
 * Before calculating the checksum 'cs' field of message header is set to SNMPDV_SA_MSG_CS_VALUE,
 * which is then checked on reception.
 * The macros XORs all even bytes and all odd bytes placing them to respective halfs of the result 2-byte word.
 * @param bytes pointer to byte array
 * @param count count of bytes to process
 */
#define SNMPDV_SA_MSG_CS(bytes, count) \
	({	unsigned short cs = 0; \
		unsigned short i;\
		for (i = 0; i < count; i++) ((unsigned char*)&cs)[i & 1] ^= ((unsigned char *)bytes)[i]; \
		cs; \
	})


/** Message/command header 
 *
 * Message is: HEADER(fixed size) + PAYLOAD(var size = header.len)
 */
typedef struct snmpdv_sa_msg_hdr {
	unsigned short version;	/**< interface version control: library and SA should be compiled against the same interface */
	unsigned short msg_id;	/**< just to identify request - response pair */
	unsigned char msg_type;	/**< command - snmpdv_sa_msg_type */
	unsigned char rc;			/**< result code returned by SA: 0 - success, < 0 - error */
	
	/** checksum of the message.
	 * Calculated as XOR of 2-byte words. 
	 * If count of bytes in the message is odd 
	 * the last word is formed as if the missing byte were 0.
	 * Before calculating checksum the 'cs' field is set to SNMPDV_SA_MSG_CS_VALUE 
	 * which is then checked on reception.
	 */
	unsigned short cs;			
	unsigned short len;		/**< length of further payload - can be different respectively to msg_type value */
	char data[];				/**< pointer to payload following the header */
} __attribute__ ((packed)) snmpdv_sa_msg_hdr;

/** Integer variable additional attributes 
 * @todo: min and max are not checked for min <= max
 * @todo: defval is not checked for min, max restrictions
 */
typedef struct snmpdv_sa_var_integer_attr {
	int min;					/**< minimal value */
	int max;					/**< maximal value */
	int defval;				/**< default value if provided */
} __attribute__ ((packed)) snmpdv_sa_var_integer_attr;

/** String variable additional attributes 
 * @todo: defval is not checked for max_len restriction.
 */
typedef struct snmpdv_sa_var_string_attr {
	unsigned char max_len;		/**< max length of the value but not more than 255 */
	char defval[SNMPDV_SA_MAX_LEN_VAL_STRING + 1];	/**< default value if provided */
} __attribute__ ((packed)) snmpdv_sa_var_string_attr;

//typedef struct snmpdv_sa_var_float_attr {
//	float defval;
//} __attribute__ ((packed)) snmpdv_sa_var_float_attr;

/** Binary variable additional attributes */
typedef struct snmpdv_sa_var_binary_attr {
	int max_len;					/**< max length of the value */
} __attribute__ ((packed)) snmpdv_sa_var_binary_attr;

/** Variable additional attributes union */
typedef union snmpdv_sa_var_attr {
	snmpdv_sa_var_integer_attr i;		/**< member for integer variable type */
	snmpdv_sa_var_string_attr s;		/**< member for integer string type */
//	snmpdv_sa_var_float_attr f;
	snmpdv_sa_var_binary_attr b;		/**< member for integer binary type */
} __attribute__ ((packed)) snmpdv_sa_var_attr;

/** Payload for add variable message (client->SA) */
typedef struct snmpdv_sa_var {
	char name[SNMPDV_SA_MAX_LEN_VAR_NAME + 1];		/**< name of the var */
	unsigned char type;								/**< variable type */
	struct {
		unsigned range: 1;							/**< attr contains range/length data */
		unsigned defval: 1;							/**< attr contains default value */
		unsigned desc: 1;								/**< 0: no desc field; 1 - desc field contains zero-terminated description string */
	} flags;
	snmpdv_sa_var_attr attr;							/**< variable type-specific attributes */

	char desc[];										/**< description of the var: zero-terminated string if .flags.desc=1 */
} __attribute__ ((packed)) snmpdv_sa_var;

/** Payload for add trap message (client->SA) */
typedef struct snmpdv_sa_trap {
	char name[SNMPDV_SA_MAX_LEN_VAR_NAME + 1];		/**< name of the var */
	struct {
		unsigned desc: 1;								/**< 0: no desc field; 1 - desc field contains zero-terminated description string */
	} flags;
	char desc[];										/**< description of the var: zero-terminated string if .flags.desc=1 */
} __attribute__ ((packed)) snmpdv_sa_trap;

#endif /* _SNMPDV_SA_H_ */

