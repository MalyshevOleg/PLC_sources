#ifndef _SNMPDV_SA_INT_H_
#define _SNMPDV_SA_INT_H_

extern void sa_agentx_lock();
extern void sa_agentx_unlock();

#endif /* _SNMPDV_SA_INT_H_ */
