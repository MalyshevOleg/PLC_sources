#include <net-snmp/net-snmp-config.h>
#include <net-snmp/net-snmp-includes.h>
#include <net-snmp/agent/net-snmp-agent-includes.h>

#include <pthread.h>
#include <stdio.h>
#include <time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <errno.h>

#include "linux_list.h"

#include "snmpdv_sa.h"
#include "snmpdv_sa_int.h"

#include "sa_mib.h"

/** Names of the options which can be defined in snmpdv_sa.conf 
 *
 * @addtogroup sa_config_options
 * @{
 */

/** Name of a config option which defines Root OID of all items dynamically created by snmpdv_sa subagent.
 *
 * For our case: owenDynvarRootOID 1.3.6.1.4.1.181175.2.2961 which is owenExperimental.2961
 */
#define SA_CONFIG_ROOT_OID "owenDynvarRootOID"

/** Name of a config option which defines Name of the MIB module respective to the rootOID.
 *
 * For our case: owenDynvarRootName owenDynvarMIB 
 * (see template MIB file: owenDynvarMIB MODULE-IDENTITY)
 */
#define SA_CONFIG_ROOT_NAME "owenDynvarRootName"

/** Name of a config option which defines Full path to MIB-file template where Root OID is defined.
 *
 * For our case: owenDynvarMIBFileTpl pathto/OWEN-DYNVAR-MIB.tpl
 */
#define SA_CONFIG_MIB_FILE_TPL "owenDynvarMIBFileTpl" 

/** Name of a config option which defines Name of the MIB supported by the SA
 *
 * For our case: owenDynvarMIBName OWEN-DYNVAR-MIB
 *
 * The name of the MIB is used to refer its variables/traps e.g. snmpget -m OWEN-DYNVAR-MIB ..
 * This MIB name should be defined in the MIB template file, e.g. (1st line):
 *          OWEN-DYNVAR-MIB DEFINITIONS ::= BEGIN
 * Also it is used to build full name of respective MIB-file: OWEN-DYNVAR-MIB.txt
 * SA keeps a copy of current MIB file by the next full path: {SA_CONFIG_RUN_DIR}/{SA_CONFIG_MIB_NAME}.txt
 */
#define SA_CONFIG_MIB_NAME "owenDynvarMIBName" 

/** Name of a config option which defines Path to the dir where SA keeps current actual MIB file and tmp files. 
 * 
 * For our case: owenDynvarRunDir /var/run/snmpdv_sa (which is a default value, defined by SA_DEFAULT_RUN_DIR)
 *
 * @todo think of moving this param handling to main module of the SA
 */
#define SA_CONFIG_RUN_DIR "owenDynvarRunDir"

/** @} */

/** Templates supported in MIB-file template
 * 
 * @addtogroup sa_mib_templates
 * @{
 */
#define SA_MIB_TPL_MARK_CHAR	'@'			/**< template start and stop char: \@TPL_NAME\@ */
#define SA_MIB_TPL_DATE	"CUR_DATE"		/**< template which's substituted with current date in format YYYYMMDDHHmmZ */
#define SA_MIB_TPL_DYNVAR	"DYNAMIC_VARS"	/**< template which's substituted with dynamically defined vars and traps */

/** @} */

#define SA_DEFAULT_RUN_DIR "/var/run/" SNMPDV_SA_NAME
#define SA_MIB_NEXT_OID_INIT_VAL 100
#define SA_MIB_FILE_BUF_SIZE	4096
#define SA_MIB_TMP_FILE_NAME_TPL "snmpdv-sa-mib-%d.tmp"
/* run_dir + 1 for / + sizeof template including terminating 0 - 2 chars %d replaced with max int 10 decimal digits */
#define SA_MIB_TMP_FILE_NAME_SIZE (SNMPDV_SA_MAX_LEN_FPATH + 1 + \
									sizeof(SA_MIB_TMP_FILE_NAME_TPL) - 2 + 10)

typedef struct sa_mib_context {
	/* config params */
	oid root_oid[MAX_OID_LEN];
	size_t root_oid_len;
	char root_name[SNMPDV_SA_MAX_LEN_VAR_NAME + 1];
	char mf_name_tpl[SNMPDV_SA_MAX_LEN_FPATH + 1];		/* full path to MIB file template */

	char mib_name[SNMPDV_SA_MAX_LEN_MIB_NAME + 1];	/* supported MIB name */
	char run_dir[SNMPDV_SA_MAX_LEN_FPATH + 1];			/* SA run dir, where current MIB file and tmp files are placed */
	size_t run_dir_len;									/* length of run dir path string */

	/* state */
	char mf_name[SNMPDV_SA_MAX_LEN_FPATH + 1];			/* full path to current MIB file = <run_dir>/<mib_name>.txt */

	oid next_oid;	/* next oid to assign, is not changed when deleting a var, =1 at start */

	/* Attach var/trap to a list respectively to first char (case insensitive) of its name.
	 * Index is letter 'a'..'z' (z-a+1) and one list for the rest cases< e.g. _ or may be some else?
	 * TODO: which first letter of name could be (whether we need the additional list)?
	 */
	struct llist_head items['z' - 'a' + 1 + 1];
	pthread_mutex_t items_locks['z' - 'a' + 1 + 1];

	struct llist_head all_items;			/* list of all items in chronological order - for tmp MIB file creation */
	pthread_mutex_t all_items_lock;

	pthread_mutex_t mf_lock;		/* resulting MIB file exclusive access () */
	char mf_buf[SA_MIB_FILE_BUF_SIZE];	/* buffer to read/write mib file when creating */
	char mf_date[13 + 1];					/* ExtUTCTime from SNMPv2-SMI.txt: string: YYYYMMDDHHMMZ */
} sa_mib_context;

static sa_mib_context sa_mib_ctx;

typedef struct sa_mib_item {
	struct llist_head list;
	struct llist_head all_items_list;
	unsigned char mit;									/**< MIB item type: all related methods switch between the types */
	char name[SNMPDV_SA_MAX_LEN_VAR_NAME + 1];		/**< name of the item */
	char desc[SNMPDV_SA_MAX_LEN_VAR_DESC + 1];
	oid sub_oid;										/**< item's suboid component additional to common rootoid */
	struct {
		unsigned registered: 1;						/**< creation of the item complete: item can be deleted now */
	} flags;
} sa_mib_item;

typedef union sa_mib_value {
	char s[SNMPDV_SA_MAX_LEN_VAL_STRING + 1];	/* string */

	/** Integer value.
	 * @note on 32bit linux 'long' and 'int' have size 4 bytes, but on 64bit linux 'long' is 8 byte long
	 * snmp api uses 'long' type for integer value, so we need 'long' also in oder to
	 * get successfull size check in mib module's handler
	 */
	long i;
	struct {
		char *data;
		size_t max_len;							/* whole data buffer len */
		size_t len;								/* value len */
	} b;											/* binary */
} sa_mib_value;

typedef struct sa_mib_var {
	sa_mib_item item;								/* should be first field to use as sa_mib_item */

	unsigned char type;
	struct {
		unsigned range: 1;						/**< attr contains range/length data */
		unsigned defval: 1;						/**< attr contains default value */
	} flags;
	snmpdv_sa_var_attr attr;

	sa_mib_value value;
	netsnmp_handler_registration *reginfo;
	netsnmp_watcher_info watcher_info;
} sa_mib_var;

typedef struct sa_mib_trap {
	sa_mib_item item;								/* should be first field to use as sa_mib_item */
} sa_mib_trap;


/* local methods */

static void sa_mib_conf_oidval(const char *key, char *value)
{
	int r;
	
	sa_mib_ctx.root_oid_len = sizeof(sa_mib_ctx.root_oid);
	r = read_objid(value, sa_mib_ctx.root_oid, &sa_mib_ctx.root_oid_len);
	if (!r) {
		sa_mib_ctx.root_oid_len = 0;
		snmp_log(LOG_ERR, "failed to parse %s option's value %s\n", key, value);
		return;
	}

#ifdef DEBUG
	printf("OBJ ID parsed:\n");
	print_objid(sa_mib_ctx.root_oid, sa_mib_ctx.root_oid_len);
#endif
}

static void sa_mib_conf_strval(const char *key, char *value)
{
	size_t len, max_len;
	char *p;

#ifdef DEBUG
	snmp_log(LOG_DEBUG, "called for '%s'\n", key);
#endif

	len = strlen(value);
	if (strcasecmp(SA_CONFIG_MIB_FILE_TPL, key) == 0) {
		max_len = sizeof(sa_mib_ctx.mf_name_tpl) - 1;
		p = sa_mib_ctx.mf_name_tpl;
	} else if (strcasecmp(SA_CONFIG_MIB_NAME, key) == 0) {
		max_len = sizeof(sa_mib_ctx.mib_name) - 1;
		p = sa_mib_ctx.mib_name;
	} else if (strcasecmp(SA_CONFIG_RUN_DIR, key) == 0) {
		max_len = sizeof(sa_mib_ctx.run_dir) - 1;
		p = sa_mib_ctx.run_dir;
	} else if (strcasecmp(SA_CONFIG_ROOT_NAME, key) == 0) {
		max_len = sizeof(sa_mib_ctx.root_name) - 1;
		p = sa_mib_ctx.root_name;
	} else {
		snmp_log(LOG_ERR, "option '%s' is not supported - ignoring\n", key);
		return;
	}

	if (len > max_len) {
		snmp_log(LOG_ERR, "value for %s too long - ignored\n", key);
		return;
	}
	
	strcpy(p, value);
}

static int get_index_of_name(const char *name)
{
	int index;
	char c = *name;

	/* check for the latest index */
	if (!((c >= 'a' && c <= 'z')  || (c >= 'A' && c <= 'Z'))) {
		index = 'z' - 'a' + 1;	/* index begings from 0, so 'z' - 'a' if index of 'z', we need here the additional list's index */
	} else {
		/* so we definitely have a letter a-zA-Z as a first char - transform it to lowcase ( | 0x20) and calc index */
		index = (c | 0x20) - 'a';
	}
	snmp_log(LOG_DEBUG, "name: '%s' - index=%d\n", name, index);
	return index;
}

static int mib_item_new(unsigned char type, sa_mib_item **item)
{
	size_t size;

	if (sa_mib_ctx.root_oid_len > MAX_OID_LEN - 2) {
		snmp_log(LOG_ERR, "Specified Root OID leaves no room for new objects\n");
		return -SNMPDV_SA_EFAIL;
	}

	switch (type) {
		case SA_MIT_VARIABLE:
			size = sizeof(sa_mib_var);
			break;
		case SA_MIT_TRAP:
			size = sizeof(sa_mib_trap);
			break;
		default:
			return -SNMPDV_SA_EINVAL; /* impossible 'cause we call this function */
			break;
	}

	*item = malloc(size);
	if (!*item) {
		snmp_log(LOG_ERR, "failed to alloc MIB item\n");
		return -SNMPDV_SA_EFAIL;
	}
	memset(*item, 0, size);

	(*item)->mit = type;
	(*item)->sub_oid = sa_mib_ctx.next_oid++; //TODO: add overfolow check?
	return 0;
}

static inline void mib_item_set_registration_complete(sa_mib_item *item)
{
	item->flags.registered = 1;
}
static inline int mib_item_is_registration_complete(sa_mib_item *item)
{
	return item->flags.registered ? 1 : 0;
}


static void mib_item_free(sa_mib_item *item)
{
	free(item);
}

/* index can't be NULL!On exit it contains the name's index */
static sa_mib_item *find_item_by_name_locked(const char *name, int *index)
{
	sa_mib_item *item, *tmp, *found_item = NULL;
	int i;

	i = get_index_of_name(name);
	*index = i;

	pthread_mutex_lock(&sa_mib_ctx.items_locks[i]);
	llist_for_each_entry_safe(item, tmp, &sa_mib_ctx.items[i], list) {
		if (!strcmp(name, item->name)) {
			found_item = item;
			break;
		}
	}
	return found_item;
}

static void unlock_items(int index)
{
	pthread_mutex_unlock(&sa_mib_ctx.items_locks[index]);
}

static int mib_file_copy(const char *from, const char *to, size_t *len)
{
	FILE *in, *out;
	size_t count_r, count_w, total = 0;

	pthread_mutex_lock(&sa_mib_ctx.mf_lock);
	in = fopen(from, "r");
	if (!in) {
		pthread_mutex_unlock(&sa_mib_ctx.mf_lock);
		snmp_log(LOG_ERR, "failed read MIB-file '%s'\n", from);
		return -SNMPDV_SA_EFAIL;
	}
	out = fopen(to, "w");
	if (!out) {
		fclose(in);
		pthread_mutex_unlock(&sa_mib_ctx.mf_lock);
		snmp_log(LOG_ERR, "failed read MIB-file '%s'\n", from);
		return -SNMPDV_SA_EFAIL;
	}

	while ((count_r = fread(sa_mib_ctx.mf_buf, 1, sizeof(sa_mib_ctx.mf_buf), in)) > 0) {
		count_w = fwrite(sa_mib_ctx.mf_buf, 1, count_r, out);
		if (count_w != count_r) {
			snmp_log(LOG_ERR, "failed to write MIB-file\n");
			break;
		}
		total += count_w;
	}

	if (len) {
		*len = total;
	}

	if (ferror(in) || ferror(out)) {
		fclose(out);
		fclose(in);
		pthread_mutex_unlock(&sa_mib_ctx.mf_lock);
		snmp_log(LOG_ERR, "error detected on one of streams while copying MIB file\n");
		return -SNMPDV_SA_EFAIL;
	}

	fclose(out);
	fclose(in);
	pthread_mutex_unlock(&sa_mib_ctx.mf_lock);
	snmp_log(LOG_DEBUG, "MIB file '%s' copied to '%s', size=%d bytes\n", 
			from, to, (int)total);
	return 0;
	
}

/* Order is:
	SYNTAX (v,t)
	MAX-ACCESS (v)
	STATUS (v,t)
	DESCRIPTION (v,t)
	DEFVAL { "none" } (v)
*/
static void mib_file_print_item(FILE *fp, sa_mib_item *item)
{
	sa_mib_var *mib_var = (sa_mib_var *)item;
	
	fprintf(fp, "%s %s\n", item->name, 
		item->mit == SA_MIT_VARIABLE ? "OBJECT-TYPE" : "NOTIFICATION-TYPE");

	/* SYNTAX */
	if (item->mit == SA_MIT_VARIABLE) {
		fprintf(fp, "\tSYNTAX");
		switch (mib_var->type) {
			case SNMPDV_SA_VT_INTEGER:
				fprintf(fp, " INTEGER");
				if (mib_var->flags.range) {
					fprintf(fp, " (%d..%d)", 
						mib_var->attr.i.min, mib_var->attr.i.max);
				}
				break;
				
			case SNMPDV_SA_VT_STRING:
				fprintf(fp, " DisplayString");	/* from SNMPv2-TC.txt */
				if (mib_var->flags.range) {
					fprintf(fp, " (SIZE(0..%d))", mib_var->attr.s.max_len);
				}
				break;
				
			case SNMPDV_SA_VT_BINARY:
				fprintf(fp, " OCTET STRING");
				if (mib_var->flags.range) {
					fprintf(fp, " (SIZE(0..%d))", mib_var->attr.b.max_len);
				}
				break;
		}
		fprintf(fp, "\n");
	}

	/* OBJECTS CAN be EMPTY
	if (item->mit == SA_MIT_TRAP) {
		fprintf(fp, "\tOBJECTS { }\n");
	}
	*/

	/* MAX-ACCESS */
	if (item->mit == SA_MIT_VARIABLE) {
		fprintf(fp, "\tMAX-ACCESS read-write\n");
	}

	/* STATUS */
	fprintf(fp, "\tSTATUS current\n");

	/* DESCRIPTION seems can't be absent, so specify it at least as "" */
	fprintf(fp, "\tDESCRIPTION");
	if (item->desc[0] != 0) {
		fprintf(fp, "\n\t\t\"%s\"\n", item->desc);
	} else {
		fprintf(fp, " \"\"\n");
	}

	/* DEFVAL */
	if (item->mit == SA_MIT_VARIABLE && mib_var->flags.defval) {
		switch (mib_var->type) {
			case SNMPDV_SA_VT_INTEGER:
				fprintf(fp, "\tDEFVAL { %d }\n", mib_var->attr.i.defval);
				break;
				
			case SNMPDV_SA_VT_STRING:
				fprintf(fp, "\tDEFVAL { \"%s\" }\n", mib_var->attr.s.defval);
				break;
		}
	} 

	/* OID */
	fprintf(fp, "\t::= { %s %d }\n", sa_mib_ctx.root_name, item->sub_oid);
	fprintf(fp, "\n");
}

static int mib_file_print_template(FILE *tmp, const char *tpl)
{
	if (!strcmp(tpl, SA_MIB_TPL_DATE)) {
		fprintf(tmp, "%s", sa_mib_ctx.mf_date);
		return 0;
	}

	if (!strcmp(tpl, SA_MIB_TPL_DYNVAR)) {
		sa_mib_item *item;

		/* lock all items list */
		pthread_mutex_lock(&sa_mib_ctx.all_items_lock);
		
		/* for each item from all items: print into the file */
		llist_for_each_entry(item, &sa_mib_ctx.all_items, all_items_list) {
			mib_file_print_item(tmp, item);
		}
		
		/* unlock all items */
		pthread_mutex_unlock(&sa_mib_ctx.all_items_lock);
		return 0;
	}
	
	return -1;
}

static void mib_file_set_date()
{
	struct tm tm, *ptm;
	time_t t;
	size_t n;

	t = time(NULL);
	ptm = localtime_r(&t, &tm);
	if (!ptm) {
		snmp_log(LOG_ERR, "failed to get localtime\n");
		strcpy(sa_mib_ctx.mf_date, "201106210001Z"); /* default date */
		return;
	}
	n = strftime(sa_mib_ctx.mf_date, sizeof(sa_mib_ctx.mf_date), "%Y%m%d%H%MZ", &tm);
	if (n != sizeof(sa_mib_ctx.mf_date) - 1) {
		snmp_log(LOG_ERR, "failed format date\n");
		strcpy(sa_mib_ctx.mf_date, "201106210002Z"); /* default date 2 */
		return;
	}
}

/* note:  tmp_fname SHOULD have size = SA_MIB_TMP_FILE_NAME_SIZE */
static void make_mib_tmp_file_name(int client_id, char *tmp_fname)
{
	char *p = tmp_fname;
	strcpy(p, sa_mib_ctx.run_dir);
	p += sa_mib_ctx.run_dir_len;
	*p++ = '/';
	sprintf(p, SA_MIB_TMP_FILE_NAME_TPL, client_id);
}

static int mib_file_update(int client_id)
{
	int r;
	char tmp_fname[SA_MIB_TMP_FILE_NAME_SIZE];
	FILE *tmp, *tpl;
	char line[255];
	char *ps, *pe;

	//open new tmp file for WRITE
	make_mib_tmp_file_name(client_id, tmp_fname);
	tmp = fopen(tmp_fname, "w");
	if (!tmp) {
		snmp_log(LOG_ERR, "failed to create tmp mib file '%s'\n", tmp_fname);
		return -SNMPDV_SA_EFAIL;
	}

	// open template
	tpl = fopen(sa_mib_ctx.mf_name_tpl, "r");
	if (!tpl) {
		fclose(tmp);
		snmp_log(LOG_ERR, "failed to read template mib file '%s'\n", sa_mib_ctx.mf_name_tpl);
		return -SNMPDV_SA_EFAIL;
	}

	mib_file_set_date();

	while (fgets(line, sizeof(line), tpl)) {
		ps = strchr(line, SA_MIB_TPL_MARK_CHAR);
		if (!ps) {
			/* no template, write line as is and continue */
			fputs(line, tmp);
			continue;
		}
		
		/* found template? */
		if (ps != line) {
			fwrite(line, 1, ps - line, tmp);	/* write before MARK */
		}

		/* find end MARK */
		pe = strchr(ps + 1, SA_MIB_TPL_MARK_CHAR);
		if (!pe) {
			/* end MARK was not found, write the rest including first MARK to the file and continue */
			fputs(ps, tmp);
			continue;
		}

		/* second MARK found, subst it with string end marked 0 and process */
		*pe = 0;
		r = mib_file_print_template(tmp, ps + 1);
		/* restore MARK char */
		*pe = SA_MIB_TPL_MARK_CHAR;	
		/* check result of template processing */
		if (r) {
			/* it was not a template, so print the rest including MARKs */
			fputs(ps, tmp);
		} else {
			/* template was substituted, print the rest of line */
			if (*(pe + 1) != 0) {
				fputs(pe + 1, tmp);
			}
		}
		/* continue */
	}

	// close files
	fclose(tpl);
	fclose(tmp);

	/* copy new tmp MIB file to current */
	r = mib_file_copy(tmp_fname, sa_mib_ctx.mf_name, NULL);
	/* remove tmp */
	remove(tmp_fname);
	
	return r;
}

static void mib_item_add_to_common_list(sa_mib_item *item)
{
	/* add to all items list - for MIB */
	pthread_mutex_lock(&sa_mib_ctx.all_items_lock);
	llist_add_tail(&item->all_items_list, &sa_mib_ctx.all_items);
	pthread_mutex_unlock(&sa_mib_ctx.all_items_lock);
}
static void mib_item_del_from_common_list(sa_mib_item *item)
{
	/* remove from all-items list */
	pthread_mutex_lock(&sa_mib_ctx.all_items_lock);
	llist_del(&item->all_items_list);
	pthread_mutex_unlock(&sa_mib_ctx.all_items_lock);
}

static int mib_item_register(sa_mib_item *item)
{
	int index;
	sa_mib_item *it;
	
	/* if item with specified name exists - ret err */
	it = find_item_by_name_locked(item->name, &index);
	if (it) {
		snmp_log(LOG_ERR, "item with name '%s' already registered\n", item->name);
		unlock_items(index);
		return -SNMPDV_SA_EINVAL;
	}

	/* otherwise add it to the list */
	llist_add_tail(&item->list, &sa_mib_ctx.items[index]);
	
	/* unlock, ret OK */
	unlock_items(index);

	return 0;
}

static void mib_item_unregister(sa_mib_item *item)
{
	int index;

	index = get_index_of_name(item->name);

	pthread_mutex_lock(&sa_mib_ctx.items_locks[index]);
	llist_del(&item->list);
	pthread_mutex_unlock(&sa_mib_ctx.items_locks[index]);
	snmp_log(LOG_DEBUG, "item: '%s' detached\n", item->name);
}

static void mib_item_unregister_nolock(sa_mib_item *item)
{
	llist_del(&item->list);
	snmp_log(LOG_DEBUG, "item: '%s' detached\n", item->name);
}

static int mib_item_register_new(unsigned char type, const char *name, 
					const char *desc, sa_mib_item **item)
{
	int r;
	sa_mib_item *it;
	
	r = mib_item_new(type, item);
	if (r) {
		return r;
	}
	it = *item;

	strcpy(it->name, name);
	if (desc) {
		strcpy(it->desc, desc);
	}

	r = mib_item_register(it);
	if (r) {
		mib_item_free(it);
		return r;
	}

	return 0;
}

static int mib_var_data_init(sa_mib_var *mib_var, snmpdv_sa_var *var)
{
	mib_var->type = var->type;
	mib_var->flags.range = var->flags.range;
	mib_var->flags.defval = var->flags.defval;
	memcpy(&mib_var->attr, &var->attr, sizeof(mib_var->attr));

	/* init var's value holder */
	if (mib_var->type == SNMPDV_SA_VT_BINARY) {
		if (mib_var->flags.range) {
			mib_var->value.b.max_len = var->attr.b.max_len;
		} else {
			mib_var->value.b.max_len = SNMPDV_SA_MAX_LEN_VAL_BINARY;
		}
		mib_var->value.b.data = malloc(mib_var->value.b.max_len);
		if (!mib_var->value.b.data) {
			snmp_log(LOG_ERR, "failed to alloc %d bytes for binary var value\n",
				(int)mib_var->value.b.max_len);
			return -SNMPDV_SA_EFAIL;
		}
	}
	
	/* init value with defval */
	if (var->flags.defval) {
		switch (mib_var->type) {
			case SNMPDV_SA_VT_INTEGER:
				mib_var->value.i = var->attr.i.defval;
				break;
			case SNMPDV_SA_VT_STRING:
				strcpy(mib_var->value.s, var->attr.s.defval);
				break;
			case SNMPDV_SA_VT_BINARY:
				break;
		}
	}

	/* init watcher info respective to var type */
	switch (mib_var->type) {
		case SNMPDV_SA_VT_INTEGER:
			netsnmp_init_watcher_info6(&mib_var->watcher_info, 
						&mib_var->value.i, sizeof(mib_var->value.i),
						ASN_INTEGER, WATCHER_MAX_SIZE,
						sizeof(mib_var->value.i), 
						NULL);
			break;
		case SNMPDV_SA_VT_STRING:
			netsnmp_init_watcher_info6(&mib_var->watcher_info, 
						mib_var->value.s, strlen(mib_var->value.s),
						ASN_OCTET_STR, WATCHER_MAX_SIZE,
						(var->flags.range ? var->attr.s.max_len : SNMPDV_SA_MAX_LEN_VAL_STRING), 
						NULL);
			break;
		case SNMPDV_SA_VT_BINARY:
			netsnmp_init_watcher_info6(&mib_var->watcher_info, 
						mib_var->value.b.data, mib_var->value.b.len,
						ASN_OCTET_STR, WATCHER_MAX_SIZE | WATCHER_SIZE_IS_PTR,
						mib_var->value.b.max_len, 
						&mib_var->value.b.len);
			break;
	}
	
#ifdef DEBUG
	snmp_log(LOG_DEBUG, "var '%s' data initialized\n", mib_var->item.name);
#endif

	return 0;
}

static void mib_var_data_free(sa_mib_var *mib_var)
{
	/* free var-type data */
	if (mib_var->type == SNMPDV_SA_VT_BINARY) {
		if (mib_var->value.b.data) {
			free(mib_var->value.b.data);
			mib_var->value.b.data = NULL;
		}
	}
}

static int check_integer_range(struct netsnmp_mib_handler_s *handler,
				struct netsnmp_handler_registration_s *reginfo,
				struct netsnmp_agent_request_info_s *reqinfo,
				struct netsnmp_request_info_s *requests)
{
	snmp_log(LOG_DEBUG, "%s: called: name='%s'\n", __func__, handler->handler_name);

	switch(reqinfo->mode) {
		case MODE_SET_RESERVE1:
			{
				int r, index;
				sa_mib_var *mib_var;

				/* name of handler == var name */
				mib_var = (sa_mib_var *)find_item_by_name_locked(handler->handler_name, &index);
				if (!mib_var) {
					snmp_log(LOG_WARNING, "'%s' var is not found: being unregistered?", handler->handler_name);
					unlock_items(index);
					break;
				}
				r = netsnmp_check_vb_int_range(requests->requestvb, 
											mib_var->attr.i.min, 
											mib_var->attr.i.max);
				/* var can't be deleted inside locks */
				unlock_items(index);
				
				if (r != SNMP_ERR_NOERROR) {
					netsnmp_set_request_error(reqinfo, requests, r);
				}
			}
			break;
	}
	return SNMP_ERR_NOERROR;
}

/* note: on exit reginfo NULL if not registered, !NULL if registered */
static int mib_var_snmp_register(sa_mib_var *mib_var)
{
	int r;
	oid var_oid[MAX_OID_LEN];
	Netsnmp_Node_Handler *handler = NULL;

	/* build var fulll OID */
	memcpy(var_oid, sa_mib_ctx.root_oid, sizeof(oid) * sa_mib_ctx.root_oid_len);
	var_oid[sa_mib_ctx.root_oid_len] = mib_var->item.sub_oid;

#ifdef DEBUG
	printf("creating reginfo for var: '%s':\n", mib_var->item.name);
	print_objid(var_oid, sa_mib_ctx.root_oid_len + 1);
#endif

	if (mib_var->type == SNMPDV_SA_VT_INTEGER && mib_var->flags.range) {
		handler = &check_integer_range;
	}
		
	mib_var->reginfo = netsnmp_create_handler_registration(mib_var->item.name, 
								handler,
								var_oid, sa_mib_ctx.root_oid_len + 1,
								HANDLER_CAN_RWRITE);
	if (!mib_var->reginfo) {
		snmp_log(LOG_ERR, "failed to create reginfo for var '%s'\n", mib_var->item.name);
		return -SNMPDV_SA_EFAIL;
	}

	sa_agentx_lock();
	r = netsnmp_register_watched_scalar(mib_var->reginfo, &mib_var->watcher_info);
	sa_agentx_unlock();

	if (r != MIB_REGISTERED_OK) {
		netsnmp_handler_registration_free(mib_var->reginfo);
		mib_var->reginfo = NULL;
		snmp_log(LOG_ERR, "failed to register new snmp var '%s'\n", mib_var->item.name);
		return -SNMPDV_SA_EFAIL;
	}

	return 0;
}

static void mib_var_snmp_unregister(sa_mib_var *mib_var)
{
#ifdef DEBUG
	snmp_log(LOG_DEBUG, "unregistering var: '%s'\n", mib_var->item.name);
#endif

	if (mib_var->reginfo) {
		sa_agentx_lock();
		netsnmp_unregister_handler(mib_var->reginfo);
		sa_agentx_unlock();
		mib_var->reginfo = NULL;
	}
}

static void mib_item_destroy(sa_mib_item *item)
{
	mib_item_del_from_common_list(item);

	switch (item->mit) {
		case SA_MIT_VARIABLE:
			/* safe to call - reginfo is NULL(checked) or initialized */
			mib_var_snmp_unregister((sa_mib_var *)item);
			/* safe to call: data is NULL(checked) or initialized */
			mib_var_data_free((sa_mib_var *)item);
			break;
		case SA_MIT_TRAP:
			break;
		default:
			snmp_log(LOG_WARNING, "item: '%s' has unknown type\n", item->name);
			break;
	}

	snmp_log(LOG_DEBUG, "item: '%s' freed\n", item->name);
	mib_item_free(item);
}

static int ensure_run_parent_dir()
{
	snmp_log(LOG_DEBUG, "%s: run dir parent: '%s'\n", __func__, sa_mib_ctx.run_dir);

	if (mkdir(sa_mib_ctx.run_dir, 0660) == 0) {
		return 0;
	}
	
	/* some error */
	if (errno == EEXIST) {
		/* give it a chance: is it a dir? */
		struct stat sbuf;
		if (stat(sa_mib_ctx.run_dir, &sbuf)) {
			snmp_log(LOG_ERR, "fail to stat run dir parent '%s'\n", sa_mib_ctx.run_dir);
			return -1;
		}
		if (!S_ISDIR(sbuf.st_mode)) {
			return -1;
		}
	}
	return 0;
}

static int ensure_run_dir()
{
	int r = 0;
	char *p;

	p = sa_mib_ctx.run_dir;

	do {
		/* skip all first / */
		while (*p == '/') p++;

		/* so now *p is not / */
		if (!*p) {
			break;	/* root dir or end of path - exists */
		}

		p = strchr(p, '/');
		if (!p) {
			/* last dir to check */
			r = ensure_run_parent_dir();
			break;
		}

		*p = 0;	/* temporarily terminate path here and ensure this parent dir existence */
		r = ensure_run_parent_dir();
		*p = '/';	/* restore / */
		if (r) {
			break; /*failure */
		}
	} while (1);

	return r;
}

/* interface methods */

int sa_mib_snmp_init(void)
{
	snmp_log(LOG_DEBUG, "%s: called\n", __func__);

	/* init context with (0 strings) */
	memset(&sa_mib_ctx, 0, sizeof(sa_mib_ctx));

	/* register config vars handlers */
	snmpd_register_config_handler(SA_CONFIG_ROOT_OID, 
					sa_mib_conf_oidval, NULL, "snmpdv_sa config");
	snmpd_register_config_handler(SA_CONFIG_ROOT_NAME,
					sa_mib_conf_strval, NULL, "snmpdv_sa config");
	snmpd_register_config_handler(SA_CONFIG_MIB_FILE_TPL,
					sa_mib_conf_strval, NULL, "snmpdv_sa config");
	snmpd_register_config_handler(SA_CONFIG_MIB_NAME,
					sa_mib_conf_strval, NULL, "snmpdv_sa config");
	snmpd_register_config_handler(SA_CONFIG_RUN_DIR,
					sa_mib_conf_strval, NULL, "snmpdv_sa config");

	return 0;
}

int sa_mib_init(void)
{
	int i, count, r;
	snmp_log(LOG_DEBUG, "%s: called\n", __func__);
	size_t len, mib_name_len;
	char *p;

	/* process configuration which may be parsed */

	/* check values */
	if (!sa_mib_ctx.root_oid_len) {
		snmp_log(LOG_ERR, "no value for config option %s\n", SA_CONFIG_ROOT_OID); 
		return -1;
	}
	if (!sa_mib_ctx.root_name[0]) {
		snmp_log(LOG_ERR, "no value for config option %s\n", SA_CONFIG_ROOT_NAME); 
		return -1;
	}
	if (!sa_mib_ctx.mf_name_tpl[0]) {
		snmp_log(LOG_ERR, "no value for config option %s\n", SA_CONFIG_MIB_FILE_TPL); 
		return -1;
	}
	if (!sa_mib_ctx.mib_name[0]) {
		snmp_log(LOG_ERR, "no value for config option %s\n", SA_CONFIG_MIB_NAME); 
		return -1;
	}
	if (!sa_mib_ctx.run_dir[0]) {
		snmp_log(LOG_NOTICE, "no value for config option %s, using default: %s\n", 
				SA_CONFIG_RUN_DIR, SA_DEFAULT_RUN_DIR); 
		strcpy(sa_mib_ctx.run_dir, SA_DEFAULT_RUN_DIR);
	}
	sa_mib_ctx.run_dir_len = strlen(sa_mib_ctx.run_dir);

	/* make actual MIB file name = run_dir / mib_name .txt */
	mib_name_len = strlen(sa_mib_ctx.mib_name);
	len = sa_mib_ctx.run_dir_len + 1 + mib_name_len + 4; /* 1 - "/", 4 - ".txt" */
	if (len + 1 > sizeof(sa_mib_ctx.mf_name)) {
		snmp_log(LOG_ERR, "result full MIB file path is too long (reduce run dir path or MIB name length)\n"); 
		return -1;
	}
	p = sa_mib_ctx.mf_name;
	strcpy(p, sa_mib_ctx.run_dir);
	p += sa_mib_ctx.run_dir_len;
	*p++ = '/';
	strcpy(p, sa_mib_ctx.mib_name);
	p += mib_name_len;
	strcpy(p, ".txt");
	snmp_log(LOG_DEBUG, "using full MIB file path: %s\n", sa_mib_ctx.mf_name); 

	/* make sure at startup that run dir exists */
	r = ensure_run_dir();
	if (r) {
		return -1;
	}

	/* init rest data */
	
	sa_mib_ctx.next_oid = SA_MIB_NEXT_OID_INIT_VAL;

	r = pthread_mutex_init(&sa_mib_ctx.mf_lock, NULL);
	if (r) {
		snmp_log(LOG_ERR, "failed to init mib file mutex\n");
		return -1;
	}

	INIT_LLIST_HEAD(&sa_mib_ctx.all_items);
	r = pthread_mutex_init(&sa_mib_ctx.all_items_lock, NULL);
	if (r) {
		snmp_log(LOG_ERR, "failed to init all items list mutex\n");
		pthread_mutex_destroy(&sa_mib_ctx.mf_lock);
		return -1;
	}

	count = sizeof(sa_mib_ctx.items)/sizeof(sa_mib_ctx.items[0]);
	for (i = 0; i < count; i++) {
		INIT_LLIST_HEAD(&sa_mib_ctx.items[i]);
		r = pthread_mutex_init(&sa_mib_ctx.items_locks[i], NULL);
		if (r) {
			snmp_log(LOG_ERR, "failed to init items list mutex\n");
			for (i = i - 1; i > 0; i--) {
				pthread_mutex_destroy(&sa_mib_ctx.items_locks[i]);
			}
			pthread_mutex_destroy(&sa_mib_ctx.all_items_lock);
			pthread_mutex_destroy(&sa_mib_ctx.mf_lock);
			return -1;
		}
	}

	/* create initial MIB-file at start-up */
	r = mib_file_update(0);
	if (r) {
		return -1;
	}
	
	return 0;
}

void sa_mib_uninit(void)
{
	sa_mib_item *item, *tmp;
	int i, count;

	/* remove MIB-file on exit */
	remove(sa_mib_ctx.mf_name);

	count = sizeof(sa_mib_ctx.items)/sizeof(sa_mib_ctx.items[0]);
	for (i = 0; i < count; i++) {
		llist_for_each_entry_safe(item, tmp, &sa_mib_ctx.items[i], list) {
			mib_item_destroy(item);
		}
		pthread_mutex_destroy(&sa_mib_ctx.items_locks[i]);
	}
	pthread_mutex_destroy(&sa_mib_ctx.all_items_lock);
	pthread_mutex_destroy(&sa_mib_ctx.mf_lock);
}

int sa_mib_add_var(int client_id, snmpdv_sa_msg_hdr* mh)
{
	snmpdv_sa_var *var;
	sa_mib_var *mib_var;
	sa_mib_item *item;
	int r;
	const char *desc = NULL;

#ifdef DEBUG
	snmp_log(LOG_DEBUG, "%s: called\n", __func__);
#endif

	var = (snmpdv_sa_var *)(mh->data);
	if (var->flags.desc) {
		desc = var->desc;
	}

	r = mib_item_register_new(SA_MIT_VARIABLE, var->name, desc, &item);
	if (r) {
		return r;
	}

	mib_item_add_to_common_list(item);

	mib_var = (sa_mib_var *)item;

	r = mib_var_data_init(mib_var, var);
	if (r) {
		mib_item_unregister(item);
		mib_item_destroy(item);
		return r;
	}

	r = mib_var_snmp_register(mib_var);
	if (r) {
		mib_item_unregister(item);
		mib_item_destroy(item);
		return r;
	}

#ifdef DEBUG
	snmp_log(LOG_DEBUG, "var '%s': watched scalar registered\n", mib_var->item.name);
#endif

	r = mib_file_update(client_id);
	if (r) {
		mib_item_unregister(item);
		mib_item_destroy(item);
		return r;
	}

#ifdef DEBUG
	snmp_log(LOG_DEBUG, "var '%s': added\n", mib_var->item.name);
#endif
	mib_item_set_registration_complete(item);
	return 0;
}

int sa_mib_add_trap(int client_id, snmpdv_sa_msg_hdr* mh)
{
	snmpdv_sa_trap *trap;
	sa_mib_item *item;
	int r;
	const char *desc = NULL;

	trap = (snmpdv_sa_trap *)(mh->data);
	if (trap->flags.desc) {
		desc = trap->desc;
	}

	r = mib_item_register_new(SA_MIT_TRAP, trap->name, desc, &item);
	if (r) {
		return r;
	}

	mib_item_add_to_common_list(item);

	r = mib_file_update(client_id);
	if (r) {
		mib_item_unregister(item);
		mib_item_destroy(item);
		return r;
	}

	mib_item_set_registration_complete(item);
	return 0;
}

int sa_mib_del_item(int client_id, snmpdv_sa_msg_hdr* mh)
{
	int index;
	sa_mib_item *item;

	snmp_log(LOG_DEBUG, "called for item: '%s'\n", mh->data);

	/* search for the item */
	item = find_item_by_name_locked(mh->data, &index);
	if (!item || !mib_item_is_registration_complete(item)) {
		snmp_log(LOG_ERR, "item with name '%s' not found\n", mh->data);
		unlock_items(index);
		return -SNMPDV_SA_EINVAL;
	}

	mib_item_unregister_nolock(item);
	unlock_items(index);

	mib_item_destroy(item);

	/* ignore result of update: anyway we won't guarantee a correct rollback - 
	 * the item is unregistered and another item with the same name may be already registered.
	 * TODO: think again about possible failure..
	 */
	mib_file_update(client_id);
	return 0;
}

const char *sa_mib_get_mib_name(void)
{
	return sa_mib_ctx.mib_name;
}

FILE* sa_mib_file_open(int client_id)
{
	char tmp_fname[SA_MIB_TMP_FILE_NAME_SIZE];
	FILE *fp;
	int r;

	make_mib_tmp_file_name(client_id, tmp_fname);

	/* copy current MIB file to tmp */
	r = mib_file_copy(sa_mib_ctx.mf_name, tmp_fname, NULL);
	if (r) {
		return NULL;
	}

	/* open tmp for READ */
	fp = fopen(tmp_fname, "r");
	if (!fp) {
		snmp_log(LOG_ERR, "failed to read shadow MIB-file '%s'\n", tmp_fname);
		return NULL;
	}
	return fp;
}

void sa_mib_file_close(int client_id, FILE *fp)
{
	char tmp_fname[SA_MIB_TMP_FILE_NAME_SIZE];
	make_mib_tmp_file_name(client_id, tmp_fname);
	/* close tmp after read it and sent to the client */
	fclose(fp);
	/* cleanup */
	remove(tmp_fname);
}

