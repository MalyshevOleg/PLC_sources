#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

#include "lsnmpdv.h"

#include "version.h"
#include "log.h"
int log_level = LEVEL_INFO;

#define APP_OP_ADD_ITEM		1
#define APP_OP_DEL_ITEM		2
#define APP_OP_CREATE_MIB		3
#define APP_OP_GET_MIB_NAME		4

#define APP_IT_TRAP		0

#define APP_IT_INTEGER	1
#define APP_IT_STRING	2
#define APP_IT_BINARY	3

typedef struct app_context {
	/* config */
	int op;
	int item_type;
	const char *item_name;
	const char *item_desc;

	int min;
	int max;		/* used as max_len as well (for string nad binary) */

	int def_int;

	const char *def_str;

	struct {
		unsigned range: 1;
		unsigned defval: 1;
	} int_flags;	/* flags for integer value */

	const char *mib_fname;

	/* state */
	lsnmpdv *inst;
} app_context;

static app_context ctx;

static void usage()
{
	printf("Use:\n"
		APP_NAME "-a name [-t type] [-C comment] [-R range] [-D defval] [-hv] or\n"
		APP_NAME "-d name [-hv] or\n"
		APP_NAME "-m [-hv] or\n"
		APP_NAME "-M file [-hv] or\n"
		"\twhere\n"
		"\t-h            print this help and exit\n"
		"\t-v            increase log level (can be specified multiple times)\n"
		"\t-a name       add item\n"
		"\t-t type       item type: i,s(default),b - var(integer, string, binary), \n"
		"                                      t - trap\n"
		"\t-C comment item comment/description\n"
		"\t-R range      range is \n"
		"\t   type i          min:max -minimal and maximal value\n"
		"\t   type s,b        max_len -maximal length of value\n"
		"\t-D defval     default value (for i or s type)\n"
		"\n"
		"\t-d name       delete item with given name\n"
		"\n"
		"\t-m            get from SA MIB-file name\n"
		"\n"
		"\t-M file       file name of the current MIB-file to create\n"
		);
}

int parse_args(int argc, char *argv[])
{
	int opt;
	opterr = 0;
	char range[32];
	int is_range = 0;
	size_t len;
	const char *defval = NULL;

	/* set defaults */
	memset(&ctx, 0, sizeof(ctx));
	ctx.item_type = APP_IT_STRING;

	/* process args */
	while ((opt = getopt(argc, argv, "a:t:C:R:D:d:mM:hv")) != -1) {
		switch (opt) {
			case 'a':
			case 'd':
				if (ctx.op) {
					pr_err("only one operation is allowed\n");
					return -1;
				}
				
				ctx.item_name = optarg;
				if (opt == 'a') {
					ctx.op = APP_OP_ADD_ITEM;
				} else {
					ctx.op = APP_OP_DEL_ITEM;
				}
				break;

			case 't':
				switch (*optarg) {
					case 'i':
						ctx.item_type = APP_IT_INTEGER;
						break;
					case 's':
						ctx.item_type = APP_IT_STRING;
						break;
					case 'b':
						ctx.item_type = APP_IT_BINARY;
						break;
					case 't':
						ctx.item_type = APP_IT_TRAP;
						break;
					default:
						pr_err("invalid item type '%c'\n", optopt);
						return -1;
						break;
				}
				break;

			case 'C':
				ctx.item_desc = optarg;
				break;

			case 'R':
				len = strlen(optarg);
				if (len > sizeof(range) - 1) {
					len = sizeof(range) - 1;
					pr_notice("-R option value truncated by %d chars\n", (int)len);
				}
				memcpy(range, optarg, len);
				range[len] = 0;
				is_range = 1;
				break;
				
			case 'D':
				defval = optarg;
				break;

			case 'm':
				if (ctx.op) {
					pr_err("only one operation is allowed\n");
					return -1;
				}
				ctx.op = APP_OP_GET_MIB_NAME;
				break;
				
			case 'M':
				if (ctx.op) {
					pr_err("only one operation is allowed\n");
					return -1;
				}
				ctx.mib_fname = optarg;
				ctx.op = APP_OP_CREATE_MIB;
				break;
				
			case 'h':
				return 1;
				break;

			case 'v':
				log_level++;
				break;
			
			case '?':
			default:
				pr_err("invalid option '%c' or argument missing\n", optopt);
				return -1;
				break;
		} /*switch */
	} /* while */

	if (!ctx.op) {
		pr_err("operation is not defined\n");
		return -1;
	}

	if (is_range) {
		switch (ctx.item_type) {
			case APP_IT_INTEGER:
				{
					char *p = strchr(range, ':');
					if (p) {
						*p++ = 0;
					}
					ctx.min = atoi(range);
					if (p) {
						ctx.max = atoi(p);
					}
				}
				ctx.int_flags.range = 1;
				break;
				
			case APP_IT_STRING:
			case APP_IT_BINARY:
				ctx.max = atoi(range);
				/* do not check validness of the value, let us test library's verification */
				break;
				
			default:
				pr_notice("-R option is not applicable for selected item type - ignoring\n");
				break;
		}
	}

	if (defval) {
		switch (ctx.item_type) {
			case APP_IT_INTEGER:
				ctx.def_int = atoi(defval);
				ctx.int_flags.defval = 1;
				break;

			case APP_IT_STRING:
				ctx.def_str = defval;
				break;

			default:
				pr_notice("-D option is not applicable for selected item type - ignoring\n");
				break;
		}
	}
	
	return 0;
}

int main(int argc, char *argv[])
{
	int r;
	lsnmpdv_var_integer_attr int_attr, *pattr = NULL;

	r = parse_args(argc, argv);
	if (r != 0) {
		usage();
		return r < 0 ? r : 0;
	}

	ctx.inst = lsnmpdv_open();
	if (!ctx.inst) {
		pr_err("failed to open lib\n");
		return -1;
	}
	pr_debug("lib opened: inst=%p\n", ctx.inst);

	switch (ctx.op) {
		case APP_OP_ADD_ITEM:
			if (ctx.item_type == APP_IT_TRAP) {
				r = lsnmpdv_add_trap(ctx.inst, ctx.item_name, ctx.item_desc);
				break;
			}

			pr_debug("adding item: type=%d\n", ctx.item_type);
			switch (ctx.item_type) {
				case APP_IT_INTEGER:
					if (ctx.int_flags.range || ctx.int_flags.defval) {
						/* use attrs */
						int_attr.flags.range = ctx.int_flags.range;
						int_attr.flags.defval = ctx.int_flags.defval;

						if (ctx.int_flags.range) {
							int_attr.min = ctx.min;
							int_attr.max = ctx.max;
						}
						if (ctx.int_flags.defval) {
							int_attr.defval = ctx.def_int;
						}
						pattr = &int_attr;
					}
					r = lsnmpdv_add_var_integer(ctx.inst, ctx.item_name, 
										ctx.item_desc, pattr);
					break;

				case APP_IT_STRING:
					pr_debug("adding string var: name='%s', desc='%s', max=%d, defval='%s'\n", 
						ctx.item_name, ctx.item_desc, ctx.max, ctx.def_str);
					r = lsnmpdv_add_var_string(ctx.inst, ctx.item_name, 
										ctx.item_desc, ctx.max, ctx.def_str);
					pr_debug("r=%d\n", r);
					break;
					
				case APP_IT_BINARY:
					r = lsnmpdv_add_var_binary(ctx.inst, ctx.item_name, 
											ctx.item_desc, ctx.max);
					break;
			}
			break;
			
		case APP_OP_DEL_ITEM:
			r = lsnmpdv_del_item(ctx.inst, ctx.item_name);
			break;
			
		case APP_OP_GET_MIB_NAME:
			{
				char *buf = NULL;
				size_t buf_size = 0;
				r = lsnmpdv_get_mib_file_name(ctx.inst, buf, &buf_size);
				if (!r) {
					pr_err("unexpected result!\n");
					break;
				}

				if (r == -LSNMPDV_EINVAL && buf_size > 0) {
					buf = malloc(buf_size);
					if (!buf) {
						pr_err("failed to alloc buffer for MIB file name\n");
						break;
					}
					r = lsnmpdv_get_mib_file_name(ctx.inst, buf, &buf_size);
					if (!r) {
						pr_info("MIB-file name: '%s'\n", buf);
					}
					r = lsnmpdv_get_mib_name(ctx.inst, buf, &buf_size);
					if (!r) {
						pr_info("MIB name: '%s'\n", buf);
					}
				} else {
					pr_err("getting MIB file name failed: r=%d, buf_size=%d\n", r, (int)buf_size);
				}
			}
			break;

		case APP_OP_CREATE_MIB:
			r = lsnmpdv_create_mib_file(ctx.inst, ctx.mib_fname);
			break;
			
		default:
			pr_info("nothing to do, exiting\n");
			lsnmpdv_close(ctx.inst);
			return 0;
			break;
	}

	pr_info("operation result: %d\n", r);
#if 0		
	for (i = 0; i < 30; i++) {
		printf(PFX "inst: %p: iteration %d\n", ctx.inst, i);
		sleep(1);
	}
#endif
	lsnmpdv_close(ctx.inst);
	
	return 0;
}

