=============================================================
NAMES
=============================================================
--------
Subagent
--------

daemon:					snmpdv_sa
interface (for library):		snmpdv_sa.h:
					snmpdv_sa_XXXX

internal:
					sa_XXX

--------
Library
--------
library:				libsnmpdv.so
interface (for app, top-level libs):	lsnmpdv.h:
					lsnmpdv *inst
					lsnmpdv_XXX
return codes:
	0 - success
	< 0 - codes are in lsnmpdv.h

internal:
					snmpdv_XXX

=============================================================
Protocol:
 - client sends a message with id
 - server checks protocol version and
    - rejects, waits for correct message | sends response with RC and same message id?
    - processes it and sends response message with the same id
 - client checks protocol version
 - client checks message id and 
    - rejects, waits for correct answer
    - processes it, returns rc
    - processes it and waits more parts ***
    
=============================================================

=============================================================
TODO:
=============================================================
- limit clients: how to make an odd client get ERR as result
  of its connect() call?

