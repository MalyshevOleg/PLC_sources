#ifndef _LOG_H_
#define _LOG_H_

#define PFX "[lsnmpdv]: "

#define pr_err(fmt, ...) \
	do {\
		fprintf(stderr, PFX "Error: " fmt, ##__VA_ARGS__);\
	} while(0)

#ifdef DEBUG
#define pr_debug(fmt, ...) \
	do {\
		printf(PFX "%s: " fmt, __func__, ##__VA_ARGS__);\
	} while(0)
#else
#define pr_debug(fmt, ...)
#endif

#endif /* _LOG_H_ */
