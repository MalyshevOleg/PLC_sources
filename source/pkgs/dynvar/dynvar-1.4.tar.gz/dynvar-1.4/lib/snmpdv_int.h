#ifndef _SNMPDV_INT_H_
#define _SNMPDV_INT_H_

#include <stdlib.h>
#include "log.h"
#include "snmpdv_sa.h"

struct lsnmpdv {
	int srv_socket;

	union {
		char raw[SNMPDV_SA_MAX_LEN_RESP_MSG];
		snmpdv_sa_msg_hdr mh;
	} in_msg;					/* receive  buffer, corresponds to output buffer of SA */
	union {
		char raw[SNMPDV_SA_MAX_LEN_REQ_MSG];
		snmpdv_sa_msg_hdr mh;
	} out_msg;					/* send buffer, corresponds to input buffer of SA  */
};

extern int snmpdv_recv_msg(struct lsnmpdv *inst);
extern int snmpdv_make_msg(struct lsnmpdv *inst, unsigned char type, unsigned short len);
extern int snmpdv_send_msg(struct lsnmpdv *inst);
extern int snmpdv_response_rc(struct lsnmpdv *inst);

#endif /* _SNMPDV_INT_H_ */

