/** 
 * @file lsnmpdv.h
 * @brief API of the library to work with SNMP dynamic variables.
 *
 * C Library which provides interface to net-snmp
 * sub agent which allows to create/delete snmp variables 
 * dynamically.
 *
 * @author Alex Dsugan, Softerra LLC
 * @date 2011-06-14
 *
 * @todo: when adding vars (int, string) min,max,defval,max_len restrictions are not validated
 */

#ifndef _LSNMPDV_H_
#define _LSNMPDV_H_

/** Interface error codes: 0 - is success, negative value is error code 
 * @addtogroup lib_err_codes
 * @{
 */
#define LSNMPDV_EFAIL		1	/**< any other system error */
#define LSNMPDV_EINVAL		2	/**< invalid args */
#define LSNMPDV_ENOMEM	3	/**< memory allocation failure */
#define LSNMPDV_ECONN		4	/**< broken pipe; peer closed connection */
#define LSNMPDV_ETIMEOUT	5	/**< timeout when getting answer, like ECONN but repeat request is possible */

#define LSNMPDV_EPROTO		6	/**< subagent response version is wrong or subagent failed to process due to library-SA incompatibility */
#define LSNMPDV_ESA		7	/**< subagent failed to process due to internal error e.g. lack of memory */

/** @} */

/** Opaque library instance handle */
typedef struct lsnmpdv lsnmpdv;

/** Initialize library instance (open connection to SA, alloc data, etc). */
extern lsnmpdv* lsnmpdv_open(void);

/** Destroy library instance (free memory, close connections etc). 
 * @param inst instance pointer returned by @ref snmpdv_open()
 */
extern void lsnmpdv_close(lsnmpdv *inst);

/** Attributes of an interger variable. */
typedef struct lsnmpdv_var_integer_attr {
	int min;					/**< minimal value */
	int max;					/**< maximal value */
	int defval;				/**< default value */
	struct {
		unsigned range: 1;	/**< use min and max values */
		unsigned defval: 1;	/**< use default value */
	} flags;
} lsnmpdv_var_integer_attr;

/** Add an INTEGER variable.
 *
 * @param name a new variable's name (max length is SNMPDV_SA_MAX_LEN_VAR_NAME).
 * @param desc a short description (max length is SNMPDV_SA_MAX_LEN_VAR_DESC). NULL is possible.
 * @param attr variable attributes, e.g. range and/or default value. NULL is possible value.
 * @return 0 on success or negative value as an @ref errcodes "error code".
 * @note desc value is cut to its max possible length as need,
 *          whereas too long name value produces an error.
 */
extern int lsnmpdv_add_var_integer(lsnmpdv *inst, const char *name, const char *desc, 
							lsnmpdv_var_integer_attr *attr);

/** Add a DisplayString (from SNMPv2-TC.txt) variable.
 *
 * @param name a new variable's name (max length is SNMPDV_SA_MAX_LEN_VAR_NAME).
 * @param desc a short description (max length is SNMPDV_SA_MAX_LEN_VAR_DESC). NULL is possible.
 * @param max_len max length of the string. If <= 0 - ignored, > SNMPDV_SA_MAX_LEN_VAL_STRING set to SNMPDV_SA_MAX_LEN_VAL_STRING.
 *              (Max value of this param is restricted by DisplayString MIB type and by data type for length of this field - 'unsigned char')
 * @param defval default value of the variable. NULL is possible - means no defval.
 * @return 0 on success or negative value as an @ref errcodes "error code".
 * @note desc and defval values are cut to max possible length if they are too long,
 *          whereas too long name value produces an error.
 */
extern int lsnmpdv_add_var_string(lsnmpdv *inst, const char *name, 
								const char *desc, int max_len, const char *defval);

/** Add an binary (OCTET STRING) variable.
 *
 * @param name a new variable's name (max length is SNMPDV_SA_MAX_LEN_VAR_NAME)
 * @param desc a short description (max length is SNMPDV_SA_MAX_LEN_VAR_DESC). NULL is possible.
 * @param max_len max length of the binary variable value. If <=0 - ignored.
 * @return 0 on success or negative value as an @ref errcodes "error code"
 * @note desc value is cut to its max possible length as need,
 *          whereas too long name value produces an error.
 */
extern int lsnmpdv_add_var_binary(lsnmpdv *inst, const char *name, 
									const char *desc, int max_len);

/** Add a new notification with given name  
 *
 * @param name a new trap's name (max length is SNMPDV_SA_MAX_LEN_VAR_NAME)
 * @param desc a short description (max length is SNMPDV_SA_MAX_LEN_VAR_DESC). NULL is possible.
 */
extern int lsnmpdv_add_trap(lsnmpdv *inst, const char *name, const char *desc);

/** Delete a variable/trap by the name provided 
 *
 * @param name of the variable or trap to delete (max length is SNMPDV_SA_MAX_LEN_VAR_NAME)
 * @return 0 on success or negative value as an @ref errcodes "error code"
 */
extern int lsnmpdv_del_item(lsnmpdv *inst, const char *name);

/** Get appropriate name for MIB-file as it configured for SA. 
 *
 * @param buf buffer for zero-terminated file name string
 * @param size reference to buffer size to check bounds, may point to 0 value, in this case
 *             -LSNMPDV_EINVAL result returned and size is set to minimal correct value, so use larger buffer.
 * @note if -LSNMPDV_EINVAL returned and size value is not changed, then error does not
 *           relate to buffer's size and it can't be fixed using larger buffer.
 */
extern int lsnmpdv_get_mib_file_name(lsnmpdv *inst, char *buf, size_t *size);

/** Get MIB name which is supported by SA
 *
 * @param buf buffer for zero-terminated MIB name string
 * @param size reference to buffer size to check bounds, may point to 0 value, in this case
 *             -LSNMPDV_EINVAL result returned and size is set to minimal correct value, so use larger buffer.
 * @note if -LSNMPDV_EINVAL returned and size value is not changed, then error does not
 *           relate to buffer's size and it can't be fixed using larger buffer.
 */
extern int lsnmpdv_get_mib_name(lsnmpdv *inst, char *buf, size_t *size);

/** Create current MIB file with given file name. 
 *
 * @param fname store current MIB as the given file.
 * @return 0 on success or negative value as an @ref errcodes "error code".
 */
extern int lsnmpdv_create_mib_file(lsnmpdv *inst, const char *fname);

#endif /* _LSNMPDV_H_ */

