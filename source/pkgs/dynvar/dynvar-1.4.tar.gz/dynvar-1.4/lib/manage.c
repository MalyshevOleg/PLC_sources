#include <stdio.h>
#include <string.h>
#include <errno.h>

#include "lsnmpdv.h"
#include "snmpdv_int.h"

/* local methods */

static int snmpdv_check_name(const char *name)
{
	if (strlen(name) > SNMPDV_SA_MAX_LEN_VAR_NAME) {
		pr_err("invalid var name length, max: %d allowed\n", 
			SNMPDV_SA_MAX_LEN_VAR_NAME);
		return -LSNMPDV_EINVAL;
	}
	
	return 0;
}

static int snmpdv_make_add_item_msg(lsnmpdv *inst, const char *name, 
							const char *desc, unsigned char msg_type, size_t type_size)
{
	int r;
	size_t desc_len = 0, alloc_desc_len = 0;

	if (!inst || !name) {
		pr_err("invalid args\n");
		return -LSNMPDV_EINVAL;
	}

	r = snmpdv_check_name(name);
	if (r) {
		return r;
	}

	if (desc) {
		desc_len = strlen(desc);
		if (desc_len > SNMPDV_SA_MAX_LEN_VAR_DESC) {
			alloc_desc_len = SNMPDV_SA_MAX_LEN_VAR_DESC + 1; /* max len + 1 char for terminating 0 */
		} else {
			alloc_desc_len = desc_len + 1;
		}
		pr_debug("transmitting desc: len=%d, alloc_len=%d\n", (int)desc_len, (int)alloc_desc_len);
	} else {
		pr_debug("do not transmit desc\n");
	}

	return snmpdv_make_msg(inst, msg_type, type_size + alloc_desc_len);
}

/* Assume desc is not NULL */
static void snmpdv_append_desc_to_add_item_msg(char *to, const char *desc)
{
	size_t desc_len = strlen(desc);

	if (desc_len > SNMPDV_SA_MAX_LEN_VAR_DESC) {
		char *p;
		pr_debug("trancating desc\n");
		/* truncate */
		memcpy(to, desc, SNMPDV_SA_MAX_LEN_VAR_DESC - 2);
		p = &to[SNMPDV_SA_MAX_LEN_VAR_DESC - 2];
		*p++ = '.';	/* [-2] */
		*p++ = '.';	/* [-1] */
		*p++ = 0;	/* [0] = [SNMPDV_SA_MAX_LEN_VAR_DESC] (extra byte for terminating zero is allocated for) */
	} else {
		/* do not truncate */
		pr_debug("do not truncate desc\n");
		strcpy(to, desc);
	}
}

/*  - check inst, name != NULL
 *   - check name length
 *   - process desc
 *   - creates a new out msg in buffer (initializes it with 0, fills msg type, version, data len):
 *   - fills name, desc, var type
 */
static int snmpdv_make_add_var_msg(lsnmpdv *inst, const char *name, 
							const char *desc, unsigned char var_type)
{
	int r;
	snmpdv_sa_msg_hdr *mh;
	snmpdv_sa_var *var;

	r = snmpdv_make_add_item_msg(inst, name, desc, SNMPDV_SA_MSG_ADD_VAR, sizeof(*var));
	if (r) {
		return r;
	}

	mh = &inst->out_msg.mh;
	var = (snmpdv_sa_var *)mh->data;
	
	var->type = var_type;
	strcpy(var->name, name);

	if (desc) {
		/* description is transmitted as zero-terminated string */
		var->flags.desc = 1;
		snmpdv_append_desc_to_add_item_msg(var->desc, desc);
	}
	
	return 0;
}

static int snmpdv_make_add_trap_msg(lsnmpdv *inst, const char *name, const char *desc)
{
	int r;
	snmpdv_sa_msg_hdr *mh;
	snmpdv_sa_trap *trap;

	r = snmpdv_make_add_item_msg(inst, name, desc, SNMPDV_SA_MSG_ADD_TRAP, sizeof(*trap));
	if (r) {
		return r;
	}

	mh = &inst->out_msg.mh;
	trap = (snmpdv_sa_trap *)mh->data;
	
	strcpy(trap->name, name);

	if (desc) {
		/* description is transmitted as zero-terminated string */
		trap->flags.desc = 1;
		snmpdv_append_desc_to_add_item_msg(trap->desc, desc);
	}
	
	return 0;
	
}


/* interface methods implamentation */

int lsnmpdv_add_var_integer(lsnmpdv *inst, const char *name, const char *desc, 
							lsnmpdv_var_integer_attr *attr)
{
	int r;
	snmpdv_sa_var *var;

	r = snmpdv_make_add_var_msg(inst, name, desc, SNMPDV_SA_VT_INTEGER);
	if (r) {
		return r;
	}

	var = (snmpdv_sa_var *)inst->out_msg.mh.data;

	if (attr) {
		if (attr->flags.range) {
			var->flags.range = 1;
			var->attr.i.min = attr->min;
			var->attr.i.max = attr->max;
		}

		if (attr->flags.defval) {
			var->flags.defval = 1;
			var->attr.i.defval = attr->defval;
		}
	}

#if 0
	/* for checking processing of server shutdown before sending a message */
	pr_debug("Waiting 5 seconds before sending a message..\n");
	sleep(5);
	pr_debug("Sending a message...\n");
#endif

	r = snmpdv_send_msg(inst);
	if (r) {
		return r;
	}

#if 0
	/* for checking processing of server shutdown before getting result */
	pr_debug("Message sent, waiting 5 seconds before getting result..\n");
	sleep(5);
	pr_debug("Getting result...\n");
#endif

	return snmpdv_response_rc(inst);
}

int lsnmpdv_add_var_string(lsnmpdv *inst, const char *name, 
								const char *desc, int max_len, const char *defval)
{
	int r;
	snmpdv_sa_var *var;

	r = snmpdv_make_add_var_msg(inst, name, desc, SNMPDV_SA_VT_STRING);
	if (r) {
		return r;
	}

	var = (snmpdv_sa_var *)inst->out_msg.mh.data;

	if (max_len > 0) {
		if (max_len > SNMPDV_SA_MAX_LEN_VAL_STRING) {
			max_len = SNMPDV_SA_MAX_LEN_VAL_STRING;
		}
		var->flags.range = 1;
		var->attr.s.max_len = max_len;
	}
	
	if (defval) {
		var->flags.defval = 1;
		if (strlen(defval) > SNMPDV_SA_MAX_LEN_VAL_STRING) {
			pr_debug("trancating string defval\n");
			memcpy(var->attr.s.defval, defval, SNMPDV_SA_MAX_LEN_VAL_STRING);
			var->attr.s.defval[SNMPDV_SA_MAX_LEN_VAL_STRING] = 0;
		} else {
			pr_debug("do not trancate string defval\n");
			strcpy(var->attr.s.defval, defval);
		}
		
	}

	r = snmpdv_send_msg(inst);
	if (r) {
		return r;
	}
	
	return snmpdv_response_rc(inst);
}

int lsnmpdv_add_var_binary(lsnmpdv *inst, const char *name, 
									const char *desc, int max_len)
{
	int r;
	snmpdv_sa_var *var;

	r = snmpdv_make_add_var_msg(inst, name, desc, SNMPDV_SA_VT_BINARY);
	if (r) {
		return r;
	}

	var = (snmpdv_sa_var *)inst->out_msg.mh.data;

	if (max_len > 0) {
		var->flags.range = 1;
		var->attr.b.max_len = max_len;
	}

	r = snmpdv_send_msg(inst);
	if (r) {
		return r;
	}
	
	return snmpdv_response_rc(inst);
}

int lsnmpdv_add_trap(lsnmpdv *inst, const char *name, const char *desc)
{
	int r;

	r = snmpdv_make_add_trap_msg(inst, name, desc);
	if (r) {
		return r;
	}

	r = snmpdv_send_msg(inst);
	if (r) {
		return r;
	}
	
	return snmpdv_response_rc(inst);
}

int lsnmpdv_del_item(lsnmpdv *inst, const char *name)
{
	int r;
	snmpdv_sa_msg_hdr *mh;
	size_t len;

	if (!inst || !name) {
		pr_err("invalid args\n");
		return -LSNMPDV_EINVAL;
	}

	r = snmpdv_check_name(name);
	if (r) {
		return r;
	}

	len = strlen(name);
	r = snmpdv_make_msg(inst, SNMPDV_SA_MSG_DEL_ITEM, len + 1);
	if (r) {
		return r;
	}

	mh = &inst->out_msg.mh;
	
	strcpy(mh->data, name);

	r = snmpdv_send_msg(inst);
	if (r) {
		return r;
	}

	return snmpdv_response_rc(inst);
}

static int snmpdv_get_mib_name(lsnmpdv *inst)
{
	int r;
	snmpdv_sa_msg_hdr *mh;
	size_t recv_len;

	/* ask server for the name */
	r = snmpdv_make_msg(inst, SNMPDV_SA_MSG_GET_MIB_NAME, 0); /* no payload - arg len = 0 */
	if (r) {
		return r;
	}

	r = snmpdv_send_msg(inst);
	if (r) {
		return r;
	}

	r = snmpdv_response_rc(inst);
	if (r) {
		return r;
	}

	/* check received data len */	
	mh = &inst->in_msg.mh;
	recv_len = strlen(mh->data);
	if (recv_len > SNMPDV_SA_MAX_LEN_MIB_NAME) {
		pr_err("lib-SA incompatibility: received file name is longer(%d) then acceptable (%d)\n",
			(int)recv_len, SNMPDV_SA_MAX_LEN_MIB_NAME);
		return -LSNMPDV_EPROTO;
	}

	return 0;
}

int lsnmpdv_get_mib_file_name(lsnmpdv *inst, char *buf, size_t *size)
{
	int r;
	snmpdv_sa_msg_hdr *mh;
	size_t recv_len;

	if (!inst || !size) {
		pr_err("invalid args\n");
		return -LSNMPDV_EINVAL;
	}

	r = snmpdv_get_mib_name(inst);
	if (r) {
		return r;
	}

	/* extract MIB name from input buffer + .txt into user buffer or return required size of user buffer */
	mh = &inst->in_msg.mh;
	recv_len = strlen(mh->data);
	if (!buf || *size < recv_len + 1 + 4) {	/* +4 for .txt */
		*size = recv_len + 1 + 4;
		pr_debug("invalid buffer, min size required: %d\n", (int)*size);
		return -LSNMPDV_EINVAL;
	}
	
	strcpy(buf, mh->data);
	strcat(buf, ".txt");
	
	return 0;
}

int lsnmpdv_get_mib_name(lsnmpdv *inst, char *buf, size_t *size)
{
	int r;
	snmpdv_sa_msg_hdr *mh;
	size_t recv_len;

	if (!inst || !size) {
		pr_err("invalid args\n");
		return -LSNMPDV_EINVAL;
	}

	r = snmpdv_get_mib_name(inst);
	if (r) {
		return r;
	}

	/* extract MIB name from input buffer into user buffer or return required size of user buffer */
	mh = &inst->in_msg.mh;
	recv_len = strlen(mh->data);
	if (!buf || *size < recv_len + 1) {
		*size = recv_len + 1;
		pr_debug("invalid buffer, min size required: %d\n", (int)*size);
		return -LSNMPDV_EINVAL;
	}
	
	strcpy(buf, mh->data);
	
	return 0;
}

int lsnmpdv_create_mib_file(lsnmpdv *inst, const char *fname)
{
	int r;
	FILE *fp;

	if (!inst || !fname) {
		pr_err("invalid args\n");
		return -LSNMPDV_EINVAL;
	}

	fp = fopen(fname, "w");
	if (!fp) {
		pr_err("failed to create MIB-file '%s'\n", fname);
		return -LSNMPDV_EFAIL;
	}

	do {
		size_t count;
		
		r = snmpdv_make_msg(inst, SNMPDV_SA_MSG_GET_MIB, 0); /* no payload - arg len = 0 */
		if (r) {
			break;
		}

		r = snmpdv_send_msg(inst);
		if (r) {
			break;
		}

		/* get responses, check rc */
		do {
			r = snmpdv_response_rc(inst);
			if (r) {
				break;
			}

			/* rc is OK, so check len and store data as need */
			if (inst->in_msg.mh.len) {
				count = fwrite(inst->in_msg.mh.data, 1, inst->in_msg.mh.len, fp);
				if (count != inst->in_msg.mh.len) {
					pr_err("failed to write to MIB-file '%s'\n", fname);
					r = -LSNMPDV_EFAIL;
					break;
				}
			}
		} while (inst->in_msg.mh.len > 0);
		
	} while (0);

	fclose(fp);
	
	if (r) {
		remove(fname);
	}

	return r;
}


