#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <stdio.h>
#include <sys/un.h>
#include <unistd.h>
#include <sys/select.h>

#include <string.h>
#include <errno.h>

#include "lsnmpdv.h"
#include "snmpdv_int.h"

static unsigned short next_msg_id = 0;

/* local methods */
static int connect_to_subagent(lsnmpdv *inst)
{
	int r;
	struct sockaddr_un addr;
	int len;

	inst->srv_socket = socket(AF_UNIX, SOCK_STREAM, 0);
	if (inst->srv_socket < 0) {
		pr_err("failed to init socket: %s\n", strerror(errno));
		return -1;
	}

	addr.sun_family = AF_UNIX;
	memcpy(addr.sun_path, SNMPDV_SA_SOCKET, sizeof(SNMPDV_SA_SOCKET));
	len = sizeof(addr);

	r = connect(inst->srv_socket, (struct sockaddr *)&addr, len);
	if (r < 0) {
		pr_err("failed to connect to srv: %s\n", strerror(errno));
		close(inst->srv_socket);
		return -1;
	}

	return 0;
}

static int snmpdv_recv(int socket, char *buf, unsigned short len)
{
	fd_set fdset;
	int count;
	struct timeval timeout;
	ssize_t rcv_len;
	char *pos = buf;
	unsigned short left_len = len;

	while (left_len > 0) {
		FD_ZERO(&fdset);
		FD_SET(socket, &fdset);
		
		/* wait any answer for specified time */
		timeout.tv_sec = SNMPDV_SA_MSG_RECV_TIMEOUT_SEC;
		timeout.tv_usec = 0;
		count = select(socket + 1, &fdset, NULL, NULL, &timeout);
		if (!count ) {
			/* timeout */
			pr_err("data receive timed out\n");
			return -LSNMPDV_ECONN;
		} else if (count < 0) {
			pr_err("getting result select error: %s\n", strerror(errno));
			return -LSNMPDV_EFAIL;
		}

		rcv_len = recv(socket, pos, left_len, 0);
		if (!rcv_len) {
			pr_err("server disconnected\n");
			return -LSNMPDV_ECONN;
		} else if (rcv_len < 0) {
			pr_err("failed to read msg: %s\n", strerror(errno));
			return -LSNMPDV_EFAIL;
		}
		left_len -= rcv_len;
		pos += rcv_len;
	}	
	
	return 0;	
}

/* interface implementation */

lsnmpdv* lsnmpdv_open(void)
{
	lsnmpdv *inst;

	inst = malloc(sizeof(*inst));
	if (!inst) {
		pr_err("failed to alloc instance\n");
		return NULL;
	}

	memset(inst, 0, sizeof(*inst));

	if (connect_to_subagent(inst) != 0) {
		free(inst);
		return NULL;
	}

	return inst;
}

void lsnmpdv_close(lsnmpdv *inst)
{
	if (!inst) {
		return;
	}

	close(inst->srv_socket);
	free(inst);
}

/* internal methods */

int snmpdv_recv_msg(struct lsnmpdv *inst)
{
	int r;
	unsigned short len;
	snmpdv_sa_msg_hdr *mh = &inst->in_msg.mh;
	unsigned short cs;

	/* recv header first */
	r = snmpdv_recv(inst->srv_socket, (char*)mh, sizeof(*mh));
	if (r) {
		return r;
	}

	/* expected total length */
	len = sizeof(*mh) + mh->len;

	pr_debug("receiving msg: id=%d, type=%d, data_len=%d, rc=%d; expected total len=%d\n", 
			mh->msg_id, mh->msg_type, mh->len, mh->rc, len);

	/* receive payload if it is expected to be in this message */
	if (len > sizeof(*mh)) {
		r = snmpdv_recv(inst->srv_socket, mh->data, mh->len);
		if (r) {
			return r;
		}
	}
	pr_debug("msg: id=%d received OK\n", mh->msg_id);
	
	/* check the received message */
	if (mh->version != SNMPDV_SA_IF_VERSION) {
		pr_err("received msg of wrong version: 0x%04x\n", mh->version);
		return -LSNMPDV_EPROTO;
	}

	/* calc checksum and verify with expected value */
	cs = SNMPDV_SA_MSG_CS(mh, len);
	if (cs != SNMPDV_SA_MSG_CS_VALUE) {
		pr_err("received msg checksum is invalid: 0x%04X\n", cs);
		return -LSNMPDV_EPROTO;
	}

	return 0;
}

int snmpdv_make_msg(struct lsnmpdv *inst, unsigned char type, unsigned short len)
{
	snmpdv_sa_msg_hdr *mh;

	mh = &inst->out_msg.mh;
	if (len + sizeof(*mh) > sizeof(inst->out_msg)) {
		pr_err("can't make message: requested length %d too big\n", len);
		return -LSNMPDV_EINVAL;
	}
	memset(mh, 0, sizeof(*mh) + len);
	
	mh->version = SNMPDV_SA_IF_VERSION;
	mh->msg_type = type;
	mh->len = len;
	/* data should be set somewhere else */
	return 0;
}

int snmpdv_send_msg(struct lsnmpdv *inst)
{
	int r;
	size_t len;
	snmpdv_sa_msg_hdr *mh;

	mh = &inst->out_msg.mh;
	mh->msg_id = next_msg_id++;
	len = sizeof(*mh) + mh->len;

	/* calc checksum and update respective field */
	mh->cs = SNMPDV_SA_MSG_CS_VALUE;
	mh->cs = SNMPDV_SA_MSG_CS(mh, len);

	r = send(inst->srv_socket, mh, len, MSG_NOSIGNAL);
	if (r < 0) {
		int rc;
		if (errno == EPIPE) {
			rc = -LSNMPDV_ECONN;
		} else {
			rc = -LSNMPDV_EFAIL;
		}
		pr_err("failed to send msg %d: %s\n", mh->msg_id, strerror(errno));
		return rc;
	}

	if (r != len) {
		pr_err("sending len %d != sent %d\n", (int)len, r);
		return -LSNMPDV_EFAIL;
	}

	pr_debug("sent %d chars\n", r);
	return 0;

}

int snmpdv_response_rc(struct lsnmpdv *inst)
{
	int r;
	snmpdv_sa_msg_hdr *mh;

	r = snmpdv_recv_msg(inst);
	if (!r) {
		/* response is OK */
		mh = &inst->in_msg.mh;

		switch (mh->rc) {
			case 0:
				/* OK, return OK */
				break;
			case SNMPDV_SA_EFAIL:
				r = -LSNMPDV_ESA;
				break;
			case SNMPDV_SA_EINVAL:
			case SNMPDV_SA_EVERSION:
			default:
				r = -LSNMPDV_EPROTO;
				break;
		}
	}
	return r;
}

