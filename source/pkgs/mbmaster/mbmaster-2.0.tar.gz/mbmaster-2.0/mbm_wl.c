#include <unistd.h>
#include <stdint.h>
#include <string.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

#include "danfoss.h"
#include "mbm_defs.h"

#include "mbm_modbus_func.h"
#include "mbm_strings.h"
#include "app_log.h"
#include "mbm_utils.h"
#include "mbm_network.h"
#include "mbm_archives.h"

#include "mbm_wl.h"

#ifdef DEBUG
/* white list source table is saved to the file in debug version of the app */
#define MBM_WL_SOURCE_TABLE_FILE		"/tmp/wl_source_table.csv"
#define MBM_WL_SOURCE_TABLES_FILE	"/tmp/wl_source_table_sorted.csv"
#define MBM_WL_NORMALIZED_FILE		"/tmp/wl_normalized.csv"
#endif

typedef struct wl_source_table_info {
#ifdef DEBUG	
	FILE *fp;		/* white list source table file */
	int fp_err;	/* flag if set - exit was due to file IO error */
	int count;	/* count of records written */
#endif

	/* filter and restrict data when setting user defined WL from setList.csv */
	uint32_t *slave_ids;	/* process only these slaves */
	size_t slaves_count;
	int by_wl;			/* use slave's WL to restrict RSSI stats by included arc-ids */

	mbm_wl_tab_t *src_tab;
} wl_source_table_info_t;

/* ==================== */
/*        Clean/Read White Lists     */
/* ==================== */

/* Read wl on the current slave, return 0 on success, -1 on error + errno is set respectively
*  Doesn't log neither success nor failure .
*/
int mbm_clean_white_list(mbm_network_t *mb_net)
{
	uint16_t regs[MBM_MAX_WRITE_REGISTRES];
	int count, rest;
	int regs_addr;
	modbus_t *mb = mb_net->mb;

	memset(regs, 0, sizeof(regs));
	rest = MBM_WHITE_LIST_PK_RECORDS * 2; /* total count of regs to zero */
	regs_addr = MBM_WHITE_LIST_BASE_REG;

	while (rest > 0) {
		int r;
		int attempts = MBM_MODBUS_RETRY;

		count = MBM_MAX_WRITE_REGISTRES;
		if (count > rest) {
			count = rest;
		}

		while (1) {
			r = modbus_write_registers(mb, regs_addr, count, regs);
			if (r < 0) {
				attempts--;
				if (attempts <= 0) {
					return -1;	/* failed (errno is to be processed by caller) */
				}
				log_debug("write(clean) 0-wl failed: %s (%d) - retry", 
							modbus_strerror(errno), errno);
				continue;
			}
			break;
		}

		rest -= count;
		regs_addr += count;
	}

	/* is it sensible to reset all archives on the slave? - NO (Owen's answer) */
	
	return 0; /* OK */
}

static int forslave_clean_white_list(mbm_network_t *mb_net, mbm_slave_dev_t *slave, 
								void *data)
{
	int r;

	r = mbm_clean_white_list(mb_net);
	if (!r) {
		/* update counter of successfully processed devices */
		(*(int*)data)++;
		log_einfo(mbm_str_slave_wl_cleaned, slave->dev_sn_str);
	} else {
		log_err(mbm_str_err_wl_clean, slave->dev_sn_str, slave->addr, 
				modbus_strerror(errno));
	}

	return 1; /* next slave (possible error ignored) */
}

int mbm_clean_white_lists(mbm_network_t *mb_net)
{
	int count = 0;
	
	log_info(mbm_str_clean_wl_started);

	mbm_foreach_active_slave(mb_net, &forslave_clean_white_list, 
								mbm_str_err_wl_clean, &count);
	
	log_info(mbm_str_clean_wl_done, count);
	return count;
}

/* compare uint32_t items as integers, but treat 0 as the biggest value */
static int comp_arc_ids_0max(const void *item1, const void *item2)
{
	uint32_t i1 = *((uint32_t *)item1);
	uint32_t i2 = *((uint32_t *)item2);

	if (i1 && i2) {
		return COMPARE_NUM(i1, i2);
	} else if (i1) {
		return -1;
	} else if (i2) {
		return 1;
	}
	return 0;
}
	
/* Read wl from the current slave, return 0 on success, -1 on error + errno is set respectively
*  Doesn't log neither success nor failure .
*/
int mbm_read_white_list(mbm_network_t *mb_net, mbm_pk_wl_t *wl)
{
	uint16_t regs[MBM_MAX_WRITE_REGISTRES];
	size_t rest_regs;
	int regs_addr;
	int records;

	wl->count = 0;
	records = MBM_WHITE_LIST_PK_RECORDS;
	rest_regs = records * 2;	/* N of IDs, each ID is 2 regs = 32bit arc_id */
	regs_addr = MBM_WHITE_LIST_BASE_REG;

	while (rest_regs > 0) {
		size_t count_regs, count_records;
		int r;
		int i;
		int attempts = MBM_MODBUS_RETRY;

		count_regs = MBM_MAX_WRITE_REGISTRES;
		if (count_regs > rest_regs) {
			count_regs = rest_regs;
		}
		count_records = count_regs /2;

		while (1) {
			r = modbus_read_registers(mb_net->mb, regs_addr, count_regs, regs);
			if (r < 0) {
				attempts--;
				if (attempts <= 0) {
					//log_err(mbm_str_err_wl_read, slave->dev_sn_str, slave->addr, 
					//		modbus_strerror(errno));
					/* pass error to the caller */
					return r;
				}
				log_debug("read wl error: %s (%d) - retry", modbus_strerror(errno), errno);
				continue;
			}
			break;
		}

		/* copy read registers to wl, transforming arc_ids to uint32_t */
		for (i = 0; i < count_records; i++) {
			/* wl is written (high word goes in low register, i.e. first, BE):
			* regs[i * 2] = (uint16_t)((tab->tab[first + i].arc_id >> 16) & 0xffff);
			* regs[i * 2 + 1] = (uint16_t)(tab->tab[first + i].arc_id & 0xffff);
			*/
			wl->arc_id[wl->count++] = MODBUS_GET_INT32_FROM_INT16(regs, i * 2);
		}

		rest_regs -= count_regs;
		regs_addr += count_regs;
	}

//	log_debug_buf("WL read", wl->arc_id, wl->count * sizeof(wl->arc_id[0]), 'd');
	
	/* sort wl (0 val is the greatest, so all 0s will be in the end of the list) */
	qsort(wl->arc_id, wl->count, sizeof(wl->arc_id[0]), &comp_arc_ids_0max);

//	log_debug_buf("WL sorted", wl->arc_id, wl->count * sizeof(wl->arc_id[0]), 'd');

	/* update count of non-zero records */
	for (wl->count = 0; wl->count < records; wl->count++) {
		if (!wl->arc_id[wl->count]) {
			break;	/* 0 records begin.. */
		}
	}
	log_debug("WL normalized count=%u", wl->count);
	log_debug_buf("WL normalized (read)", wl->arc_id, wl->count * sizeof(wl->arc_id[0]), 'd');
	
	return 0;
}

int mbm_write_white_list(mbm_network_t *mb_net, mbm_pk_wl_t *wl)
{
	uint16_t regs[MBM_MAX_WRITE_REGISTRES];
	size_t rest_regs;
	int regs_addr;
	int records;
	int offset_record = 0;
	mbm_pk_wl_t sl;

	/* sort wl (0 val is the greatest, so all 0s will be in the end of the list) */
	memset(&sl, 0, sizeof(sl));
	if (wl->count) {
		qsort(wl->arc_id, wl->count, sizeof(wl->arc_id[0]), &comp_arc_ids_0max);
		memcpy(sl.arc_id, wl->arc_id, sizeof(sl.arc_id[0]) * wl->count);
	}

	log_debug_buf("WL normalized (to write)", wl->arc_id, wl->count * sizeof(wl->arc_id[0]), 'd');

	/* write respective ArcIDs to the slave's WL by blocks of up to MBM_MAX_WRITE_REGISTRES regs */
	records = MBM_WHITE_LIST_PK_RECORDS;
	rest_regs = records * 2;	/* number of regs to write */
	regs_addr = MBM_WHITE_LIST_BASE_REG;

	while (rest_regs > 0) {
		size_t count_regs, count_records;
		int r;
		int i;
		int attempts = MBM_MODBUS_RETRY;

		count_regs = MBM_MAX_WRITE_REGISTRES;
		if (count_regs > rest_regs) {
			count_regs = rest_regs;
		}
		count_records = count_regs /2;

		/* set values */
		for (i = 0; i < count_records; i++) {
			/*
			* ArcID = MODBUS_GET_INT32_FROM_INT16: low register becomes high word in the result dword
			* do reverse transformation: hi word set to low register
			*/
			regs[i * 2] = (uint16_t)((sl.arc_id[offset_record + i] >> 16) & 0xffff);
			regs[i * 2 + 1] = (uint16_t)(sl.arc_id[offset_record + i] & 0xffff);
		}

		while (1) {
			r = modbus_write_registers(mb_net->mb, regs_addr, count_regs, regs);
			if (r < 0) {
				attempts--;
				if (attempts <= 0) {
					//log_err(mbm_str_err_wl_set, slave->dev_sn_str, slave->addr, 
					//		modbus_strerror(errno));
					/* pass error to the caller */
					return r;
				}
				log_debug("write wl error: %s (%d) - retry", modbus_strerror(errno), errno);
				continue;
			}
			break;
		}

		rest_regs -= count_regs;
		regs_addr += count_regs;
		offset_record += count_records;
	}

	return 0;
}

int mbm_is_arc_id_in_pk_wl(mbm_pk_wl_t *wl, uint32_t arc_id)
{
	uint32_t *r;

	r = (uint32_t*)bsearch(&arc_id, wl->arc_id, wl->count, sizeof(wl->arc_id[0]),
				&comp_arc_ids_0max);

	log_debug("arc_id: 0x%08X -%sfound", arc_id, r ? "" : "not");

	return !!r;
}

/* ==================== */
/*            Make/Set White List      */
/* ==================== */

/* src - 1: save src records with RSSI value, 0: save white list i.e. marked wl records */
static int save_white_list_from_src(mbm_wl_tab_t *src_tab, const char *fname, int src)
{
	FILE *fp;
	char arc_id_str[8 + 1];
	char pk_id_str[8 + 1];
	size_t i;
	
	fp = fopen(fname, "w");
	if (!fp) {
		return -1;
	}
	
	for (i = 0; i < src_tab->count; i++) {
		if (
#ifdef DEBUG
			src || 
#endif
			MBM_REC_MARKED(src_tab, i)) {
			arcid_to_str(src_tab->tab[i].arc_id, arc_id_str);
			devsn_to_str(src_tab->tab[i].pk_id, pk_id_str);
#ifdef DEBUG
			if (src) {
				fprintf(fp, "%s" MBM_CSV_FIELD_SEP "%s" MBM_CSV_FIELD_SEP "%d" 
						MBM_CSV_FIELD_SEP "%08X\n", 
						arc_id_str, pk_id_str, src_tab->tab[i].rssi, src_tab->tab[i].arc_id);
			} else {
#endif
				fprintf(fp, "%s" MBM_CSV_FIELD_SEP "%s\n", arc_id_str, pk_id_str);
#ifdef DEBUG
			}
#endif
		}
	}
	fclose(fp);
	return 0;
}

int mbm_save_white_list(const char *fname, mbm_wl_tab_t *wl_tab, int pk_first)
{
	FILE *fp;
	char arc_id_str[8 + 1];
	char pk_id_str[8 + 1];
	size_t i;
	
	fp = fopen(fname, "w");
	if (!fp) {
		return -1;
	}
	
	for (i = 0; i < wl_tab->count; i++) {
		arcid_to_str(wl_tab->tab[i].arc_id, arc_id_str);
		devsn_to_str(wl_tab->tab[i].pk_id, pk_id_str);
		fprintf(fp, "%s" MBM_CSV_FIELD_SEP "%s\n", 
				pk_first ? pk_id_str : arc_id_str,
				pk_first ? arc_id_str : pk_id_str);
	}
	fclose(fp);
	return 0;
}

int mbm_comp_wl_rec_by_arc(const void *rec1, const void *rec2)
{
	mbm_wl_rec_t *r1 = (mbm_wl_rec_t *)rec1;
	mbm_wl_rec_t *r2 = (mbm_wl_rec_t *)rec2;
	return COMPARE_NUM(r1->arc_id, r2->arc_id);
}

int mbm_comp_wl_rec_by_pk_arc(const void *rec1, const void *rec2)
{
	mbm_wl_rec_t *r1 = (mbm_wl_rec_t *)rec1;
	mbm_wl_rec_t *r2 = (mbm_wl_rec_t *)rec2;
	int r;

	r = COMPARE_NUM(r1->pk_id, r2->pk_id);
	if (!r) {
		r = COMPARE_NUM(r1->arc_id, r2->arc_id);
	}
	return r;
}

int mbm_comp_wl_index_rec_by_val(const void *rec1, const void *rec2)
{
	mbm_wl_index_rec_t *r1 = (mbm_wl_index_rec_t *)rec1;
	mbm_wl_index_rec_t *r2 = (mbm_wl_index_rec_t *)rec2;
	return COMPARE_NUM(r1->value, r2->value);
}


/* Reads archives from slaves and collects data into WL src tab for finding out 
* which records should be included to WL.
* - the processed slaves can be restricted by slave ID array passed along with data
* - the archives the data collcted of may be restricted by slave's WL if by_wl flag passed along with data is set
* Two cases of use:
* 1) making WL from scratch - no slave IDs and not by_wl flag
* 2) updating WL - compile tmp_WL for slave, install, wait 24hours, then 
*           add arc data to the src table only from the slaves where tmp WL was set successfully and
*           add only data of arc IDs which are present in slave's actual WL(tmp WL)
*/
static int forslave_add_white_list_source_data(mbm_network_t *mb_net,
											mbm_slave_dev_t *slave, void *data)
{
	int r;
	int channel;
	wl_source_table_info_t *info = (wl_source_table_info_t *)data;
	mbm_arc_descriptor_t arc;
	mbm_arc_header_t arc_head;

	mbm_wl_tab_t *src_tab = info->src_tab;
	mbm_pk_wl_t wl;

	/* check whether or not the slave should be included into process */
	if (info->slave_ids && info->slaves_count) {
		/* use the restriction */
		if (!bsearch(&slave->dev_sn, info->slave_ids, info->slaves_count,
					sizeof(info->slave_ids[0]), &uint32cmp)) {
			log_debug("slave %s excluded from gathering RSSI stats", slave->dev_sn_str);
			return 1; /* next slave */
		}
		log_debug("slave %s participates in gathering RSSI stats", slave->dev_sn_str);
	}

	if (info->by_wl) {
		log_debug("wl src data restricted by slave's %s WL", slave->dev_sn_str);
		r = mbm_read_white_list(mb_net, &wl);
		if (r) {
			log_err(mbm_str_err_wl_read, slave->dev_sn_str, slave->addr, 
					modbus_strerror(errno));
			return 1; /* next slave */
		}
		if (!wl.count) {
			log_debug("slave's %s WL is empty but required for src_tab - skip the slave", slave->dev_sn_str);
			return 1; /* next slave */
		}
	}

	/* for each current arc 0..255:
	* - read header, 
	* - read arc, 
	* - make a record for source table
	* IDCounter, RSSI, IDPK
	* - write the record to the source table
	*/
	for (channel = 0; channel < MBM_ARC_CHANNEL_COUNT; channel++) {
		if (src_tab->count >= MBM_WHITE_LIST_MAX_RECORDS) {
			log_warn("reading of arcs for white list source table stopped: max number of records read");
			return 0;
		}
		
		mbm_make_arc_descriptor(channel, -1, &arc);

		log_debug("process arc for wl source table: dev %s (addr=%d): "
			"channel=%d, arc_header_reg=0x%04X, file_no=%d",
			slave->dev_sn_str, slave->addr, 
			arc.channel, arc.header_reg, arc.file_no);

		r = mbm_read_slave_arc_header(mb_net->mb, slave, &arc, &arc_head);
		if (r) {
			continue;
		}

		/* header got */
		if (!arc_head.telegram_size || arc_head.telegram_size == 0xFF) {
			continue;	/* could it be == 0? */
		}

		/* should we include the arc-record into source table ? */
		if (!info->by_wl || bsearch(&arc_head.arc_id, wl.arc_id, wl.count,
									sizeof(arc_head.arc_id), &uint32cmp)) {
			int16_t rssi;
			mbm_modbus_file_t arc_file;
			
			arc_file.addr = (uint8_t)(slave->addr);
			arc_file.file_no = (uint16_t)arc.file_no;
			arc_file.rec_no = 0;
			/* confirmed by OWEN: TelegramSize in bytes, so convert them into regs, 
			* then, when saving file, convert back 
			*/
			arc_file.regs_count = arc_head.telegram_size / 2 + (arc_head.telegram_size & 1);

			r = mbm_modbus_read_file(mb_net->mb, &arc_file);
			if (r < 0) {
				log_err(mbm_str_err_fetch_arc, slave->dev_sn_str, slave->addr, 
						arc.channel, -1, modbus_strerror(errno));
				continue;
			}

			/* do not correct data length - we need only RSSI field which is first */
			rssi = (int16_t)MODBUS_GET_INT16_FROM_INT8(arc_file.data, 0);

#ifdef DEBUG
			if (info->fp) {
				/* save the record */
				fprintf(info->fp, "%s" MBM_CSV_FIELD_SEP "%s" MBM_CSV_FIELD_SEP 
					"%d" MBM_CSV_FIELD_SEP "'%s'\n", 
					arc_head.arc_id_str, slave->dev_sn_str, rssi, arc_head.time_str);
				info->count++;
			}
#endif

			src_tab->tab[src_tab->count].arc_id = arc_head.arc_id;
			src_tab->tab[src_tab->count].pk_id = slave->dev_sn;
			src_tab->tab[src_tab->count].rssi = rssi;
			src_tab->count++;
		} else {
			log_debug("arc-id %s is not in WL - do not add it to src table", arc_head.arc_id_str);
		}
	}

	return 1;
}

/* Wrapper for forslave_add_white_list_source_data() */
int mbm_make_white_list_source_table(mbm_network_t *mb_net,
										uint32_t *slave_ids, size_t slaves_count,
										int by_wl, mbm_wl_tab_t *src_tab)
{
	wl_source_table_info_t info;

	/* reset src data */
	memset(src_tab, 0, sizeof(*src_tab));

	info.slave_ids = slave_ids;
	info.slaves_count = slaves_count;
	info.by_wl = by_wl;
	info.src_tab = src_tab;

#ifdef DEBUG
	info.fp_err = 0;
	info.count = 0;
	info.fp = fopen(MBM_WL_SOURCE_TABLE_FILE, "w");
	if (!info.fp) {
		log_err("failed to create wl source table file: %s", strerror(errno));
	}
#endif

	mbm_foreach_active_slave(mb_net, &forslave_add_white_list_source_data,
								mbm_str_err_wl_source_table, &info);
#ifdef DEBUG
	if (info.fp_err) {
		log_err("error while writing to wl source table file: %s", strerror(errno));
	}
	if (info.fp) {
		fclose(info.fp);
	}
#endif
	
	log_info(mbm_str_wl_source_table_done, info.src_tab->count);
	return 0;
}

int mbm_mark_white_list_records(mbm_wl_tab_t *src_tab)
{
	size_t i, max_rssi;
	uint32_t cur_arc_id;

	if (!src_tab->count) {
		log_debug("no wl source records - nothing to do");
		return 0;
	}
	
	/* use in-memory table to make the list */
	qsort(src_tab->tab, src_tab->count, sizeof(src_tab->tab[0]),
			&mbm_comp_wl_rec_by_arc);
	log_einfo(mbm_str_wl_source_table_sorted);

#ifdef DEBUG
	if (save_white_list_from_src(src_tab, MBM_WL_SOURCE_TABLES_FILE, 1)) {
		log_err("failed to create WL src tabe file %s: %s", MBM_WL_SOURCE_TABLES_FILE,
				strerror(errno));
	}
#endif
	
	i = 0;
	cur_arc_id = src_tab->tab[i].arc_id;
	max_rssi = i;
	
	while (1) {
		i++;

		if ((i < src_tab->count) &&
			(cur_arc_id == src_tab->tab[i].arc_id)) {
			if (src_tab->tab[i].rssi > src_tab->tab[max_rssi].rssi) {
				max_rssi = i;
			}
			continue;
		}

		/* i wrong or arc_id changed - mark previous arc_id's best RSSI index */
		MBM_REC_MARK_AND_COUNT(src_tab, max_rssi);
		
		if (i >= src_tab->count) {
			/* no more records (i wrong) */
			break;
		}

		/* otherwise arc_id is changed */
		cur_arc_id = src_tab->tab[i].arc_id;
		max_rssi = i;
	}
	log_info(mbm_str_wl_produced, (int)src_tab->mark_count);

	return 0;
}

/* Shrink wl tab by exclusion not marked records.
* Used for:
* - transformation of marked WL source table into WL table
* - making actual WL after installing it on PKs (if some of installation failed, the records of the PK are excluded)
* Note:
* - sorting order of the marked records is not changed,
* - marking information is invalidated
*/
void mbm_shrink_white_list_table(mbm_wl_tab_t *tab)
{
	mbm_wl_rec_t *cur, *gap;
	size_t new_count = 0;
	size_t i;

	if (!tab->count) {
		log_debug("src tab to wl transformation: nothing to do");
		return;
	}

	cur = tab->tab;
	gap = NULL;
	for (i = 0; i < tab->count; i++) {
		if (MBM_REC_MARKED(tab, i)) {
			if (gap) {
				/* move to the gap */
				memcpy(gap, cur, sizeof(*gap));
				gap++;
			} /* otherwise leave on its place and just count */
			new_count++;
		} else {
			/* skip the record */
			if (!gap) {
				gap = cur;
			}
		}
		cur++;
	}

	log_debug("source tab transformed to wl tab: records: %u -> %u", tab->count, new_count);

	tab->count = new_count;
	/* now we have different table, so reset marks */
	MBM_REC_MARK_INIT(tab);
	return;
}

int mbm_save_white_list_from_src(const char *fname, size_t root_dir_len,
										mbm_wl_tab_t *src_tab)
{
	int r;

	r = save_white_list_from_src(src_tab, fname, 0);
	if (r) {
		log_err(mbm_str_err_wl_file, &fname[root_dir_len + 1], strerror(errno));
		return -1;
	}

	log_info(mbm_str_wl_file_saved, &fname[root_dir_len + 1]);
	return 0;
}

/* specify root_dir_len=-1 if whole file name should be printed to the log */
int mbm_load_white_list_stats(const char *fname, size_t root_dir_len, 
								mbm_wl_index_t *stats_tab)
{
	FILE *fp;
	char stats_line[16];	/* correct line is:str[8];str[1-3] - PKID;count=0-256 */
	char *s;
	size_t len;
	uint32_t dev_sn;
	uint16_t arc_count;

	stats_tab->count = 0;

	do {
		fp = fopen(fname, "r");
		if (!fp) {
			if (errno == ENOENT) {
				log_debug("wl stats not found: no wl will be applied");
				break;
			}
			log_err(mbm_str_err_wl_stats_file_read, &fname[root_dir_len + 1],
					strerror(errno));
			return -1;
		}
		log_debug("%s opened", &fname[root_dir_len + 1]);

		while (!feof(fp)) {
			s = fgets(stats_line, sizeof(stats_line), fp);
			log_debug("wl_stats line: '%s'", s);
			if (!s) {
				if (ferror(fp)) {
					/* error */
					log_err(mbm_str_err_wl_stats_file_read, &fname[root_dir_len + 1], 
							strerror(errno));
					return -1;
				}
				break;
			}

			/* parse the line: cut off NL char, leading whitespaces and ending whitespaces, 
			* ignore empty lines 
			*/
			len = strlen(s);
			if (s[len-1] == '\n') {
				len--;
				s[len] = 0;
			}
			while (len > 0 && (s[len-1] == ' ' || s[len-1] == '\t')) len--;
			while ((*s != 0) && (*s == ' ' || *s =='\t'))  {
				s++;
				len--;
			}
			if (!len) {
				continue;
			}

			if (len < 10 || s[8] != MBM_CSV_FIELD_SEP_CHAR) {
				log_err(mbm_str_err_wl_stats_invalid_line, &fname[root_dir_len + 1],
						stats_line);
				return -1;
			}

			s[8] = 0;
			dev_sn = str_to_devsn(s);
			s[8] = MBM_CSV_FIELD_SEP_CHAR;
			if (dev_sn == 0xffffffff) {
				log_err(mbm_str_err_wl_stats_invalid_pk, &fname[root_dir_len + 1],
						stats_line);
				return -1;
			}
			arc_count = atoi(&s[9]);

			if (stats_tab->count >= MBM_SLAVE_MAX_COUNT) {
				log_err(mbm_str_err_wl_stats_invalid_file, &fname[root_dir_len + 1],
						stats_tab->count);
				return -1;
			}
			stats_tab->tab[stats_tab->count].value = dev_sn;
			stats_tab->tab[stats_tab->count].count = arc_count;
			stats_tab->count++;
		}

		fclose(fp);
	} while (0);

	if (stats_tab->count) {
		/* sort by pk_id */
		qsort(stats_tab->tab, stats_tab->count, sizeof(stats_tab->tab[0]), 
			&mbm_comp_wl_index_rec_by_val);
		
		log_einfo(mbm_str_wl_stats_loaded, stats_tab->count);
	} else {
		log_einfo(mbm_str_wl_stats_empty);
	}
	
	return 0;
}

int mbm_save_white_list_stats(const char *fname, size_t root_dir_len, 
								mbm_wl_index_t *wl_tab_index, int marked)
{
	FILE *fp;
	int r;
	size_t i;
	char pk_id_str[9];
	size_t count = 0;

	if (!wl_tab_index->count ||
		(wl_tab_index->count == 1 && !wl_tab_index->tab[0].value) ||
		(marked && !wl_tab_index)) {
		r = unlink(fname);
		if (r && (errno != ENOENT)) {
			log_err(mbm_str_err_wl_stats_file_remove, &fname[root_dir_len + 1],
					strerror(errno));
			return -1;
		}
		log_info(mbm_str_wl_stats_file_empty_removed);
		return 0;
	}

	fp = fopen(fname, "w");
	if (!fp) {
		log_err(mbm_str_err_wl_stats_file_write, &fname[root_dir_len + 1],
				strerror(errno));
		return -1;
	}

	for (i = !wl_tab_index->tab[0].value; i < wl_tab_index->count; i++) {
		size_t index = i - !wl_tab_index->tab[0].value;
		if (!marked || MBM_REC_MARKED(wl_tab_index, index)) {
			fprintf(fp, "%s" MBM_CSV_FIELD_SEP "%u\n",
					devsn_to_str(wl_tab_index->tab[i].value, pk_id_str),
					wl_tab_index->tab[i].count);
			count++;
		}
	}

	fclose(fp);
	
	log_info(mbm_str_wl_stats_file_saved, &fname[root_dir_len + 1], count);
	return 0;
}

mbm_wl_index_rec_t *mbm_get_wl_stats_record_for_pk(mbm_wl_index_t *stats_tab, 
														uint32_t pk_id)
{
	mbm_wl_index_rec_t *r;

	r = (mbm_wl_index_rec_t *)bsearch(&pk_id, stats_tab->tab, stats_tab->count,
									sizeof(stats_tab->tab[0]), 
									&mbm_comp_wl_index_rec_by_val);
	return r;
}

int mbm_load_white_list(const char *fname, mbm_wl_tab_t *wl_tab)
{
	FILE *fp;
	int line_index;
	char wl_line[20];	/* correct line is:str[8];str[8] */
	int r = 0;

	fp = fopen(fname, "r");
	if (!fp) {
		log_err(mbm_str_err_wl_file_read, strerror(errno));
		return -1;
	}

	/* read WL into memory, converting IDs to numbers */
	wl_tab->count = 0;
	line_index = 0;
	while (fgets(wl_line, sizeof(wl_line), fp) != NULL) {
		char *arc_id_str, *pk_id_str;
		size_t len;
		int nl;

		nl = 0;
		line_index++;
		len = strlen(wl_line);
		if (wl_line[len -1] == '\n') {
			nl = 1;
			len--;
			wl_line[len] = 0;
		}
		
		if (len != 17 || wl_line[8] != MBM_CSV_FIELD_SEP_CHAR) {
			log_debug("ignoring wrong line: %d", line_index);
			if (!nl) {
				line_index--;
			}
			continue;
		}

		/* lineis OK, check if there is room for it */
		if (wl_tab->count >= MBM_WHITE_LIST_MAX_RECORDS) {
			log_err(mbm_str_err_wl_file_too_many_records, MBM_WHITE_LIST_MAX_RECORDS);
			r = -1;
			break;
		}

		arc_id_str = wl_line;
		pk_id_str = &wl_line[9];
		wl_line[8] = 0;

		/* convert IDs from string to number */
		wl_tab->tab[wl_tab->count].arc_id = str_to_arcid(arc_id_str);
		wl_tab->tab[wl_tab->count].pk_id = str_to_devsn(pk_id_str);
		wl_tab->count++;
	}

	/* err? */
	if (ferror(fp)) {
		log_err(mbm_str_err_wl_file_read, strerror(errno));
		r = -1;
	}
	
	fclose(fp);

	log_debug("loaded wl records count: %u", wl_tab->count);
//#ifdef DEBUG
//		mbm_save_white_list(MBM_WL_NORMALIZED_FILE ".parsed", wl_tab, 1);
//#endif

	if (!r && wl_tab->count) {
		/* normalize wl: 
		* - sort by PKID, ARCID
		* - make it contain unique records
		*/
		qsort(wl_tab->tab, wl_tab->count, sizeof(wl_tab->tab[0]),
				&mbm_comp_wl_rec_by_pk_arc);
//#ifdef DEBUG
//		mbm_save_white_list(MBM_WL_NORMALIZED_FILE ".sorted", wl_tab, 1);
//#endif
		wl_tab->count = unique_sorted_array(wl_tab->tab, wl_tab->count,
											sizeof(wl_tab->tab[0]),
											&mbm_comp_wl_rec_by_pk_arc);
		log_einfo(mbm_str_wl_table_normalized, wl_tab->count);
#ifdef DEBUG
		mbm_save_white_list(MBM_WL_NORMALIZED_FILE, wl_tab, 1);
#endif
	}
	
	return r;
}

int mbm_make_white_list_index_by_pk(mbm_wl_tab_t *wl_tab, 
											mbm_wl_index_t *wl_tab_index)
{
	int zero_pk = 0;
	size_t i = 0;

	/* init index */
	wl_tab_index->count = 0;
	MBM_REC_MARK_INIT(wl_tab_index);

	if (wl_tab->count) {
		zero_pk = !wl_tab->tab[0].pk_id;
	}
		
	while (i < wl_tab->count) {
		uint32_t val;
		size_t arc_count = 0;
		char id_str[9];

		if (wl_tab_index->count >= MBM_SLAVE_MAX_COUNT + zero_pk) {
			log_err(mbm_str_err_wl_file_too_many_pk, MBM_SLAVE_MAX_COUNT);
			return -1;
		}
		
		val = wl_tab->tab[i].pk_id;
		arc_count = 1;
		
		wl_tab_index->tab[wl_tab_index->count].value = val;
		wl_tab_index->tab[wl_tab_index->count].start = i;
		i++;
		while (i < wl_tab->count && wl_tab->tab[i].pk_id == val) {
			arc_count++;
			i++;
		}
		wl_tab_index->tab[wl_tab_index->count].count = arc_count;
		log_debug("wl_tab_index[%u]: val=%s, start=%u, count=%u",
				wl_tab_index->count, devsn_to_str(val, id_str),
				wl_tab_index->tab[wl_tab_index->count].start,
				wl_tab_index->tab[wl_tab_index->count].count);
		wl_tab_index->count++;
		if (val && (arc_count > MBM_WHITE_LIST_PK_RECORDS)) {
			log_err(mbm_str_err_wl_file_too_many_arc, MBM_WHITE_LIST_PK_RECORDS, 
					devsn_to_str(val, id_str), arc_count);
			return -1;
		}
	}

	return 0;
}

