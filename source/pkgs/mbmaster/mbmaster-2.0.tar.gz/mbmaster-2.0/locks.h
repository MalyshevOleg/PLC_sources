#ifndef LOCKS_H
#define LOCKS_H

struct lock_t
{
    int fd;
};

/*
 * lock_file() and trylock_file() return value:
 *   0 on success (file is successfully locked)
 *  -1 on error (errno) indicates error code
 *   1 if file is already locked or file is mmap()'ed by another process
 *
 *  see lockf(3) for details
 */

int lock_file(const char *name, struct lock_t *lock);

int trylock_file(const char *name, struct lock_t *lock);

int unlock_file(const struct lock_t *lock);

#endif /* LOCKS_H */
