#ifndef _MBM_CONTEXT_H_
#define _MBM_CONTEXT_H_

#include <limits.h>
#include <time.h>
#include <stdint.h>
#include <stdio.h>

#include "mbm_defs.h"

#include "mbm_args.h"
#include "mbm_network.h"
#include "mbm_fs.h"

/* global data structure for top procedures; 
* contains pre-allcated at start-time memory buffers and pre-calculated at start time params
*/
typedef struct mbm_context {
	mbm_config_t cfg;				/* configuration (e.g. from command line) */
	mbm_network_t mb_net;		/* modbus network */

	/* directories and files */
	char root_dir[PATH_MAX];		/* realpath is used - it requires buffer of PATH_MAX */
	size_t root_dir_len;
	
	const char *log_sub_dir;		/* log sub dir depending on app mode */
	char log_dir[MBM_PATH_MAX];	/* log file directory + filename */
	size_t log_dir_len;
	char *log_file_name;	/* ptr to log_file buffer at log file name part */

	/* start time */
	time_t start_time;
	struct tm start_tm;
	char start_dt_str[MBM_DATETIME_LEN + 1];	/* YYYY-MM-DD-HH-mm0 */

	char hostname[MBM_MAX_HOSTNAME_LEN + 1];	/* + 1 - terminating 0 */

	mbm_scan_dir_buf_t scan_buf;

	/* wl processing requires bigger data which is allocated 
	* separately only when wl-operation is performed
	*/
	void *wl_data;
} mbm_context_t;

#endif /*_MBM_CONTEXT_H_*/
