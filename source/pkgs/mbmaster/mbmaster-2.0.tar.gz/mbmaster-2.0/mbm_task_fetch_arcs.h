#ifndef _MBM_TASK_FETCH_ARCS_H_
#define _MBM_TASK_FETCH_ARCS_H_

/** Create dir structure for arcs: /archive/current|monthly
 * @param ctx - app context
 * return 0 - success, <0 - error
 */
extern int mbm_init_arc_fs(mbm_context_t *ctx);

extern void mbm_fetch_archives(mbm_context_t *ctx);

#endif /* _MBM_TASK_FETCH_ARCS_H_ */
