#ifndef _MBM_DEFS_H_
#define _MBM_DEFS_H_

#include "version.h"

extern int mbm_isdst;	/* to eliminate passing of the value for time transforming functions */

/* for testing paths vars length checking */
//#define MBM_PATH_MAX					PATH_MAX
#define MBM_PATH_MAX					1024

#define MBM_FNAME_SEP_CHAR			'-'
//#define MBM_SCAN_BUF_MAX_RECORDS	100
#define MBM_DATETIME_FORMAT			"%Y-%m-%d-%H-%M"
#define MBM_DATETIME_LEN				16
#define MBM_DATE_FORMAT				"%Y-%m-%d"
#define MBM_DATE_LEN					10

#define MBM_ARC_FILENAME_LEN			(9 + MBM_DATETIME_LEN + 9)

#define MBM_GLOBAL_LOCK_FILE	"/var/lock/dk_common.lock"
#define MBM_APP_LOCK_FILE_TPL	"/var/lock/%s-%s.lock"

#define MBM_DIR_STATE					"/root/mbm_state"
#define MBM_FILENAME_WL_STATS		"wl_stats.csv"
#define MBM_FILENAME_CHECK_DIR		"mbm_check_dir.tmp"
/* max length of filenames in state directory: all files are above, select value >= max length */
#define MBM_STATE_FILENAME_MAX_LEN	32

/* keep no more than this count of arcs of given type */
#define MBM_KEEP_ARC_CUR			1
#define MBM_KEEP_ARC_MON			18

/* log files are cleaned either elder than specified number or
* elder than speicifed number of days
* The method is selected by definition of a corresponding value:
* MBM_KEEP_LOG_NUM or MBM_KEEP_LOG_DAYS respectively.
* If both values are defined, MBM_KEEP_LOG_NUM is used
* (MBM_KEEP_LOG_DAYS ignored)
* NOTE: Number of days does not includes the current day, i.e.
* value 0 - preserve only today's files, 
* value 1 - preserve today's and yesterday's files and so on.
*/
/* keep no more than specified number of logs of the same type */
#define MBM_KEEP_LOG_NUM			30
//#define MBM_KEEP_LOG_NUM			5
/* clean log files elder than specified months */
#define MBM_KEEP_LOG_DAYS			30

/* See above: 30 log files, 18 monthly arcs, 1 cur arc - max = 30 */
#define MBM_KEEP_ITEMS_MAX_COUNT		30

#define MBM_SAME_ARC_TIME_SHIFT_MIN	15

#define MBM_MODBUS_RETRY 2

#define MBM_CSV_FIELD_SEP			";"
#define MBM_CSV_FIELD_SEP_CHAR	';'

/* RFC2181: length of a label 1..63 octets */
#define MBM_MAX_HOSTNAME_LEN			63

#define SUBDIR_ARCHIVE			"archive"
#define SUBDIR_ARCHIVE_CUR		"current"
#define SUBDIR_ARCHIVE_MON	"monthly"
#define SUBDIR_SERVICE			"service"
#define SUBDIR_SERVICEOK		"serviceOK"

#define SUBDIR_SERVICE_SETLIST	"setList"

#define SUBDIR_SERVICE_LOG_FILE		"LogFile"
#define SUBDIR_SERVICE_LOG_RSSI		"LogRSSI"
#define SUBDIR_SERVICE_LOG_SETLIST	"LogSetList"

#define MBM_FILENAME_SETLIST				"setList.csv"
#define MBM_FILENAME_SETLIST_REJECTED	"setList_rejected.csv"
#define MBM_FILENAME_SETLIST_ERROR		"setList_error.csv"

/* sorted by Arc ID */
#define MBM_FILENAME_SETLIST_ACTUAL		"setList_actual.csv"
/* sorted by PK ID, then by Arc ID */
#define MBM_FILENAME_SETLIST_ACTUAL_PK	"setList_actual_pk.csv"

#define pr_err(fmt, ...) \
	do {\
		fprintf(stderr, APP_NAME ": Error(%s): " fmt, __func__, ##__VA_ARGS__);\
	} while(0)

#ifdef DEBUG
#define pr_debug(fmt, ...) \
	do {\
		fprintf(stderr, APP_NAME "%s: " fmt, __func__, ##__VA_ARGS__);\
	} while(0)
#else
#define pr_debug(fmt, ...)
#endif

#endif /* _MBM_DEFS_H_ */

