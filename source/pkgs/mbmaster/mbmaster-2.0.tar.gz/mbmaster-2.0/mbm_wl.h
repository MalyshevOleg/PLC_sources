#ifndef _MBM_WL_
#define _MBM_WL_

#include <stdint.h>

#include "mbm_network.h"

/* NOTE: 
* - size of 'count', 'mark_count' field and 'start' (index) in strucutres below is up to uin16_t: 
* max value is number of WL records, which is =MBM_WHITE_LIST_MAX_RECORDS = 247 * 256 < uint16_t
* (type size_t can be changed for uint16_t)
*/

typedef struct mbm_wl_rec {
	uint32_t arc_id;
	uint32_t pk_id;
	int16_t rssi;
}  __attribute__((packed)) mbm_wl_rec_t;

/* WL table - used as source table for setList,  made when loading white list from a file etc. */
typedef struct mbm_wl_tab {
	mbm_wl_rec_t tab[MBM_WHITE_LIST_MAX_RECORDS];
	size_t count;		/* filled records count */

	uint8_t mark[MBM_WHITE_LIST_MAX_RECORDS / 8 + 1]; /* bit array - every bit indicates whether or not respective record is marked */
	size_t mark_count;								/* count of set bits in the array */
} mbm_wl_tab_t;

/* used as index for wl tab or as wl PK stats (w/o 'start' field) */
typedef struct mbm_wl_index_rec {
	uint32_t value;		/* field value */
	uint16_t count;		/* count of repetitions of the value */
	size_t start;			/* starting index of the value */
} __attribute__((packed)) mbm_wl_index_rec_t;

typedef struct mbm_wl_index {
	mbm_wl_index_rec_t tab[MBM_SLAVE_MAX_COUNT + 1];	/* extra 1 slot for possible 0 ID */
	size_t count;											/* filled records count */

	/* bit array - every bit indicates whether or not respective record is marked 
	* NOTE: bit index of the mask = i - !index[0].value - 
	*		i.e. skip first element of index[] if its value is 0
	*/
	uint8_t mark[MBM_SLAVE_MAX_COUNT / 8 + 1];
	size_t mark_count;								/* count of set bits in the array */
} mbm_wl_index_t;

/* Macros for marking records of WL tables: mbm_wl_tab_t and mbm_wl_index_t */
#define MBM_REC_MARK_INIT(ms) \
	{ \
		memset((ms)->mark, 0, sizeof((ms)->mark)); \
		(ms)->mark_count = 0; \
	}

#define MBM_REC_MARK_AND_COUNT(ms, no) \
	{ \
		(ms)->mark[(no)/8] |= (1 << ((no) % 8)); \
		(ms)->mark_count++; \
	}

#define MBM_REC_MARKED(ms, no) ((ms)->mark[(no)/8] & (1 << ((no) % 8)))

typedef struct mbm_pk_wl {
	uint32_t arc_id[MBM_WHITE_LIST_PK_RECORDS];
	size_t count;		/* count of non-zero records which placed first */
} mbm_pk_wl_t;

typedef struct mbm_wl_data {
	mbm_wl_tab_t wl_tab;
} mbm_wl_data_t;

/* Read wl on the current slave, return 0 on success, -1 on error + errno is set respectively
*  Doesn't log neither success nor failure .
*/
extern int mbm_clean_white_list(mbm_network_t *mb_net);

/* Clean white lists on all PKs, returns number of PKs successfully processed */
extern int mbm_clean_white_lists(mbm_network_t *mb_net);

/* Read wl from the current slave, return 0 on success, -1 on error + errno is set respectively
*  Doesn't log neither success nor failure .
*/
extern int mbm_read_white_list(mbm_network_t *mb_net, mbm_pk_wl_t *wl);

/* Write wl to the current slave, return 0 on success, -1 on error + errno is set respectively
*  Doesn't log neither success nor failure .
*/
extern int mbm_write_white_list(mbm_network_t *mb_net, mbm_pk_wl_t *wl);

/* return 1 - arc_id in WL, 0 - NOT in WL */
extern int mbm_is_arc_id_in_pk_wl(mbm_pk_wl_t *wl, uint32_t arc_id);

/** Compare mbm_wl_rec_t by arc_id */
extern int mbm_comp_wl_rec_by_arc(const void *rec1, const void *rec2);

/** Compare mbm_wl_rec_t by pk_id, then by arc_id */
extern int mbm_comp_wl_rec_by_pk_arc(const void *rec1, const void *rec2);

/** Compare mbm_wl_index_rec_t by value (PK ID) */
extern int mbm_comp_wl_index_rec_by_val(const void *rec1, const void *rec2);

/* Make white list source table: read arcs and saves records to the given table.
* Wrapper for forslave_add_white_list_source_data()
*
* src_tab - ptr to pre-allocated and pre-initialized buffer for max-size wl source table
* slave_ids - sorted array of slave IDs which participate in the process
* slaves_count - count of slaves in the array
* by_wl - flag, 1-restrict RSSi stats by slave's current WL
*/
extern int mbm_make_white_list_source_table(mbm_network_t *mb_net,
										uint32_t *slave_ids, size_t slaves_count,
										int by_wl, mbm_wl_tab_t *src_tab);

/* Mark records in wl src tab with max RSSI value
* As result src_tab -all records, sorted by Arc ID, some of records marked to be included in
* result WL
*/
extern int mbm_mark_white_list_records(mbm_wl_tab_t *src_tab);

/* Shrink wl tab by exclusion not marked records.
* Used for:
* - transformation of marked WL source table into WL table
* - making actual WL after installing it on PKs (if some of installation failed, the records of the PK are excluded)
* Note:
* - sorting order of the marked records is not changed,
* - marking information is invalidated
*/
extern void mbm_shrink_white_list_table(mbm_wl_tab_t *tab);

/* Save white list (understood by web UI) from WL source table.
* It is assumed that the source table is prepared properly: 
* sorted by ARCID and best records are marked - see mbm_mark_white_list_records()
*
* The result file has records sorted by ArcID
*/
extern int mbm_save_white_list_from_src(const char *fname, size_t root_dir_len,
											mbm_wl_tab_t *src_tab);
/* Save white list from wl_tab e.g. for debug purposes. 
* pk_first -format: 1=PKID, ARCID, 0=ARCID, PKID
*/
extern int mbm_save_white_list(const char *fname, mbm_wl_tab_t *wl_tab, int pk_first);

/* Load stats file and sort records by PK ID */
extern int mbm_load_white_list_stats(const char *fname, size_t root_dir_len, 
										mbm_wl_index_t *stats_tab);
/* Saves WL stats. If provided wl_tab_index empty or 
* contains only 0-PK ID, which is also treated as empty, then
* existing stats file is deleted - so it will look like WLs are not used.
* NOTE: this may happen if actually PKs have WLs but reading them failed.
* 	See: mbm_fetch_archives() and mbm_load_white_list_stats() - if stats file is absent
* 		stats data is empty which is treated as WLs are not used. 
* 		The same would be treated an empty stats file (no records in result data).
*		So there is no sense in empty stats file at all.
* marked - 1=save only marked records, 0-save all records
*/
extern int mbm_save_white_list_stats(const char *fname, size_t root_dir_len, 
									mbm_wl_index_t *wl_tab_index, int marked);
/*
* returns pointer to the record for given pk_id or NULL if not found
*/
extern mbm_wl_index_rec_t *mbm_get_wl_stats_record_for_pk(mbm_wl_index_t *stats_tab, 
														uint32_t pk_id);

/* load user's setList from a file, 
* normalizes it: sort by PK, Arc, get rid of repeting records (0-PKs are first)
*/
extern int mbm_load_white_list(const char *fname, mbm_wl_tab_t *wl_tab);

/**  Build wl index by PK ID, check unique PK ID count and arc ID count for a PK
* wl_tab - should be pre-sorted by PK 
* return -1 as error if count of unique PK IDs > allowed for bus, or when 
* count of records for a PKID > allowed for PK
* Note: the result index is also sorted by PK ID
*/
extern int mbm_make_white_list_index_by_pk(mbm_wl_tab_t *wl_tab, 
												mbm_wl_index_t *wl_tab_index);

#endif /* _MBM_WL_ */
