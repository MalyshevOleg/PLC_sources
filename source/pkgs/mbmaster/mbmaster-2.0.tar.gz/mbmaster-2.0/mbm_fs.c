#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <limits.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <stdlib.h>
#include <stdio.h>

#include "mbm_defs.h"

#include "mbm_strings.h"
#include "app_log.h"
#include "mbm_utils.h"

#include "mbm_fs.h"
extern char *strptime(const char *s, const char *format, struct tm *tm);

const char *mbm_arc_subdirs[MBM_ARC_TYPE_COUNT] = {
	SUBDIR_ARCHIVE_CUR,
	SUBDIR_ARCHIVE_MON,
};

/******************/
/* Local methods      */
/******************/

/* build parent_dir / sub_dir and create the directory 
 * check that length of result dir with terminating 0 <= MBM_PATH_MAX
 * Doesn't use log - it may not have beed started yet
 * Note: parent_dir MUST have length >= MBM_PATH_MAX
 * return codes:
 * 	0 - success:	directory exists
 *	1 - success:	directory created
 *	<0 = -errno fail:
 *	
 */
static int init_sub_dir(char *parent_dir, const char *sub_dir)
{
	struct stat sbuf;
	int r;

	r = mbm_make_path(parent_dir, sub_dir, parent_dir);
	if (r) {
		return -errno;
	}

	r = stat(parent_dir, &sbuf);
	if (!r) {
		if (!(S_ISDIR(sbuf.st_mode) || S_ISLNK(sbuf.st_mode))) {
			return -ENOTDIR;		/* exists but either directory nor symlink*/
		}
		return 0;				/* exists and directory - OK */
	}
	
	/* some error - assume path does not exist - create */
	r = mkdir(parent_dir, S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
	if (r) {
		return -errno;			/* directory creation failed */
	}
	
	return 1;					/* OK - directory created */
}

/******************/
/* Interface methods */
/******************/

/* note: 
* - path buffer assumed to have size MBM_PATH_MAX 
* - path can poitn to the same buffer as parent_dir - in which case it just appended with sub_dir
*/
int mbm_make_path(const char *dir, const char *name, char *path)
{
	size_t dir_len, name_len;

	dir_len = strlen(dir);
	name_len = strlen(name);
	if (dir_len + 1 + name_len + 1 > MBM_PATH_MAX) {
		errno = ENAMETOOLONG;
		return -1;
	}

	if (path != dir) {
		memcpy(path, dir, dir_len);
	}

	path[dir_len] = '/';
	memcpy(&path[dir_len + 1], name, name_len + 1); /* incl. terminating 0 */
	return 0;
}

int mbm_move_file(const char *oldpath, const char *newpath)
{
	FILE *fp_old, *fp_new;
	char buf[1024];
	size_t size;
	int rc = 0;

	fp_old = fopen(oldpath, "r");
	if (!fp_old) {
		return -errno;
	}
	fp_new = fopen(newpath, "w");
	if (!fp_new) {
		rc = -errno;
		fclose(fp_old);
		return rc;
	}

	while (!feof(fp_old)) {
		size = fread(buf, 1, sizeof(buf), fp_old);
		if (ferror(fp_old)) {
			rc = -errno;
			break;
		}
		if (size > 0) {
			fwrite(buf, size, 1, fp_new);
			if (ferror(fp_new)) {
				rc = -errno;
				break;
			}
		}
	}
	fclose(fp_new);
	fclose(fp_old);
	//sync();

	if (!rc) {
		unlink(oldpath);
	} else {
		unlink(newpath);
	}
	sync();
	return rc;
}

/* here we can use log because it's assumed to have been started */
int mbm_init_sub_dir(char *parent_dir, const char *sub_dir, int root_dir_len)
{
	int r;

	/* root_dir will contain full sub-directory path upon successful call */
	r = init_sub_dir(parent_dir, sub_dir);
	
	switch (r) {
		case 0:
			break;
		case 1:
			if (root_dir_len >= 0) {
				log_einfo(mbm_str_dir_created, &parent_dir[root_dir_len + 1]);
			}
			r = 0;
			break;
		default:
			if (root_dir_len >= 0) {
				log_err(mbm_str_dir_failure, &parent_dir[root_dir_len + 1], strerror(r));
			}
			r = -1;
			break;
	}
	
	return r;
}

//TODO: re-write to use common method mbm_scan_dir??
/* Assumes that:
 * 	- ctx->scan_buf allocated
 * If ctx->rec_len > 0:
 *	- ctx->rec_max_count >= 1
 *	- ctx->rec_len > 1
 * 	- ctx->rec_len  * ctx->rec_max_count <= ctx->scan_buf_size
 * If limit > 0 filter no more than specified number of entries, otherwise filter as many as possible
 */
int mbm_scan_dir_to_buf(const char *dir, int root_dir_len,
							mbm_scan_dir_buf_t *scan_buf, int limit,
							mbm_filter_cb filter, void *data)
{
	int r;
	DIR *d;
	struct dirent *ep;
	struct dirent entry;
	char *p;

	scan_buf->rec_count = 0;
	p = scan_buf->buf;
	scan_buf->flags.eos = 0;
	
	log_debug("scanning dir '%s'...", dir);

	d = opendir(dir);
	if (!d) {
		log_err(mbm_str_err_opendir, &dir[root_dir_len + 1], strerror(errno));
		return -1;
	}

	while ((r = readdir_r(d, &entry, &ep)) == 0) {
		if (!ep) {
			log_debug("dir '%s' reading done - no more items", dir);
			scan_buf->flags.eos = 1;
			break; /* OK: end of stream */
		}

		/* common filtering - skip special directories '.' '..' */
		if ((ep->d_name[0] == '.') && 
			(ep->d_name[1] == '.' || ep->d_name[1] == 0)) {
			log_debug("item: '%s' - special - ignored", ep->d_name);
			continue;
		}

		if (filter(ep, data)) {
			/* add the entry name to the buffer */
			if (scan_buf->rec_len > 0) { /* fixed rec_len */
				strncpy(p, ep->d_name, scan_buf->rec_len - 1);
				p[scan_buf->rec_len - 1] = 0;
				p += scan_buf->rec_len;
				scan_buf->rec_count++;
				log_debug("item '%s' added to scan buf, current count: %d",
							(p - scan_buf->rec_len), scan_buf->rec_count);

				/* check if more entries can be accumulated */
				if (scan_buf->rec_count >= scan_buf->rec_max_count) {
					log_debug("dir '%s' reading done - max item count in scan buf reached", dir);
					break;	/* OK: max_count of entries filtered */
				}
			} else { /* variable rec_len */
				size_t len = strlen(ep->d_name);
				if (sizeof(scan_buf->buf) - (p - scan_buf->buf) <= len) {
					log_debug("dir '%s' reading done - scan buf can't accept more entries", dir);
					break;	/* OK: buffer fulfilled */
				}
				strcpy(p, ep->d_name);
				p += len + 1;			/* every item includes terminating zero */
				scan_buf->rec_count++;
				log_debug("item '%s' added to scan buf, current count: %d",
							(p - len - 1), scan_buf->rec_count);
			}

			if (limit > 0 && scan_buf->rec_count >= limit) {
				log_debug("dir '%s' reading done - limit(%d) item count in scan buf reached", 
							dir, limit);
				break;		/* OK: limit of entries filtered*/
			}
		}
	}
	
	if (r) {
		log_err(mbm_str_err_readdir, &dir[root_dir_len + 1], strerror(r));
		//closedir(d);
		//return -1;	/* filtered entries still can be processed */
	}

	closedir(d);
	log_debug("scanning dir '%s'...done", dir);
	return 0;
}

/* Scan directory dir, filter entries using custom filter callback (filter) with its data (data). 
* If entry is filtered (OK),  it is accepted by custom procedure(accept_entry) with the same data (data).
* If ptr flag_eos provided it is set to signalize whether scanning is ended because no more entries left
*/
int mbm_scan_dir(const char *dir, int root_dir_len, int *flag_eos,
					mbm_filter_cb filter, mbm_accept_entry_cb accept_entry, void *data)
{
	int r;
	DIR *d;
	struct dirent *ep;
	struct dirent entry;
	int eos = 0;

	log_debug("scanning dir '%s'...", dir);

	d = opendir(dir);
	if (!d) {
		log_err(mbm_str_err_opendir, &dir[root_dir_len + 1], strerror(errno));
		return -1;
	}

	while ((r = readdir_r(d, &entry, &ep)) == 0) {
		if (!ep) {
			log_debug("dir '%s' reading done: no more items left", dir);
			eos = 1;
			break; /* OK: end of stream */
		}

		/* common filtering - skip special directories '.' '..' */
		if ((ep->d_name[0] == '.') && 
			(ep->d_name[1] == '.' || ep->d_name[1] == 0)) {
			log_debug("item: '%s' - special - ignored", ep->d_name);
			continue;
		}

		if (filter(ep, data)) {
			/* accept entry */
			if (accept_entry(ep, data) == 0) {
				log_debug("dir '%s' reading done: no more entries wanted by accept\n", dir);
				break;
			}
		}
	}
	
	if (r) {
		log_err(mbm_str_err_readdir, &dir[root_dir_len + 1], strerror(r));
		//closedir(d);
		//return -1;	/* filtered entries still can be processed */
	}

	closedir(d);

	if (flag_eos) {
		*flag_eos = eos;
	}
	
	log_debug("scanning dir '%s'...done", dir);
	return 0;
}

int mbm_datetime_from_log_filename(const char* filename, struct tm *file_tm,
											time_t *file_time)
{
	char *p;
	struct tm tm_val;

	/* get date-time from the file name */
	memset(&tm_val, 0, sizeof(tm_val));
	p = strptime(filename, MBM_DATE_FORMAT, &tm_val);

	/* sanity check */
	if (p && (*p == '-') && (p - filename == MBM_DATE_LEN)) {
		/* convert to time */
		tm_val.tm_isdst = mbm_isdst;
		tm_val.tm_hour = 12; /* as hh:mm:ss are not defined, set 12 hours, so DST correction won't change date */
		log_debug("filename: '%s' time=%4d-%02d-%02d %02d:%02d", filename,
			tm_val.tm_year + 1900, tm_val.tm_mon + 1, tm_val.tm_mday, 
			tm_val.tm_hour, tm_val.tm_min);
		if (file_tm) {
			*file_tm = tm_val;
		}
		if (file_time) {
			*file_time = mktime(&tm_val);
		}
	} else {
		log_debug("filename: '%s' is not correct log file name - ignored", filename);
		return -1;
	}

	return 0;	
}

int mbm_datetime_from_arc_filename(const char* filename, struct tm *file_tm,
									time_t *file_time,	const char *check_arc_id_str)
{
	char *p;
	struct tm tm_val;

	/* check id-part */
	if ((check_arc_id_str && memcmp(filename, check_arc_id_str, 8)) ||
		(filename[8] != MBM_FNAME_SEP_CHAR)) {
		log_debug("filename: '%s' either wrong or not of the expected arc id %s - ignored", 
					filename, check_arc_id_str);
		return -1;
	}

	/* get date-time from the file name */
	memset(&tm_val, 0, sizeof(tm_val));
	p = strptime(&filename[9], MBM_DATETIME_FORMAT, &tm_val);

	/* sanity check */
	if (p && (*p == '-') && (p - &filename[9] == MBM_DATETIME_LEN)) {
		/* convert to time */
		tm_val.tm_isdst = mbm_isdst;
		log_debug("filename: '%s' time=%4d-%02d-%02d %02d:%02d", filename,
			tm_val.tm_year + 1900, tm_val.tm_mon + 1, tm_val.tm_mday, 
			tm_val.tm_hour, tm_val.tm_min);
		if (file_tm) {
			*file_tm = tm_val;
		}
		if (file_time) {
			*file_time = mktime(&tm_val);
		}
	} else {
		log_debug("filename: '%s' is not correct arc file name - ignored", filename);
		return -1;
	}

	return 0;
}

int mbm_order_from_log_filename(const char *fname)
{
	char *p;

	p = strrchr(fname, MBM_FNAME_SEP_CHAR);
	if (p) {
		return atoi(p + 1);
	}
	return 0;
}

/* file filter helpers */

void mbm_file_filter_data_setup(mbm_file_filter_data_t *filter_data, size_t max_count)
{
	filter_data->max_count = max_count;
	filter_data->start_index = max_count;
}

int mbm_comp_arc_filter_item_time_key(const void *item1, const void *item2)
{
	mbm_file_filter_item_t *i1 = (mbm_file_filter_item_t *)item1;
	mbm_file_filter_item_t *i2 = (mbm_file_filter_item_t *)item2;
	return COMPARE_NUM(i1->add_key, i2->add_key);
}

int mbm_comp_arc_filter_item_time_full(const void *item1, const void *item2)
{
	mbm_file_filter_item_t *i1 = (mbm_file_filter_item_t *)item1;
	mbm_file_filter_item_t *i2 = (mbm_file_filter_item_t *)item2;
	return COMPARE_NUM(i1->dt_full, i2->dt_full);
}

int mbm_add_arc_filter_item(const char *fname, int arc_type, mbm_file_filter_data_t *fd)
{
	int r;
	mbm_file_filter_item_t item;

	item.dt_full = fd->file_time;

	if (arc_type == MBM_ARC_TYPE_MON) {
		/* for monthly arcs key is YYYY-MM data
		* i.e. uniqueness is determined by YYYY-MM, 
		* but whether to replace or not is checked by full datetime
		*/
		fd->file_tm.tm_mday = 1;
		fd->file_tm.tm_hour = 12;
		fd->file_tm.tm_min = 0;
		fd->file_tm.tm_sec = 0;
		item.add_key = (long)mktime(&fd->file_tm);
	} else {
		item.add_key = (long)fd->file_time;
	}

	r = insert_unique_from_end(&item, fd->tab, fd->max_count, &fd->start_index, sizeof(item),
								&mbm_comp_arc_filter_item_time_key,
								&mbm_comp_arc_filter_item_time_full);
	log_debug("insert item %s: %d (%s)", fname, r,
			r == 1 ? "replaced" : (r == 2 ? "added/inserted" : "rejected"));
	
	return r;
}

