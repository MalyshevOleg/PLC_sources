#ifndef _MBM_ARCHIVES_H_
#define _MBM_ARCHIVES_H_

#include <time.h>
#include <stdint.h>
#include <modbus/modbus.h>

#include "mbm_network.h"
#include "mbm_defs.h"

typedef struct mbm_arc_descriptor {
	int channel;
	int mon_shift;
	int file_no;			/* No. of the file: calculated */
	int header_reg;		/* Base reg of the header of the file: calculated */
} mbm_arc_descriptor_t;

typedef struct mbm_arc_header {
	uint16_t raw[MBM_ARC_HEADER_REG_COUNT];
	uint32_t arc_id;
	char arc_id_str[8 + 1];	/* converted to string arc_id */
	struct tm tm;				/* telegram time */
	time_t time;
	char time_str[MBM_DATETIME_LEN + 1];
	uint8_t telegram_size;	/* telegram size */
} mbm_arc_header_t;

/*
* @return <0 error, 0 - OK
* NOTE: despite return code is 0, check arc_head->telegram_size: 
*           0xFF - mean 'no archive' and is not valid length
*/
extern int mbm_read_slave_arc_header(modbus_t *mb, mbm_slave_dev_t *slave,
							mbm_arc_descriptor_t *arc, mbm_arc_header_t *arc_head);
extern int mbm_make_arc_descriptor(int channel, int mon_shift,
										mbm_arc_descriptor_t *arc);

extern int mbm_delete_slave_arc(modbus_t *mb, mbm_slave_dev_t *slave,
									uint32_t arc_id);

#endif /* _MBM_ARCHIVES_H_ */
