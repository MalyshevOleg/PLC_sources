#ifndef _MBM_UTILS_H_
#define _MBM_UTILS_H_

#include <stdint.h>

#define COMPARE_NUM(a, b) ({ (a) < (b) ? -1 : ((a) > (b) ? 1 : 0); })

/* returns pointer to the str */
extern const char *devsn_to_str(uint32_t id, char *str);
extern uint32_t str_to_devsn(const char *str);
/* returns pointer to the str */
extern const char *arcid_to_str(uint32_t id, char *str);
extern uint32_t str_to_arcid(const char *str);

/* Like bsearch from stdlib but additionally returned the index of the found element or 
* index of the place where the element could be put (if pointer to result index is provided)
*/
extern void *bsearch_index(const void *key, const void *base, size_t nmemb, size_t size, 
							int (*compar)(const void *, const void *), size_t *index);

extern size_t unique_sorted_array(const void *base, size_t nmemb, size_t size,
							int (*compar)(const void *, const void *));

/* Add or insert item 'item' to array 'base' of unique elements of size 'size'. 
* The array size is 'max_count'. Adding of items is done from the end of the array, 
* so items in the array begin with 'start_index'.
* The items in the array are kept in ascending order.
* Search of items and their uniqueness are determined with 'compar' callback (standard).
* The other comparison method 'compar_replace' is used to decide whether or not the item 
* which was detected as exising should be replaced with new item.
* Example: uniqueness is determined by date YY-MM but whether to replace the item is  determined
* by full date-time YY-MM-DD-HH-mm. This allow to collect only one the newest item for a month.
*
* return codes: 0 - rejected, 1 -replaced, 2 - added(inserted) 
*/
extern int insert_unique_from_end(const void *item, const void *base,
								size_t max_count, size_t *start_index, size_t size, 
								int (*compar)(const void *, const void *),
								int (*compar_replace)(const void *, const void *));

extern int uint32cmp(const void *n1, const void *n2);

#endif /* _MBM_UTILS_H_ */
