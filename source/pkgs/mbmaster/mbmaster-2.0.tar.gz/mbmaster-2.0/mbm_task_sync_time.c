#include <stdint.h>
#include <string.h>
#include <errno.h>
#include <time.h>

#include <modbus/modbus.h>

#include "danfoss.h"
#include "mbm_defs.h"

#include "mbm_strings.h"
#include "app_log.h"
#include "mbm_network.h"

#include "mbm_task_sync_time.h"

static int forslave_sync_time(mbm_network_t *mb_net, mbm_slave_dev_t *slave, 
								void *data)
{
	time_t cur_time;
	struct tm cur_tm;
	uint16_t calendar[6];
	int r;
	int attempts = MBM_MODBUS_RETRY;
	
	modbus_t *mb = mb_net->mb;

	while (1) {
		/* get current time */
		cur_time = time(NULL);
		cur_time += (MBM_TIME_CORRECTION_SEC);
		if (!localtime_r(&cur_time, &cur_tm)) {
			/* sys err */
			log_err(mbm_str_err_sys_time, strerror(errno));
			return 0; /* do not continue - fatal */
		}

		/* Setup device calendar. The format is:
		 * sec 0..59
		 * min 0..59
		 * hour 0..23
		 * mday 1..31
		 * mon 1.12
		 * year 2010..2100 
		 */

		calendar[0] = cur_tm.tm_sec;
		calendar[1] = cur_tm.tm_min;
		calendar[2] = cur_tm.tm_hour;
		calendar[3] = cur_tm.tm_mday;
		calendar[4] = cur_tm.tm_mon + 1;		/* tm_mon 0..11 */
		calendar[5] = cur_tm.tm_year + 1900;	/* tm_year - the number of years since 1900 */

		/* do not use function 0x50 (SetTime) from owen doc - confirmed by Owen */
		r = modbus_write_registers(mb, MBM_CALENDAR_REG, 6, (uint16_t *)calendar);
		if (r < 0) {
			attempts--;
			if (attempts <= 0) {
				log_err(mbm_str_err_sync_time, slave->dev_sn_str, slave->addr, 
						modbus_strerror(errno));
				return 1;	/* not fatal: try another device */
			}
			log_debug("write to slave's %s calendar failed: %s (%d) - retry", 
						slave->dev_sn_str, modbus_strerror(errno), errno);
			continue;
		}
		break;
	}

	/* update counter of synced devices */
	(*(int*)data)++;
	log_einfo(mbm_str_slave_time_synced, slave->dev_sn_str);
	
	return 1;
}

void mbm_sync_time(mbm_network_t *mb_net)
{
	int count = 0;
	
	log_info(mbm_str_sync_time_started);

	mbm_foreach_active_slave(mb_net, &forslave_sync_time, 
							mbm_str_err_sync_time, &count);

	log_info(mbm_str_sync_time_done, count);
}

