#include <unistd.h>
#include <signal.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
//#include <time.h>
#include <stdlib.h>

#include "locks.h"
#include "mbm_context.h"
#include "mbm_strings.h"
#include "app_log.h"
#include "mbm_init.h"

#include "mbm_task_sync_time.h"
#include "mbm_task_fetch_arcs.h"
#include "mbm_task_clean_fs.h"
#include "mbm_task_wl.h"

/* Note: name should not be more than 20 char long - see app_lock_file var in main() */
const char *app_mode_names[MBM_MODE_COUNT] = {
	[MBM_MODE_FETCH_ARCHIVES] = "fetch-arcs",
	[MBM_MODE_MAKE_WHITE_LIST] = "make-wl",	
	[MBM_MODE_SET_WHITE_LIST] = "set-wl",
	[MBM_MODE_SYNC_TIME] = "sync-time",
	[MBM_MODE_GET_ACTUAL_WHITE_LIST] = "get-act-wl",
};

static mbm_context_t *gctx = NULL;

void sig_handler(int signum)
{
	printf("signal %d\n", signum);
	if (gctx) {
		if (gctx->mb_net.mb) {
			mbm_modbus_done(&gctx->mb_net);
			printf("modbus connection freeed\n");
		}
		/* TODO: potential risk to double done() if signal caught 
		* when done() is executed in natural order
		*/
		mbm_done(&gctx);
		printf("mb_master memory freeed\n");
	}
	exit(0);
}

static int run_app_mode(mbm_context_t *ctx)
{
	int r;

	mbm_modbus_init(&ctx->mb_net, &ctx->cfg.port, ctx->cfg.log_level >= APP_DEBUG);
	if (ctx->mb_net.mb) {
		mbm_sync_time(&ctx->mb_net);
	}

	switch (ctx->cfg.mode) {
		case MBM_MODE_MAKE_WHITE_LIST:
			if (ctx->mb_net.mb && mbm_init_wl_fs(ctx) == 0) {
				r = mbm_make_white_list(ctx);
			}
			break;

		case MBM_MODE_SET_WHITE_LIST:
			if (ctx->mb_net.mb && mbm_init_wl_fs(ctx) == 0) {
				r = mbm_set_white_list(ctx);
			}
			break;

		case MBM_MODE_GET_ACTUAL_WHITE_LIST:
			if (ctx->mb_net.mb && mbm_init_wl_fs(ctx) == 0) {
				r = mbm_get_actual_white_list(ctx);
			}

		case MBM_MODE_SYNC_TIME:
			/* do nothing more */
			break;

		default:
		case MBM_MODE_FETCH_ARCHIVES:
			{
				if (mbm_init_arc_fs(ctx) == 0) {
					if (ctx->mb_net.mb) {
						mbm_fetch_archives(ctx);
					}
					mbm_clean_archives(ctx);
				} else {
					log_err(mbm_str_err_fail_init_arc_fs);
				}
			}
			break;
	}

	mbm_modbus_done(&ctx->mb_net);

	if (ctx->cfg.mode != MBM_MODE_SYNC_TIME) {
		mbm_clean_logs(ctx);
	}
	
	return r;
}

int main(int argc, char *argv[])
{
	int r;
	char app_lock_file[sizeof(MBM_APP_LOCK_FILE_TPL) - 1 - 4 + sizeof(APP_NAME) - 1 + 20 + 1];
	struct lock_t app_lock;
	struct lock_t global_lock;
	mbm_context_t *ctx;

	signal(SIGINT, &sig_handler);
	signal(SIGTERM, &sig_handler);

	/* initialization before log start */
	r = mbm_init(argc, argv, &gctx);
	if (!gctx) {
		return r;
	}

	ctx = gctx;

	/* init logging */
	r = app_log_start(ctx->log_dir, APP_NAME, mbm_str_log_started);
	/* as soon as log file opened we can split log_dir for pure dir and log file name */
	ctx->log_dir[ctx->log_dir_len] = 0;

	{
		const char *app_mode_titles[MBM_MODE_COUNT] = {
			[MBM_MODE_FETCH_ARCHIVES] = mbm_str_am_fetch_arcs,
			[MBM_MODE_MAKE_WHITE_LIST] = mbm_str_am_make_wl,
			[MBM_MODE_SET_WHITE_LIST] = mbm_str_am_set_wl,
			[MBM_MODE_SYNC_TIME] = mbm_str_am_sync_time,
			[MBM_MODE_GET_ACTUAL_WHITE_LIST] = "getting actual WL",
		};
		log_info(mbm_str_app_id, APP_NAME, APP_VERSION, app_mode_titles[ctx->cfg.mode]);
	}

	do {
		/* prevent more than 1 instance of the app+mode to run simultaneously,
		* note: distinguish between app modes
		*/
		sprintf(app_lock_file, MBM_APP_LOCK_FILE_TPL, APP_NAME, app_mode_names[ctx->cfg.mode]);
		r = trylock_file(app_lock_file, &app_lock);
		if (r) {
			if (r < 0) {
				/* sys err */
				log_err(mbm_str_err_fail_lock, app_lock_file, strerror(errno));
			} else {
				/* already locked */
				log_info(mbm_str_app_mode_running, app_mode_names[ctx->cfg.mode]);
			}
			break;
		}

		/* wait while another app using modbus finishes its work and acquire global modbus lock */
		log_info(mbm_str_getting_modbus_lock);
		r = lock_file(MBM_GLOBAL_LOCK_FILE, &global_lock);
		if (r) {
			log_err(mbm_str_err_fail_lock, MBM_GLOBAL_LOCK_FILE, strerror(errno));
			unlock_file(&app_lock);
			break;
		}

		r = run_app_mode(ctx);

		unlock_file(&global_lock);
		unlock_file(&app_lock);
	}while (0);

	mbm_done(&gctx);

	/* stop logging */
	app_log_stop(mbm_str_log_stopped);
	
	return r;
}

