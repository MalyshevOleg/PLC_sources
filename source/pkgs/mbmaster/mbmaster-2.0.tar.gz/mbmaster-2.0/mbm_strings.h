#ifndef _MBM_STRINGS_H_
#define _MBM_STRINGS_H_

const char *mbm_str_log_started;
const char *mbm_str_log_stopped;

const char *mbm_str_app_id;

const char *mbm_str_dir_created;
const char *mbm_str_dir_failure;

const char *mbm_str_app_mode_running;
const char *mbm_str_getting_modbus_lock;

const char *mbm_str_err_fail_lock;

//const char *mbm_err_file_operation;
//const char *mbm_str_file_open;
//const char *mbm_str_file_read;
//const char *mbm_str_file_write;

const char *mbm_str_err_arc_path_too_long;
//const char *mbm_str_err_scan_buf_alloc;
const char *mbm_str_err_wl_src_tab_alloc;
const char *mbm_str_err_wl_tab_alloc;
const char *mbm_str_err_opendir;
const char *mbm_str_err_readdir;
const char *mbm_str_err_remove;
const char *mbm_str_err_fail_init_arc_fs;
const char *mbm_str_err_assign_addrs;
const char *mbm_str_err_libmodbus;

const char *mbm_str_err_modbus_reinit;
const char *mbm_str_warn_diff_slaves_count;

const char *mbm_str_warn_set_slave_addr;
const char *mbm_str_err_set_slave_addr;
const char *mbm_str_err_slave_addr_verify;
const char *mbm_str_received_addr_different;
const char *mbm_str_err_slave_info;
const char *mbm_str_err_sync_time;
const char *mbm_str_err_sys_time;
const char *mbm_str_err_fetch_arc_header;
const char *mbm_str_err_fetch_arc;
const char *mbm_str_err_save_arc;
const char *mbm_str_err_fetch_arcs;

const char *mbm_str_err_wl_clean;
const char *mbm_str_err_wl_source_table;
const char *mbm_str_err_wl_file;
const char *mbm_str_err_wl_path_too_long;
const char *mbm_str_err_wl_file_read;
const char *mbm_str_err_wl_file_too_many_records;
const char *mbm_str_err_wl_file_too_many_pk;
const char *mbm_str_err_wl_file_too_many_arc;
const char *mbm_str_err_set_list_pk_not_on_bus;
const char *mbm_str_err_wl_set;
const char *mbm_str_err_move_wl_set;

const char *mbm_str_slave_found;
const char *mbm_str_slave_addrs_assigned;
	
const char *mbm_str_old_removed;
const char *mbm_str_old_arcdir_removed;

const char *mbm_str_fetch_archives_started;
const char *mbm_str_arc_fetched;
const char *mbm_str_fetch_archives_done;

const char *mbm_str_sync_time_started;
const char *mbm_str_slave_time_synced;
const char *mbm_str_sync_time_done;

const char *mbm_str_clean_log_started;
const char *mbm_str_clean_log_done;
const char *mbm_str_clean_arc_started;
const char *mbm_str_clean_arc_done;

const char *mbm_str_clean_wl_started;
const char *mbm_str_slave_wl_cleaned;
const char *mbm_str_clean_wl_done;

const char *mbm_str_make_wl_started;
const char *mbm_str_wl_source_table_done;
const char *mbm_str_make_wl_wait;
const char *mbm_str_make_wl_continue;
const char *mbm_str_wl_source_table_sorted;
const char *mbm_str_wl_produced;
const char *mbm_str_wl_file_saved;
const char *mbm_str_make_wl_done;

const char *mbm_str_set_wl_started;
const char *mbm_str_wl_table_normalized;
const char *mbm_str_wl_no_records_for_slave;
const char *mbm_str_wl_found_records_for_slave;
const char *mbm_str_slave_wl_set;
const char *mbm_str_set_wl_done;
const char *mbm_str_set_list_empty;
const char *mbm_str_set_wl_empty_done;
const char *mbm_str_move_wl_set;

const char *mbm_str_err_bad_set_list_file;
const char *mbm_str_err_use_set_list_file;
const char *mbm_str_err_moveok_set_list_file;

const char *mbm_str_set_list_file_found;
const char *mbm_str_no_set_list_file;
const char *mbm_str_set_list_file_accepted_found;
const char *mbm_str_moveok_set_list_file;

const char *mbm_str_nosp;
const char *mbm_str_error;

const char *mbm_str_am_fetch_arcs;
const char *mbm_str_am_make_wl;
const char *mbm_str_am_set_wl;
const char *mbm_str_am_sync_time;

/******/
const char *mbm_str_err_wl_stats_file_remove;
const char *mbm_str_err_wl_stats_file_write;

const char *mbm_str_err_wl_stats_file_read;
const char *mbm_str_err_wl_stats_invalid_line;
const char *mbm_str_err_wl_stats_invalid_pk;
const char *mbm_str_err_wl_stats_invalid_file;

const char *mbm_str_err_wl_read;

const char *mbm_str_wl_stats_loaded;
const char *mbm_str_wl_stats_empty;

const char *mbm_str_wl_stats_file_empty_removed;
const char *mbm_str_wl_stats_file_saved;

const char *mbm_str_fetch_arcs_wl_stats_empty;
const char *mbm_str_fetch_arcs_wl_empty;

const char *mbm_str_err_del_arc;

const char *mbm_str_del_slave_arc_started;
const char *mbm_str_del_slave_arc;
const char *mbm_str_del_slave_arc_done;
	
#endif /* _MBM_STRINGS_H_ */

