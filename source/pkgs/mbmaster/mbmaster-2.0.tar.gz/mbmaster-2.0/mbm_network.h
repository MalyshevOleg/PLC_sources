#ifndef _MBM_NETWORK_H_
#define _MBM_NETWORK_H_

#include <stdint.h>
#include <modbus/modbus.h>

/* danfoss & modbus constants */
#include "danfoss.h"

/* channel 0- based 0..255 */
#define CHANNEL_INDEX(channel) ((channel) >> 3)
#define CHANNEL_BIT(channel) ((channel) & 0x7)

typedef struct mbm_slave_dev {
	int addr;
	char dev_name[6 + 1]; /* zero terminated */
	uint32_t dev_sn; /* MODBUS_GET_INT32_FROM_INT16 - low register becomes high word in the result dword */
	char dev_sn_str[8 + 1];
	uint16_t status;
	int sensor_count;		/* from status - count of sensors being archived by the slave */
	char fw_ver[MBM_MAX_SLAVE_VER_LEN + 1];
	struct {
		unsigned addr_check_passed: 1;

		/* status flags */
		unsigned no_arc: 1;			/* can't perform operations with archives - OP2 */
		unsigned no_mon_arc: 1;		/* can't perform operations with last mon archives - OP1 */
		unsigned fail_radio: 1;
		unsigned fail_flash: 1;
	} flags;

	/* statistics on channels use: gather while fetching current arcs, 
	* then skip fetching of monthly arcs for not used channels
	* 256 channels = 8 * 32. bit = 1 - channel used, 0 - not used
	*/
	uint8_t channel_mask[MBM_ARC_CHANNEL_COUNT / 8 + 1];
} mbm_slave_dev_t;

/* modbus network state */
typedef struct mbm_network {
	modbus_t *mb;
	/* indexed by slave addr starting with 1  (slot 0 is not used) - see mbm_foreach_active_slave()*/
	mbm_slave_dev_t slaves[MBM_SLAVE_ADDR_MAX + 1];
	int max_addr;		/* max slave addr assigned:  MBM_MB_SLAVE_ADDR_ MIN..MAX*/
	int slaves_count;		/* number of slaves successfully passed addr check */
} mbm_network_t;

typedef struct mbm_port_config {
	const char *tty_dev;	/* tty device for access to the bus */
	int baud_rate;
	char parity;
	int data_bits;
	int stop_bits;
} mbm_port_config_t;

/* init, configure and finalize modbus network */

extern int mbm_modbus_init(mbm_network_t *mb_net, mbm_port_config_t *port_cfg, 
								int mb_debug_on);
extern void mbm_modbus_done(mbm_network_t *mb_net);
extern int mbm_network_configure(mbm_network_t *mb_net);

/* process slaves */

/* return 0 to break the loop and do not process more slaves */
typedef int (*process_slave_cb)(mbm_network_t *mb_net, mbm_slave_dev_t *slave, 
								void *data);
/* err_msg - optional err message for modbus_set_slave() failure, 
* data - optional specific data 
*/
extern void mbm_foreach_active_slave(mbm_network_t *mb_net, 
						process_slave_cb process, const char *err_msg, void *data);

extern void mbm_get_active_slaves_ids(mbm_network_t *mb_net,
										uint32_t slave_ids[MBM_SLAVE_MAX_COUNT],
										size_t *slaves_count);

#endif /* _MBM_NETWORK_H_ */
