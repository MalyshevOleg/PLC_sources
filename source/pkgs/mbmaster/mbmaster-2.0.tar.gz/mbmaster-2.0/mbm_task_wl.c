#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <stdint.h>
#include <string.h>
#include <errno.h>
#include <stdlib.h>

#include "mbm_context.h"

#include "mbm_strings.h"
#include "app_log.h"
#include "mbm_utils.h"

#include "mbm_archives.h"
#include "mbm_wl.h"
#include "mbm_task_wl.h"

typedef struct arc_ref {
	uint32_t id;
	char id_str[8 + 1];	/* converted to string arc_id */
	int channel;
	/* do not use 'mark' structure in order to be able to re-sort arc-list after marking */
	char preserve;		/* mark arcs to be preserved in case freeing of channels will be needed */
} arc_ref_t;

typedef struct arc_list {
	arc_ref_t ref[MBM_ARC_CHANNEL_COUNT];
	size_t count;		/* count of non-zero records which placed first */
	size_t fail_count;	/* count of channels we fail to read */
} arc_list_t;

typedef struct set_wl_info {
	int clean_count;		/* count of slaves where WL cleaned */
	int set_count;		/* count of slaves setting WL to succeeded */
	int fail_count;		/* count of slaves where cleaning/setting WL failed */
	int wl_rec_count;		/* total installed wl records */

	int ambiguous;		/* whether or not user setList is ambiguous */
	
	mbm_wl_tab_t *wl_tab;		/* reference to WL table memory in global context: used for WL and for WL src data */
	mbm_wl_index_t wl_index_pk;	/* WL table index by PK */

	uint32_t slave_ids[MBM_SLAVE_MAX_COUNT];				/* slaves on the bus */
	size_t slaves_count;
	struct {
		uint8_t mark[MBM_SLAVE_MAX_COUNT / 8 + 1];		/* mark slaves on the bus instead of w;_index_pk - for installing 0-PK records */
		size_t mark_count;
	} slave_mark;
} set_wl_info_t;

/* ==================================*/
/*  Local methods */
/* ==================================*/

static int move_processed_set_list_file(const char *src, const char *root_dir, 
										size_t root_dir_len, const char *dst_name)
{
	int r;
	char path[MBM_PATH_MAX];

	mbm_make_path(root_dir, SUBDIR_SERVICEOK, path);
	mbm_make_path(path, SUBDIR_SERVICE_SETLIST, path);
	mbm_make_path(path, dst_name, path);

	r = mbm_move_file(src, path);
	if (r) {
		log_err(mbm_str_err_moveok_set_list_file, strerror(-r));
	} else {
		log_info(mbm_str_moveok_set_list_file, &path[root_dir_len + 1]);
	}

	return r;	
}

/* slave_ids - IDs of slaves active on the bus
* slaves_count - count of the active slaves
* returns bool 1- yes, 0 - no 
*/
static int is_white_list_pk_on_bus(mbm_wl_index_t *wl_index_pk,
									uint32_t slave_ids[], size_t slaves_count)
{
	size_t i;
	uint32_t pkid;

	if (!wl_index_pk->count) {
		/* answer YES though it doesn't matter actually:
		* this is not possible 'cause if no PKs in WL we won't get into this procedure - 
		* clean WL performed instead 
		*/
		return 1;
	}

	/* wl_index_pk is sorted by PKID(as corresponding white list), so if 0 PKID is present - 
	* it is first - skip it
	*/
	for (i = !wl_index_pk->tab[0].value; i < wl_index_pk->count; i++) {
		pkid = wl_index_pk->tab[i].value;

		if (!bsearch(&pkid, slave_ids, slaves_count, sizeof(pkid), &uint32cmp)) {
			char id_str[9];
			log_err(mbm_str_err_set_list_pk_not_on_bus, devsn_to_str(pkid, id_str));
			return 0;
		}
	}
	log_debug("all PKs from the setList are on bus");
	return 1;
}

/* Note: it is assumed that wl_tab is normalized, i.e.
* has globally unique records, sorted by PKID then by ArcID
*/
static int is_white_list_ambiguous(mbm_wl_tab_t *wl_tab,
									mbm_wl_index_t *wl_index_pk)
{
	size_t i, j;

	if (!wl_index_pk->tab[0].value) {
		log_debug("0 PK found - WL is ambiguous");
		return 1;	/* 0 PK ID found */
	}
	
	/* search WL for duplicates */
	log_debug("search wl for duplicate arc-ids");
	i = 0;
	/* We need at least two PKs available for comparing Arc IDs:
	* ones of the i-PK with ones of (i+1)-PK 
	* (within the same PK IDs Arc IDs are quniue)
	*/
	for (i = 0; i < wl_index_pk->count; i++) {
		for (j = i + 1; j < wl_index_pk->count; j++) {
			size_t k;
			size_t i_start, i_count, j_start, j_count;
			i_start = wl_index_pk->tab[i].start;
			i_count = wl_index_pk->tab[i].count;
			j_start = wl_index_pk->tab[j].start;
			j_count = wl_index_pk->tab[j].count;
			
			for (k = 0; k < i_count; k++) { /* for each arcid of i-PK */
				/* search j-PK range for current i-PK Arc ID */
				mbm_wl_rec_t *wl_rec;
				wl_rec = bsearch(&wl_tab->tab[i_start + k].arc_id,
							&wl_tab->tab[j_start], j_count, sizeof(wl_tab->tab[0]),
							&mbm_comp_wl_rec_by_arc);
				if (wl_rec) {
#ifdef DEBUG
					{
						char arc_id_str[9];
						char pk1_id_str[9];
						char pk2_id_str[9];
						log_debug("double Arc-ID %s found PKs: %s, %s - WL is ambiguous",
							arcid_to_str(wl_tab->tab[i_start + k].arc_id, arc_id_str),
							devsn_to_str(wl_tab->tab[i_start + k].pk_id, pk1_id_str),
							devsn_to_str(wl_rec->pk_id, pk2_id_str));
					}
#endif
					return 1;
				}
			}
		}
	}

	/* no ambiguities found */
	log_debug("WL is NOT ambiguous");
	return 0;
}

static int comp_arc_ref_by_id(const void *rec1, const void *rec2)
{
	arc_ref_t *r1 = (arc_ref_t *)rec1;
	arc_ref_t *r2 = (arc_ref_t *)rec2;
	return COMPARE_NUM(r1->id, r2->id);
}
static int comp_arc_ref_by_channel(const void *rec1, const void *rec2)
{
	arc_ref_t *r1 = (arc_ref_t *)rec1;
	arc_ref_t *r2 = (arc_ref_t *)rec2;
	return COMPARE_NUM(r1->channel, r2->channel);
}

/* return arc list sorted by arc_id;
* the list contains only valuable records, i.e. no free channels, no error-channels
*/
static void get_slave_arc_list(mbm_network_t *mb_net, mbm_slave_dev_t *slave,
							arc_list_t *arc_list)
{
	int r;
	int channel;
	mbm_arc_descriptor_t arc;
	mbm_arc_header_t arc_head;
	arc_ref_t *arc_ref;

	arc_list->count = 0;
	arc_list->fail_count = 0;
	
	for (channel = 0; channel < MBM_ARC_CHANNEL_COUNT; channel++) {
		mbm_make_arc_descriptor(channel, -1, &arc);

		r = mbm_read_slave_arc_header(mb_net->mb, slave, &arc, &arc_head);
		if (r) {
			arc_list->fail_count++;
			log_debug("slave %s, channel: %d - failure", slave->dev_sn_str, channel);
			continue;
		}
		if (arc_head.telegram_size == 0xFF) {
			log_debug("slave %s, channel: %d - free", slave->dev_sn_str, channel);
			continue;
		}
		arc_ref = &arc_list->ref[arc_list->count++];

		arc_ref->channel = channel;
		arc_ref->id = arc_head.arc_id;
		memcpy(arc_ref->id_str, arc_head.arc_id_str, sizeof(arc_ref->id_str));
		arc_ref->preserve = 0;

		log_debug("slave %s, channel: %d - id: %s, count=%u", slave->dev_sn_str, channel,
					arc_head.arc_id_str, arc_list->count);
	}

	if (arc_list->count) {
		qsort(arc_list->ref, arc_list->count, sizeof(arc_list->ref[0]), &comp_arc_ref_by_id);
	}

#ifdef DEBUG
	{
		uint32_t arc_ids[MBM_ARC_CHANNEL_COUNT];
		size_t i;
		for (i = 0; i < arc_list->count; i++) {
			arc_ids[i] = arc_list->ref[i].id;
		}
		log_debug("N of arcs of the slave %s: %u", slave->dev_sn_str, i);
		log_debug_buf("cur arcs of slave", arc_ids, i * sizeof(arc_ids[0]), 'd');
	}
#endif
}

/* For first call use cur_index = -1, then for next calls use previous result of the function 
* return index > 0 of the next channel of not matched arc which can be deleted or 
* < 0 if there are no more such channels
*/
static int get_next_odd_arc_ref_index(arc_list_t *arc_list, int cur_index)
{
	int i;

	for (i = cur_index < 0 ? 0 : cur_index + 1; i < arc_list->count; i++) {
		if (!arc_list->ref[i].preserve) {
			log_debug("Arc ref to del found: ArcList[%d] = %s (channel %d)",
						i, arc_list->ref[i].id_str, arc_list->ref[i].channel);
			return i; /* found */
		}
	}
	log_debug("No more arc refs to del");
	return -1; /* not found */
}

/* Check arcids on the slave and clean slots as need :
* - read arc-ids of the slave
* - match arc-ids list to the new WL => COUNTmatched-arcs, COUNTmatched-wl, COUNTempty-arcs =>
*    COUNTdel = COUNTwl - COUNTmatched-wl - COUNTempty-arcs
* - while COUNTdel > 0 && there_is_next_not_matched_channel free the channel, COUNTdel--;
* Assume:
* - wl is sorted
*/
static int free_channels_for_wl(mbm_network_t *mb_net, mbm_slave_dev_t *slave,
								mbm_pk_wl_t *wl)
{
	arc_list_t arc_list;
	size_t i, j;
	size_t wl_match_count = 0;
	int del_count, count;
	int free_index;
	int r;
	size_t free_count;

	log_debug("slave %s: freeing channels for new WL as need", slave->dev_sn_str);

	/* get sorted arc list by reading current archives' headers */
	get_slave_arc_list(mb_net, slave, &arc_list);
	free_count = MBM_ARC_CHANNEL_COUNT - arc_list.count - arc_list.fail_count;

	log_debug("WL total: %u, Arc total: %u, used: %u, failed: %u, free: %u", wl->count,
				MBM_ARC_CHANNEL_COUNT, arc_list.count, arc_list.fail_count, free_count);

	if (wl->count < free_count) {
		log_debug("there are enough free channels, no need for matching WL to Arc");
		return 0;	// comment it for debugging
	}

	/* match both wl and arc_list (they are sorted by Arc ID - use this for matching optimization)*/
	for (i = 0, j = 0; i < wl->count && j < arc_list.count; i++) {
		arc_ref_t *arc_rec;
		arc_ref_t arc_item;
		size_t arc_match_index;
		arc_item.id = wl->arc_id[i];
		arc_rec = bsearch_index(&arc_item, &arc_list.ref[j], 
								arc_list.count - j, sizeof(arc_list.ref[0]),
								&comp_arc_ref_by_id, &arc_match_index);
		if (arc_rec) {
			arc_match_index += j; /* index in the array provided to the search, i.e. starting with offset j */
		}
		log_debug("WL[%u] (0x%08X) === ArcList[%d] (id:0x%08X/channel:%d): %smatched",
					i, wl->arc_id[i],
					arc_rec ? arc_match_index : -1, arc_rec ? arc_rec->id : 0xffffffff,
					arc_rec ? arc_rec->channel : -1,
					arc_rec ? "" : "NOT ");
		if (arc_rec) {
			/* matched */
			wl_match_count++;
			arc_rec->preserve = 1;
			j = arc_match_index + 1;
		}
	}

	del_count = wl->count - wl_match_count - free_count;
	log_debug("WL <-> Arc matched count: %u, free count: %d", wl_match_count, del_count);
	
	if (del_count < 0) {
		del_count = 0;
	}

	log_info(mbm_str_del_slave_arc_started, slave->dev_sn_str, slave->addr, del_count);

	/* re-order arc list by channel, so channels will be freed from low to high */
	if (arc_list.count) {
		qsort(arc_list.ref, arc_list.count, sizeof(arc_list.ref[0]), &comp_arc_ref_by_channel);
	}
	
	free_index = -1;
	count = del_count;
//del_count=count=1; // debug deleting
	while (count > 0) {
		/* find next free slot */
		free_index = get_next_odd_arc_ref_index(&arc_list, free_index);
		if (free_index < 0) {
			break;
		}

		/* delete archive */
		r = mbm_delete_slave_arc(mb_net->mb, slave, arc_list.ref[free_index].id);
		if (r) {
			/* failed to delete, try free another channel */
			continue;
		}
		/* deleted */
		count--;
		log_einfo(mbm_str_del_slave_arc, slave->dev_sn_str, slave->addr,
					arc_list.ref[free_index].id_str, arc_list.ref[free_index].channel);
	}
	
	log_info(mbm_str_del_slave_arc_done, slave->dev_sn_str, slave->addr,
			del_count - count);
	return 0;
}

static int forslave_set_user_white_list(mbm_network_t *mb_net,
									mbm_slave_dev_t *slave, void *data)
{
	int r;
	set_wl_info_t *sl_info = (set_wl_info_t *)data;
	mbm_wl_tab_t *wl_tab = sl_info->wl_tab;
	mbm_wl_index_t *wl_index_pk = &sl_info->wl_index_pk;
	size_t i;

	mbm_wl_index_rec_t item;
	mbm_wl_index_rec_t *rec;
	size_t index;	/* used for marking PKs for NOT ambiguous WL */

	size_t slave_index = 0;	/* used for marking PKs only for ambiguous WL */
	
	mbm_pk_wl_t new_wl;
	size_t direct_count;
	int pk0 = !wl_index_pk->tab[0].value && wl_index_pk->tab[0].count;	/* count can't be 0 actually.. */

	/* find index for the slave in the sl tab index */
	item.value = slave->dev_sn;
	rec = bsearch_index(&item, wl_index_pk->tab, wl_index_pk->count, sizeof(item),
				&mbm_comp_wl_index_rec_by_val, &index);

	if (sl_info->ambiguous) {
		if (!bsearch_index(&slave->dev_sn, sl_info->slave_ids, sl_info->slaves_count,
							sizeof(sl_info->slave_ids[0]), &uint32cmp, &slave_index)) {
			log_err(mbm_str_err_wl_set, slave->dev_sn_str, slave->addr, "internal:1");
			return 1;
		}
	}
	
	/* if slave is not provided with direct records, if no 0-PK records, clean WL on the slave */
	if ((!rec || !rec->count) && !pk0) { /* count can't be 0 actually.. */
		log_debug("slave %s: no direct records, no 0-PK records - clean WL", slave->dev_sn_str);
		r = mbm_clean_white_list(mb_net);
		if (!r) {
			log_einfo(mbm_str_slave_wl_cleaned, slave->dev_sn_str);
			sl_info->clean_count++;
		} else {
			log_err(mbm_str_err_wl_clean, slave->dev_sn_str, slave->addr, 
					modbus_strerror(errno));
			sl_info->fail_count++;
		}
		return 1; /* next slave */
	}

	log_debug("slave %s: direct records and/or 0-PK records found", slave->dev_sn_str);

	new_wl.count = 0;

	/* if index for the slave found, i.e. there are direct records, install them to the slave */
	if (rec) {
		/* copy all slave's special WL records to new WL */
		for (; new_wl.count < rec->count; new_wl.count++) {
			if (new_wl.count >= MBM_WHITE_LIST_PK_RECORDS) {
				log_err(mbm_str_err_wl_set, slave->dev_sn_str, slave->addr, "internal:2");
				return 1;
			}
			new_wl.arc_id[new_wl.count] = wl_tab->tab[rec->start + new_wl.count].arc_id;
		}

		qsort(new_wl.arc_id, new_wl.count, sizeof(new_wl.arc_id[0]), &uint32cmp);
		log_debug("slave %s: direct records copied and sorted: added %u records",
					slave->dev_sn_str, new_wl.count);
	}
	direct_count = new_wl.count;	/* count of 'direct' records */

	/* add ambiguous 0-records if they exist , if they are not in the new WL yet and while there
	* is room in the new WL 
	*/
	if (pk0) {
		for (i = wl_index_pk->tab[0].start;
			i < wl_index_pk->tab[0].count && new_wl.count < MBM_WHITE_LIST_PK_RECORDS;
			i++) { /* here new_wl.count >= MBM_WHITE_LIST_PK_RECORDS is not error, just stop adding records */
			if (!direct_count || 
				!bsearch(&wl_tab->tab[i].arc_id, new_wl.arc_id, direct_count,
						sizeof(new_wl.arc_id[0]), &uint32cmp)) {
				new_wl.arc_id[new_wl.count++] = wl_tab->tab[i].arc_id;
			}
		}
		log_debug("slave %s: 0-PK records copied: added %u records",
					slave->dev_sn_str, new_wl.count - direct_count);
	}
	
	r = mbm_write_white_list(mb_net, &new_wl);
	if (!r) {
		log_einfo(mbm_str_slave_wl_set, slave->dev_sn_str);

		/* if WL is ambiguous, use slave_ids[] to mark successful slaves - then 
		* RSSI stats will be gathered for these slaves only
		* if WL is not ambiguous - mark slaves in wl_index_pk and WL records in wl_tab
		*/
		if (sl_info->ambiguous) {
			MBM_REC_MARK_AND_COUNT(&sl_info->slave_mark, slave_index);
			/* counting successes will be done at the sencond step, when WL will not be ambiguous */
		} else { /* rec is !NULL - by conditions above */
			index -= !wl_index_pk->tab[0].value;
			MBM_REC_MARK_AND_COUNT(wl_index_pk, index);
			sl_info->set_count++;
			sl_info->wl_rec_count += new_wl.count;
			/* mark successful WL records as well for saving only them */
			log_debug("slave %s: marking successfully installed records", slave->dev_sn_str);
			for (i = 0; i < rec->count; i++) {
				MBM_REC_MARK_AND_COUNT(wl_tab, rec->start + i);
			}
		}
	} else {
		sl_info->fail_count++;	/* failure counted here independently of ambiguity flag */
		log_err(mbm_str_err_wl_set, slave->dev_sn_str, slave->addr, 
					modbus_strerror(errno));
		return 1; /* no sense to check and clean arcs if WL setting failed, pass to the next slave */
	}

	/* new WL has been installed on the slave - 
	* we need to ensure that slave has enough free slots for new WL records to 
	* collect arcs with respective IDs.
	* So match slave channels against new WL and free channels as need.
	*/
	free_channels_for_wl(mb_net, slave, &new_wl);

	return 1; /* next slave */
}

static int forslave_set_auto_white_list(mbm_network_t *mb_net,
										mbm_slave_dev_t *slave, void *data)
{
	int r;
	set_wl_info_t *sl_info = (set_wl_info_t *)data;
	mbm_wl_tab_t *wl_tab = sl_info->wl_tab;
	mbm_wl_index_t *wl_index_pk = &sl_info->wl_index_pk;
	mbm_wl_index_rec_t *rec;
	size_t index;	/* used for marking PKs */
	mbm_wl_index_rec_t item;
	mbm_pk_wl_t new_wl;
	size_t i;

	/* find index for the slave in the sl tab index */
	item.value = slave->dev_sn;
	rec = bsearch_index(&item, wl_index_pk->tab, wl_index_pk->count, sizeof(item),
				&mbm_comp_wl_index_rec_by_val, &index);
	if (!rec || !rec->count) { /* !rec->count is  not possible case.. */
		log_debug("slave %s: no auto records - clean WL", slave->dev_sn_str);
		r = mbm_clean_white_list(mb_net);
		if (!r) {
			log_einfo(mbm_str_slave_wl_cleaned, slave->dev_sn_str);
			sl_info->clean_count++;
		} else {
			log_err(mbm_str_err_wl_clean, slave->dev_sn_str, slave->addr, 
					modbus_strerror(errno));
			sl_info->fail_count++;
		}
		return 1; /* next slave */
	}

	/* copy all slave's special WL records to new WL */
	for (new_wl.count = 0; new_wl.count < rec->count; new_wl.count++) {
		if (new_wl.count >= MBM_WHITE_LIST_PK_RECORDS) {
			log_err(mbm_str_err_wl_set, slave->dev_sn_str, slave->addr, "internal:3");
			return 1;
		}
		new_wl.arc_id[new_wl.count] = wl_tab->tab[rec->start + new_wl.count].arc_id;
	}
	qsort(new_wl.arc_id, new_wl.count, sizeof(new_wl.arc_id[0]), &uint32cmp);

	r = mbm_write_white_list(mb_net, &new_wl);
	if (!r) {
		log_einfo(mbm_str_slave_wl_set, slave->dev_sn_str);
		/* update slave mask - bit set == WL installed OK */
		index -= !wl_index_pk->tab[0].value;
		MBM_REC_MARK_AND_COUNT(wl_index_pk, index);
		sl_info->set_count++;
		sl_info->wl_rec_count += new_wl.count;
		for (i = 0; i < rec->count; i++) {
			MBM_REC_MARK_AND_COUNT(wl_tab, rec->start + i);
		}
	} else {
		sl_info->fail_count++;
		log_err(mbm_str_err_wl_set, slave->dev_sn_str, slave->addr, 
					modbus_strerror(errno));
	}
	return 1;	/* next slave */
}

static void shrink_slave_list(set_wl_info_t *sl_info)
{
	size_t i, count = 0;
	uint32_t *gap = NULL;

	for (i = 0; i < sl_info->slaves_count; i++) {
		if (MBM_REC_MARKED(&sl_info->slave_mark, i)) {
			/* leave it, move as need */
			if (gap) {
				*gap++ = sl_info->slave_ids[i];
			}
			count++;
		} else {
			if (!gap) {
				gap = &sl_info->slave_ids[i];
			}
		}
	}
	sl_info->slaves_count = count;
}

/* ==================================*/
/*  Interface methods */
/* ==================================*/

int mbm_init_wl_fs(mbm_context_t *ctx)
{
	int r = 0;
	char path[MBM_PATH_MAX];
	const char *service_dirs[] = { SUBDIR_SERVICE, SUBDIR_SERVICEOK, NULL };
	const char **svc_dir;

	for (svc_dir = service_dirs; *svc_dir && !r; svc_dir++) {
		strcpy(path, ctx->root_dir);	/* see init_root_dir - it ensures that root_dir is less than MBM_PATH_MAX chars */
		log_debug("initializing service dir: %s/%s", path, *svc_dir);
		r = mbm_init_sub_dir(path, *svc_dir, ctx->root_dir_len);
		if (!r) {
			log_debug("initializing service dir: %s/%s", path, SUBDIR_SERVICE_SETLIST);
			r = mbm_init_sub_dir(path, SUBDIR_SERVICE_SETLIST, ctx->root_dir_len);

			if (!r) {
				/* check longest path length of setList.csv */
				r = mbm_make_path(path, MBM_FILENAME_SETLIST_REJECTED, path);
			}
		}
	}
	return r;
}

static int sleep_for_wl(mbm_context_t *ctx)
{
	int r;
	
	/*TODO:  release LOCK ? */
	if (ctx->cfg.delay_min > 0) {
		int slaves_count = ctx->mb_net.slaves_count;
		mbm_modbus_done(&ctx->mb_net);
		
		log_info(mbm_str_make_wl_wait, ctx->cfg.delay_min / 60,
										ctx->cfg.delay_min % 60);
		sleep(ctx->cfg.delay_min * 60);
		log_info(mbm_str_make_wl_continue);

		/* re-init modbus and network */
		r = mbm_modbus_init(&ctx->mb_net, &ctx->cfg.port, ctx->cfg.log_level >= APP_DEBUG);
		if (r) {
			log_err(mbm_str_err_modbus_reinit);
			return r;
		}
		if (slaves_count != ctx->mb_net.slaves_count) {
			log_warn(mbm_str_warn_diff_slaves_count, slaves_count,
						ctx->mb_net.slaves_count);
		}
	}

	return 0;
}

int mbm_make_white_list(mbm_context_t *ctx)
{
	int r = 0;
	mbm_wl_data_t *wl_data;
	mbm_wl_tab_t *src_tab;
	char path[MBM_PATH_MAX];

	log_info(mbm_str_make_wl_started);

	wl_data = (mbm_wl_data_t *)(ctx->wl_data);
	src_tab = &wl_data->wl_tab;

	/* clean while lists on all slaves - ignore errors */
	mbm_clean_white_lists(&ctx->mb_net);

	r = sleep_for_wl(ctx);
	if (r) {
		return r;
	}

	r = mbm_make_white_list_source_table(&ctx->mb_net, NULL, 0, 0, src_tab);

	if (!r) {
		r = mbm_mark_white_list_records(src_tab);
		if (!r) {
			char *p;
			/* directory structure is made and path length checked earlier */
			p = path;
			memcpy(p, ctx->root_dir, ctx->root_dir_len);
			p += ctx->root_dir_len;
			*p++ = '/';
			memcpy(p, SUBDIR_SERVICE, sizeof(SUBDIR_SERVICE));
			p += (sizeof(SUBDIR_SERVICE) - 1);
			*p++ = '/';
			memcpy(p, SUBDIR_SERVICE_SETLIST, sizeof(SUBDIR_SERVICE_SETLIST));
			p += (sizeof(SUBDIR_SERVICE_SETLIST) - 1);
			*p++ = '/';
			memcpy(p, MBM_FILENAME_SETLIST, sizeof(MBM_FILENAME_SETLIST));
			r = mbm_save_white_list_from_src(path, ctx->root_dir_len, src_tab);
		}
	}

	log_info(mbm_str_make_wl_done);
	return r;
}

int mbm_set_white_list(mbm_context_t *ctx)
{
	set_wl_info_t sl_info;
	mbm_wl_data_t *wl_data;
	mbm_wl_tab_t *wl_tab;
	mbm_wl_index_t *wl_index_pk;
	char path1[MBM_PATH_MAX];
	char path2[MBM_PATH_MAX];
	int r;
	struct stat sbuf;

	log_info(mbm_str_set_wl_started);

	memset(&sl_info, 0, sizeof(sl_info));
	
	wl_data = (mbm_wl_data_t *)(ctx->wl_data);
	wl_tab = &wl_data->wl_tab;
	sl_info.wl_tab = wl_tab;
	wl_index_pk = &sl_info.wl_index_pk;

	do {
		/* prepare source and destination path of setList.csv */
		mbm_make_path(ctx->root_dir, SUBDIR_SERVICE, path1);
		mbm_make_path(path1, SUBDIR_SERVICE_SETLIST, path1);
		mbm_make_path(path1, MBM_FILENAME_SETLIST, path1);

		mbm_make_path(ctx->cfg.state_dir, MBM_FILENAME_SETLIST, path2);

		/* check whether /service/setList/setList.csv exists */
		r = stat(path1, &sbuf);
		if (!r) {
			if (!S_ISREG(sbuf.st_mode)) {
				log_err(mbm_str_err_bad_set_list_file, &path1[ctx->root_dir_len + 1]);
				r = -1;
				break;
			}
			log_info(mbm_str_set_list_file_found, &path1[ctx->root_dir_len + 1]);
			
			/* move /service/setList/setList.csv to state directory */
			r = mbm_move_file(path1, path2);
			if (r) {
				log_err(mbm_str_err_use_set_list_file, strerror(-r));
				break;
			}
		} else {
			/* check whether setList.csv exists in state directory */
			r = stat(path2, &sbuf);
			if (r || !S_ISREG(sbuf.st_mode)) {
				log_info(mbm_str_no_set_list_file);
				r = 0;
				break;
			}
			log_info(mbm_str_set_list_file_accepted_found);
		}

		/* load user-setList from dst_path file - result sorted by PK, Arc */
		r = mbm_load_white_list(path2, wl_tab);
		if (r) {
			/* move set-list file to serviceOK (rejected) */
			move_processed_set_list_file(path2, ctx->root_dir, ctx->root_dir_len,
											MBM_FILENAME_SETLIST_REJECTED);
			break;
		}

		if (!wl_tab->count) {
			/* clean white lists and exit */
			log_info(mbm_str_set_list_empty);
			sl_info.clean_count = mbm_clean_white_lists(&ctx->mb_net);
			sl_info.fail_count = ctx->mb_net.slaves_count - sl_info.clean_count;

			/* clean wl stats file if exists */
			mbm_make_path(ctx->cfg.state_dir, MBM_FILENAME_WL_STATS, path1);
			r = unlink(path1);
			log_debug("wl stats file %s removed, rc=%d (if !0, errno: %s)",
						path1, r, strerror(errno));

			/* move set-list file to serviceOK */
			move_processed_set_list_file(path2, ctx->root_dir, ctx->root_dir_len,
											MBM_FILENAME_SETLIST);
			break;
		}

		/* there are records of WL to set, continue checking and processing it... */

		/* index set list table for further processing */
		r = mbm_make_white_list_index_by_pk(wl_tab, wl_index_pk);
		if (r) {
			move_processed_set_list_file(path2, ctx->root_dir, ctx->root_dir_len,
											MBM_FILENAME_SETLIST_REJECTED);
			break;
		}

		/* get slaves IDs into array, sort the array */
		mbm_get_active_slaves_ids(&ctx->mb_net, sl_info.slave_ids, &sl_info.slaves_count);
		qsort(sl_info.slave_ids, sl_info.slaves_count, sizeof(sl_info.slave_ids[0]), &uint32cmp);

#ifdef DEBUG
		{
			size_t i;
			char id_str[9];
			for (i = 0; i < sl_info.slaves_count; i++) {
				log_debug("sorted slave_ids[%u]=%s", i, devsn_to_str(sl_info.slave_ids[i], id_str));
			}
		}
#endif

		/* check whether all PK from setList are present and active on the bus */
		r = is_white_list_pk_on_bus(wl_index_pk, sl_info.slave_ids, sl_info.slaves_count);
		if (!r) {
			move_processed_set_list_file(path2, ctx->root_dir, ctx->root_dir_len,
											MBM_FILENAME_SETLIST_REJECTED);
			break;
		}

		/* white list is ambiguous when more than one PKs have the same ArcID, 
		* which means use the best of ones, or when there is a 0 PKID, which means 
		* use the best of all
		*
		* calc the flag - it's needed for further processing
		*/
		sl_info.ambiguous = is_white_list_ambiguous(wl_tab, wl_index_pk);

		/* set user setList to slaves: 
		* - clean WL on slaves not mentioned by user
		* -- calc slaves count (success and failure)
		* - compile and set to slaves new WLs consisting of exact and possible ambiguous values
		* -- calc slaves count (success and failure) if !ambiguous list
		* - free slave's archive slots for new IDs as need
		* Mark PKs where WL was installed successfully, mark successfully installed WL records:
		*  - ambiguous WL: mark PKs in slave_ids[] to make later RSSI statsitics for them only
		*  - !ambigous WL: mark PKs in wl_index_pk, mark WL records in wl_tab
		*/
		mbm_foreach_active_slave(&ctx->mb_net, forslave_set_user_white_list,
									NULL, &sl_info);

		/* two cases for slaves which were marked as "WL installed on successfully":
		* - ambiguous - gather arcs, make src table, make WL by best RSSI, compile and 
		*                       install new WLs, make WLstats and actual setList.csv in OK dir.
		* - !ambiguous - WLs are installed, so just make WL stats and actual setList.csv in OK dir.
		*/
		if (sl_info.ambiguous) {
			/* - sleep for a the specified time
			* - wake, re-conf network
			*/
			r = sleep_for_wl(ctx);
			if (r) {
				move_processed_set_list_file(path2, ctx->root_dir, ctx->root_dir_len,
											MBM_FILENAME_SETLIST_ERROR);
				break;
			}

			/* -gather RSSI stats for all marked PKs from slave_ids[] */
			
			/* remove from slave_ids[] not marked entries */
			shrink_slave_list(&sl_info);

			/* wl_tab will contain WL src data from now */
			r = mbm_make_white_list_source_table(&ctx->mb_net, sl_info.slave_ids,
													sl_info.slaves_count, 1, wl_tab);
			if (r) {
				move_processed_set_list_file(path2, ctx->root_dir, ctx->root_dir_len,
											MBM_FILENAME_SETLIST_ERROR);
				break;
			}
			
			/* - compile WL */
			r = mbm_mark_white_list_records(wl_tab);
			if (r) {
				move_processed_set_list_file(path2, ctx->root_dir, ctx->root_dir_len,
											MBM_FILENAME_SETLIST_ERROR);
				break;
			}
			
			/* transform source tab to wl tab (order is preserved by ArcID */
			mbm_shrink_white_list_table(wl_tab);

			/* re-order by PK, Arc for setting WLs to PKs */
			qsort(wl_tab->tab, wl_tab->count, sizeof(wl_tab->tab[0]),
					&mbm_comp_wl_rec_by_pk_arc);

			/* index set list table for further processing */
			r = mbm_make_white_list_index_by_pk(wl_tab, wl_index_pk);
			if (r) {
				move_processed_set_list_file(path2, ctx->root_dir, ctx->root_dir_len,
												MBM_FILENAME_SETLIST_ERROR);
				break;
			}
			
			/* set WLs to slaves, 
			* mark slaves where WL was set successfully, mark successfully set WL records
			* count successes and failures
			*/
			mbm_foreach_active_slave(&ctx->mb_net,
								forslave_set_auto_white_list, NULL, &sl_info);

		}
		
		/*  save actual setList.csv from wl_tab (marked, i.e. successfully installed on PKs records only)
		* - save WL stats by wl_index_pk (marked PKs)
		*/

		/* get rid of not marked (failed to install on PK) records in WL */
		mbm_shrink_white_list_table(wl_tab);
		/* re-order WL by ArcID */
		qsort(wl_tab->tab, wl_tab->count, sizeof(wl_tab->tab[0]), &mbm_comp_wl_rec_by_arc);

		/* prepare file path for actual setList to be saved */
		mbm_make_path(ctx->root_dir, SUBDIR_SERVICEOK, path1);
		mbm_make_path(path1, SUBDIR_SERVICE_SETLIST, path1);
		mbm_make_path(path1, MBM_FILENAME_SETLIST, path1);

		/* save actual WL in format: ArcID;PKID */
		r = mbm_save_white_list(path1, wl_tab, 0);
		if (r) {
			log_err(mbm_str_err_wl_file, &path1[ctx->root_dir_len + 1], strerror(errno));
			/* do nothing special - file just not saved */
			r = 0;	/* err ignored */
		} else {
			log_info(mbm_str_wl_file_saved, &path1[ctx->root_dir_len + 1]);
		}

		/* remove setList.csv form state dir - in order to prevent repetition of the rocessing has been done */
		unlink(path2);

		/* prepare file path for stats */
		mbm_make_path(ctx->cfg.state_dir, MBM_FILENAME_WL_STATS, path1);
		r = mbm_save_white_list_stats(path1, -1, wl_index_pk, 1);
	}while (0);

	log_info(mbm_str_set_wl_done, sl_info.clean_count,
				sl_info.set_count, sl_info.wl_rec_count, sl_info.fail_count);

	return r;
}

static int forslave_read_white_list(mbm_network_t *mb_net, mbm_slave_dev_t *slave,
									void *data)
{
	int r;
	mbm_pk_wl_t wl;
	mbm_wl_tab_t *wl_tab = (mbm_wl_tab_t *)data;
	size_t i;

	r = mbm_read_white_list(mb_net, &wl);
	if (r) {
		log_err("DBG: failed to read WL for PK %s: %s", slave->dev_sn_str, modbus_strerror(errno));
		return 1; /* continue with next slave */
	}

	log_info("DBG: wl read for PK %s: records count=%u", slave->dev_sn_str, wl.count);

	for (i = 0; i < wl.count; i++) {
		wl_tab->tab[wl_tab->count].pk_id = slave->dev_sn;
		wl_tab->tab[wl_tab->count].arc_id = wl.arc_id[i];
		wl_tab->count++;
	}

	return 1;	
}

/* now is for debugging purposes only, so no Russian messages etc. */
int mbm_get_actual_white_list(mbm_context_t *ctx)
{
	mbm_wl_data_t *wl_data;
	mbm_wl_tab_t *wl_tab;
	mbm_wl_index_t wl_index_pk;
	char path[MBM_PATH_MAX];
	int r;

	log_info("getting actual WL started");

	wl_data = (mbm_wl_data_t *)(ctx->wl_data);
	wl_tab = &wl_data->wl_tab;

	wl_tab->count = 0;

	mbm_foreach_active_slave(&ctx->mb_net, forslave_read_white_list, NULL, wl_tab);

	if (wl_tab->count) {
		size_t dir_len;
		
		mbm_make_path(ctx->root_dir, SUBDIR_SERVICEOK, path);
		mbm_make_path(path, SUBDIR_SERVICE_SETLIST, path);
		dir_len = strlen(path);
		
		qsort(wl_tab->tab, wl_tab->count, sizeof(wl_tab->tab[0]), &mbm_comp_wl_rec_by_arc);
		mbm_make_path(path, MBM_FILENAME_SETLIST_ACTUAL, path);
		r = mbm_save_white_list(path, wl_tab, 0);
		if (!r) {
			log_info("actual WL (sorted by Arc ID) saved: %s", &path[ctx->root_dir_len + 1]);
		} else {
			log_err("error when saving actual WL (sorted by Arc ID): %s", strerror(errno));
		}

		qsort(wl_tab->tab, wl_tab->count, sizeof(wl_tab->tab[0]), &mbm_comp_wl_rec_by_pk_arc);
		path[dir_len] = 0;
		mbm_make_path(path, MBM_FILENAME_SETLIST_ACTUAL_PK, path);
		r = mbm_save_white_list(path, wl_tab, 1);
		if (!r) {
			log_info("actual WL (sorted by PK ID, Arc ID) saved: %s", &path[ctx->root_dir_len + 1]);
		} else {
			log_err("error when saving actual WL (sorted by PK ID, Arc ID): %s", strerror(errno));
		}

	}

	mbm_make_path(ctx->cfg.state_dir, MBM_FILENAME_WL_STATS, path);
	r = mbm_make_white_list_index_by_pk(wl_tab, &wl_index_pk);
	if (r) {
		wl_index_pk.count = 0;	/* reset on error */
		log_info("WL stats reset to be removed due to the error");
	}
	r = mbm_save_white_list_stats(path, -1, &wl_index_pk, 0);

	log_info("getting actual WL done: records=%u", wl_tab->count);

	return 0;
}

