#include <unistd.h>
#include <errno.h>
#include <stdio.h>
#include <string.h>

#include "mbm_defs.h"

#include "mbm_strings.h"
#include "app_log.h"
#include "mbm_utils.h"

#include "mbm_network.h"

/*============================================================================*/
/* Local methods                                                              */
/*============================================================================*/

static void update_slave_status(mbm_slave_dev_t *slave, uint16_t status)
{
	slave->status = status;

	slave->sensor_count = status >> MBM_ST_OFF_SENSOR_COUNT; 
	slave->flags.fail_flash = (status >> MBM_ST_OFF_FLASH) & 1;
	slave->flags.fail_radio = (status >> MBM_ST_OFF_RADIO) & 1;
	slave->flags.no_arc = (status >> MBM_ST_OFF_NO_ARC) & 1;
	slave->flags.no_mon_arc = (status >> MBM_ST_OFF_NO_MON_ARC) & 1;
}

static int forslave_get_info(mbm_network_t *mb_net, mbm_slave_dev_t *slave, void *data)
{
	uint16_t info[MBM_INFO_REG_COUNT];	/* name, SN, status */
	uint8_t slave_id[MODBUS_RTU_MAX_ADU_LENGTH - 4];	/* 1(addr) + 1(fc) + 2 (rc) */
	int r, i, j;
	modbus_t *mb = mb_net->mb;
	int attempts = MBM_MODBUS_RETRY;

	while (1) {
		r = modbus_read_registers(mb, MBM_INFO_REG, MBM_INFO_REG_COUNT, info);
		if (r < 0) {
			attempts--;
			if (attempts <= 0) {
				/* sn str now is empty */
				log_err(mbm_str_err_slave_info, slave->dev_sn_str, slave->addr, 
						modbus_strerror(errno));
				/* should not happen, but if happen - mark the slave */
				sprintf(slave->dev_name, "Unk%03d", slave->addr);
				return 1; /* continue */
			}
			log_debug("get slave info error: %s (%d) - retry", modbus_strerror(errno), errno);
			continue;
		}
		break;
	}

	for (i = MBM_INFO_IDX_NAME, j = 0; i < MBM_INFO_IDX_NAME + 3; i++) {
		slave->dev_name[j++] = MODBUS_GET_HIGH_BYTE(info[i]);
		slave->dev_name[j++] = MODBUS_GET_LOW_BYTE(info[i]);
	}
	/* MODBUS_GET_INT32_FROM_INT16: low register becomes high word in the result dword */
	slave->dev_sn = MODBUS_GET_INT32_FROM_INT16(info, MBM_INFO_IDX_SN);
	update_slave_status(slave, info[MBM_INFO_IDX_STATUS]);

	devsn_to_str(slave->dev_sn, slave->dev_sn_str);

	r = modbus_report_slave_id(mb, slave_id);
	if (r > 1) {
		char *start, *end;
		size_t len;
		start = strchr((const char *)&slave_id[1], ' ');
		if (start) {
			start++;
			end = strchr(start, ' ');
			if (end) {
				len = end - start;
				if (len > MBM_MAX_SLAVE_VER_LEN) {
					len = MBM_MAX_SLAVE_VER_LEN;
				}

				if (len) {
					memcpy(slave->fw_ver, start, len);
					slave->fw_ver[len] = 0;
				}
			}
		}
	}
	if (!slave->fw_ver[0]) {
		strcpy(slave->fw_ver, "unk");
	}
	
	log_info(mbm_str_slave_found, slave->addr, slave->dev_sn_str,
			slave->dev_name, slave->fw_ver,
			slave->status, slave->sensor_count, 
			slave->flags.fail_flash ? mbm_str_error : "OK",
			slave->flags.fail_radio ? mbm_str_error : "OK",
			slave->flags.no_mon_arc ? "" : mbm_str_nosp,
			slave->flags.no_arc ? "" : mbm_str_nosp);
	return 1;
}

/* note: assumes that slaves info in ctx is initialized to 0 */
static void fetch_slaves_info(mbm_network_t *mb_net)
{
	mbm_foreach_active_slave(mb_net, &forslave_get_info, 
								mbm_str_err_slave_info, NULL);
}

/* note: assumes that slaves info in ctx is initialized to 0 */
static int assign_slave_addrs(mbm_network_t *mb_net)
{
	int r;
	int attempts;
	int count;
	int addr;

	modbus_t *mb = mb_net->mb;
	
	/* start addr assigning - target addr:=0xfe */
	r = modbus_set_slave(mb, MBM_CONFIG_SLAVE_DEV);
	if (r < 0) {
		log_err(mbm_str_err_libmodbus, modbus_strerror(errno));
		return -1;	/* fatal: can't assign addresses */
	}

	r = modbus_write_register(mb, 
		MBM_RESET_ADDR_REG, MBM_RESET_ALL_ADDRS);
	log_debug("reset all addresses, rc(ignored)=%d: %s",
			 	r, r < 0 ? modbus_strerror(errno) : "OK");

	/* assign addresses */
	attempts = 0;
	mb_net->max_addr = MBM_SLAVE_ADDR_MIN;
	do {
		usleep(50 * 1000); /* wait a bit to avoid errors w/o debug + by Semenov - 500*/

		/* set cur addr */
		r = modbus_write_register(mb, MBM_SET_ADDR_REG, mb_net->max_addr);
		if (r == 1) {
			log_debug("address %d assigned OK, going on..", mb_net->max_addr);
			attempts = 0;
			mb_net->max_addr++;
			if (mb_net->max_addr > MBM_SLAVE_ADDR_MAX) {
				log_debug("all possible addresses are assigned, the job's well done");
				break;
			}
		} else { /* assume r = -1 (error)*/
			attempts++;
			log_warn(mbm_str_warn_set_slave_addr, mb_net->max_addr, 
						attempts, modbus_strerror(errno));

			/* reset addr */
			r = modbus_write_register(mb, MBM_RESET_ADDR_REG, mb_net->max_addr);
			log_debug("attempt: %d - addr %d reset, rc(ignored)=%d: %s", 
					attempts, mb_net->max_addr, r, r < 0 ? modbus_strerror(errno) : "OK");

			if (attempts >= MBM_SET_SLAVE_ADDR_ATTEMPTS_MAX) {
				log_err(mbm_str_err_set_slave_addr, mb_net->max_addr);
				break;
			}
		}
	} while (1);

	/* correct max valid addr for both exit cases */
	mb_net->max_addr--;	
	count = mb_net->max_addr - (MBM_SLAVE_ADDR_MIN - 1);
	log_debug("addresses assigned for %d slaves (max_addr=%d)",
				count, mb_net->max_addr);

	if (count <= 0) {
		return -1;
	}
	
	/* verify addresses */
	for (addr = MBM_SLAVE_ADDR_MIN; addr <= mb_net->max_addr; addr++) {
		int i;
		uint16_t a;
		int saved_errno = 0;
		
		/* set slave addr: = current */
		r = modbus_set_slave(mb, addr);
		if (r < 0) {
			log_err(mbm_str_err_slave_addr_verify, addr, modbus_strerror(errno));
			continue;	/* not fatal: try check another addr */
		}

		for (i = 0; i < MBM_VERIFY_SLAVE_ADDR_COUNT; i++) {
			int attempts = MBM_MODBUS_RETRY;

			while (1) {
				r = modbus_read_registers(mb, MBM_SET_ADDR_REG, 1, &a);
				saved_errno = errno;
				log_debug("addr %d verification %d: rc=%d, val=%u", addr, i, r, a);
				if (r < 0) {
					attempts--;
					if (attempts <= 0) {
						log_debug("verify slave addr error: %s (%d) - retry",
									modbus_strerror(saved_errno), saved_errno);
						break;
					}
					continue;
				}
				break;
			}

			if (r < 0 || a != addr) {
				break;
			}
		}

		if (r < 0 || a != addr) {
			log_err(mbm_str_err_slave_addr_verify, addr, 
				r < 0 ? modbus_strerror(saved_errno) : mbm_str_received_addr_different);
			continue;
		}

		mb_net->slaves[addr].flags.addr_check_passed = 1;
		mb_net->slaves_count++;

		log_debug("slave addr %d verified", addr);
	}

	log_info(mbm_str_slave_addrs_assigned, 
		MBM_SLAVE_ADDR_MIN, mb_net->max_addr, mb_net->slaves_count);

	return mb_net->slaves_count > 0 ? 0 : -1;
}

/*============================================================================*/
/* Interface methods                                                          */
/*============================================================================*/

int mbm_modbus_init(mbm_network_t *mb_net, mbm_port_config_t *port_cfg, 
						int mb_debug_on)
{
	int r;
	modbus_t *mb;
	
	mb_net->mb = NULL;

	/* Modbus ops */
	mb = modbus_new_rtu(port_cfg->tty_dev, port_cfg->baud_rate, port_cfg->parity, 
						port_cfg->data_bits, port_cfg->stop_bits);
	if (!mb) {
		log_err(mbm_str_err_libmodbus, modbus_strerror(errno));
		goto err_new;
	}
	log_debug("modbus context created: %p", mb);

#ifdef DEBUG
	if (mb_debug_on) {
		modbus_set_debug(mb, 1);
	}
#endif

	r = modbus_rtu_get_serial_mode(mb);
	if (r == -1) {
		log_warn("failed to determine serial mode: %s", modbus_strerror(errno));
	} else {
		log_debug("serial mode: %s", 
			r == MODBUS_RTU_RS232 ? "RS232" :
			r == MODBUS_RTU_RS485 ? "RS485" : "invalid");
	}

#ifdef DEBUG
	{
		struct timeval tv;
		modbus_get_response_timeout(mb, &tv);
		log_debug("response timeout: %d sec, %d usec", tv.tv_sec, tv.tv_usec);
		modbus_get_byte_timeout(mb, &tv);
		log_debug("byte timeout: %d sec, %d usec", tv.tv_sec, tv.tv_usec);
	}
#endif

	/* connect */
	r = modbus_connect(mb);
	if (r) {
		log_err(mbm_str_err_libmodbus, modbus_strerror(errno));
		goto err_conn;
	}
	log_debug("modbus connection established");

	r = modbus_rtu_set_serial_mode(mb, MODBUS_RTU_RS485);
	if (r == -1) {
		log_err("failed to set RS485 serial mode: %s", modbus_strerror(errno));
		goto err_setmode;
		
	} else {
		log_debug("RS485 serial mode set");
	}

	modbus_set_error_recovery(mb, MODBUS_ERROR_RECOVERY_PROTOCOL);

	mb_net->mb = mb;
	r = mbm_network_configure(mb_net);
	if (r) {
		goto err_network;
	}
	
	log_debug("mbm_modbus_init OK");

	return 0;
	
err_network:
	mb_net->mb = NULL;
err_setmode:
	modbus_close(mb);
err_conn:
	modbus_free(mb);
err_new:
	return -1;
}

void mbm_modbus_done(mbm_network_t *mb_net)
{
	if (mb_net->mb) {
		modbus_close(mb_net->mb);
		log_debug("modbus connection closed");
		modbus_free(mb_net->mb);
		log_debug("modbus context freed");
		mb_net->mb = NULL;
	}
}

int mbm_network_configure(mbm_network_t *mb_net)
{
	int r;

	mb_net->slaves_count = 0;
	mb_net->max_addr = 0;
	memset(mb_net->slaves, 0, sizeof(mb_net->slaves));
	
	r = assign_slave_addrs(mb_net);
	if (r) {
		log_err(mbm_str_err_assign_addrs);
		return r;;
	}

	fetch_slaves_info(mb_net);
	return r;
}

/* err_msg - optional err message for modbus_set_slave() failure, 
* data - optional specific data 
*/
void mbm_foreach_active_slave(mbm_network_t *mb_net, process_slave_cb process, 
									const char *err_msg, void *data)
{
	int addr;
	int r;

	for (addr = MBM_SLAVE_ADDR_MIN; addr <= mb_net->max_addr; addr++) {
		mbm_slave_dev_t *slave = &mb_net->slaves[addr];

		slave->addr = addr;	/* ensure correct slave's addr value */

		if (!slave->flags.addr_check_passed) {
			log_debug("skip addr %d (check not passed)", addr);
			continue;
		}

		r = modbus_set_slave(mb_net->mb, addr);
		if (r < 0) {
			if (err_msg) {
				log_err(err_msg, slave->dev_sn_str, addr, modbus_strerror(errno));
			} else {
				log_err(mbm_str_err_libmodbus, modbus_strerror(errno));
			}
			continue;	/* not fatal: try another device */
		}

		r = process(mb_net, slave, data);
		if (!r) {
			break;
		}
	}
}

void mbm_get_active_slaves_ids(mbm_network_t *mb_net,
									uint32_t slave_ids[MBM_SLAVE_MAX_COUNT],
									size_t *slaves_count)
{
	int addr;
	int i = 0;
	for (addr = MBM_SLAVE_ADDR_MIN; addr <= mb_net->max_addr; addr++) {
		mbm_slave_dev_t *slave = &mb_net->slaves[addr];
		if (slave->flags.addr_check_passed) {
			slave_ids[i++] = slave->dev_sn;
		}
	}
	*slaves_count = i;
}

