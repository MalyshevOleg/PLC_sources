#ifndef _MBM_INIT_H_
#define _MBM_INIT_H_

#include "mbm_context.h"

/* Initialize:
* - startup data (args, dirs, etc.)
* - logfile directory and file
* - alloc memory
*/
extern int mbm_init(int argc, char *argv[], mbm_context_t **ctxp);

/** Finalization
* - free allocated memory
*/
extern void mbm_done(mbm_context_t **ctxp);

#endif /* _MBM_INIT_H_ */
