#include <sys/types.h>
#include <unistd.h>
#include <limits.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <time.h>
#include <dirent.h>

#include "mbm_init.h"
#include "mbm_wl.h"

int mbm_isdst = 0;

const char *app_mode_log_sub_dirs[MBM_MODE_COUNT] = {
	[MBM_MODE_FETCH_ARCHIVES] = SUBDIR_SERVICE_LOG_FILE,
	[MBM_MODE_MAKE_WHITE_LIST] = SUBDIR_SERVICE_LOG_RSSI,
	[MBM_MODE_SET_WHITE_LIST] = SUBDIR_SERVICE_LOG_SETLIST,
	[MBM_MODE_SYNC_TIME] = NULL,	/* no log - to stderr */
	[MBM_MODE_GET_ACTUAL_WHITE_LIST] = "", /* right in service/ */
};

static int init_root_dir(mbm_context_t *ctx)
{
	mbm_config_t *cfg = &ctx->cfg;

	/* normalize root dir path and check */
	if (!realpath(cfg->root_dir, ctx->root_dir)) {
		pr_err("incorrect root dir '%s' specified: %s\n",
			cfg->root_dir, strerror(errno));
		return -1;
	}

	ctx->root_dir_len = strlen(ctx->root_dir);
	if (ctx->root_dir_len + 1 > MBM_PATH_MAX) {
		pr_err("too long root dir '%s' specified: the app is built for paths < %d chars\n", 
			ctx->root_dir, MBM_PATH_MAX);
		return -1;
	}
	return 0;
}

static int check_state_dir(const char *state_dir)
{
	/* try to create a file in the dir */
	char path[MBM_PATH_MAX];
	FILE *fp;
	int r;

	mbm_make_path(state_dir, MBM_FILENAME_CHECK_DIR, path);

	remove(path);

	fp = fopen(path, "w");
	if (!fp) {
		r = errno;
		pr_err("state_dir '%s' check failed: %s\n", state_dir, strerror(errno));
		return r;
	}

	fclose(fp);

	r = remove(path);
	if (r) {
		pr_err("state_dir '%s' check failed: %s\n", state_dir, strerror(errno));
		return r;
	}

	return 0;
}

static int mbm_init_log_fs(mbm_context_t *ctx)
{
	int r;
	DIR *d;
	struct dirent *ep;
	struct dirent entry;
	int max_order;
	size_t len;

	if (!ctx->log_sub_dir) {
		/* log to stderr, ignore the log by redirecting  to /dev/null as need */
		return -1;
	}

	/* check result length to prevent logging in mbm_ensure_subdir */
	ctx->log_dir_len = ctx->root_dir_len + 1 + sizeof(SUBDIR_SERVICE) + 
						strlen(ctx->log_sub_dir); /* / + service/ + log (w/o terminating 0) */
	if (ctx->log_dir_len >= sizeof(ctx->log_dir)) {
		pr_err("log directory path too long: %u\n", ctx->log_dir_len);
		return -1;
	}

	strcpy(ctx->log_dir, ctx->root_dir);
	r = mbm_init_sub_dir(ctx->log_dir, SUBDIR_SERVICE, -1);
	if (!r) {
		r = mbm_init_sub_dir(ctx->log_dir, ctx->log_sub_dir, -1);
	}

	if (r < 0) {
		pr_err("failed to create log subdirs: %s\n", strerror(-r));
		return -1;
	}

	/* scan log dir for current date and determine max order number */
	max_order = 0;
	d = opendir(ctx->log_dir);
	if (!d) {
		pr_err("failed to open log directory '%s': %s\n", ctx->log_dir, strerror(errno));
		return -1;
	}

	while ((r = readdir_r(d, &entry, &ep)) == 0) {
		if (!ep) {
			break; /* end of stream */
		}
		/* lookup log files: YYYY-MM-DD-??hostname??-NN 
		 * for current day "YYYY-MM-DD-" get max number NN
		 */
		if (!strncmp(ep->d_name, ctx->start_dt_str, 11)) {
			int order;
			char *p = strrchr(ep->d_name, MBM_FNAME_SEP_CHAR);
			if (!p) {
				pr_err("wrong log file name '%s'\n", ep->d_name);
				continue;
			}
			p++;
			order = atoi(p);
			if (order > max_order) {
				max_order = order;
			}
		}
	}

	if (r) {
		pr_err("error while reading log dir '%s': %s\n", ctx->log_dir, strerror(r));
		closedir(d);
		return -1;
	}

	closedir(d);

	pr_debug("max_order=%d\n", max_order);
	max_order++;
	if (max_order > 99) {
		max_order = 99;	/* will stay at this number if overflows */
	}
	pr_debug("cur log order=%d\n", max_order);

	/* so we can build log file name now */
	len = ctx->log_dir_len + 1 + MBM_DATE_LEN + 1 + strlen(ctx->hostname) + 1 + 2;	/* log_dir/YYYY-MM-DD-hn-NN (w/o terminating 0) */
	if (len >= sizeof(ctx->log_dir)) {
		pr_err("log file name too long: %u\n", len);
		return -1;
	}

	ctx->log_dir[ctx->log_dir_len] = '/';
	ctx->log_file_name = &ctx->log_dir[ctx->log_dir_len + 1];

	memcpy(ctx->log_file_name, ctx->start_dt_str, MBM_DATE_LEN);
	len = MBM_DATE_LEN;
	ctx->log_file_name[len++] = MBM_FNAME_SEP_CHAR;
	len += sprintf(&ctx->log_file_name[len], "%s-%02d", ctx->hostname, max_order);	/* len = length of log file name */
	
	pr_debug("log_dir_len=%d, log_file_name_len=%d\n", 
				ctx->log_dir_len, len);
	return 0;
}

/*=========================================*/
/* Interface                                                                              */
/*=========================================*/

int mbm_init(int argc, char *argv[], mbm_context_t **ctxp)
{
	int r;
	mbm_config_t cfg;
	int hr = 0;
	mbm_context_t *ctx;

	time_t start_time = time(NULL);
	*ctxp = NULL;

	/* TODO: read_config (from /etc/mbm.cfg)
	 * - move? root_dir there: ?do not allow override root_dir from command line 
	 * can be worked around by wrapping shell script with root_dir specified,
	 * so user should specify running of the script in his crontab
	 */

	/* parse args */
	r = mbm_parse_args(argc, argv, &cfg, &hr);
	if (r || hr) {
		return r;
	}
	mbm_dump_config(&cfg);

	/* allocate context */
	*ctxp = calloc(1, sizeof(mbm_context_t));
	if (!*ctxp) {
		pr_err("not enough memory for context: %d bytes\n", sizeof(mbm_context_t));
		return ENOMEM;
	}

	ctx = *ctxp;

	/* set config */
	memcpy(&ctx->cfg, &cfg, sizeof(ctx->cfg));

	/* op-specific allocations */
	if (ctx->cfg.mode == MBM_MODE_MAKE_WHITE_LIST ||
			ctx->cfg.mode == MBM_MODE_SET_WHITE_LIST ||
			ctx->cfg.mode == MBM_MODE_GET_ACTUAL_WHITE_LIST) {
		ctx->wl_data = malloc(sizeof(mbm_wl_data_t));
		if (!ctx->wl_data) {
			pr_err("not enough memory for wl operation: %d bytes\n", sizeof(mbm_wl_data_t));
			free(*ctxp);
			*ctxp = NULL;
			return ENOMEM;
		}
	}

	/* set log subdir */
	ctx->log_sub_dir = app_mode_log_sub_dirs[ctx->cfg.mode];

	/* build and/or check root and state dirs, as required: 
	* skip it for sync-time mode 
	*/
	if (ctx->cfg.mode != MBM_MODE_SYNC_TIME) {
		r = init_root_dir(ctx);

		if (!r) {
			r = check_state_dir(ctx->cfg.state_dir);
		}

		if (r) {
			free(*ctxp);
			*ctxp = NULL;
			return r;
		}
	}

	/* prepare start date-time values */
	ctx->start_time = start_time;
	localtime_r(&start_time, &ctx->start_tm);
	mbm_isdst = ctx->start_tm.tm_isdst;
	strftime(ctx->start_dt_str, sizeof(ctx->start_dt_str), 
				MBM_DATETIME_FORMAT, &ctx->start_tm);
	ctx->start_dt_str[sizeof(ctx->start_dt_str) - 1] = 0;

	/* build hostname */
	if (gethostname(ctx->hostname, sizeof(ctx->hostname)) < 0) {
		pr_err("failed to determine hostname: %s\n", strerror(errno));
		strcpy(ctx->hostname, "localhost");
	}

	/* make up log dir and file name, create subdirs as need: skip it for sync-time mode */
	if (ctx->cfg.mode == MBM_MODE_SYNC_TIME) {
		ctx->log_file_name = ctx->log_dir;	/* point to 0 - empty string */
	} else {
		r = mbm_init_log_fs(ctx);
		/* if error use stderr for logging and continue */
		if (r) {
			ctx->log_dir[0] = 0;
			ctx->log_file_name = ctx->log_dir;	/* point to 0 - empty string */
			ctx->log_dir_len = 0;
		}
	}

	return 0;
}

void mbm_done(mbm_context_t **ctxp)
{
	if (!ctxp || !*ctxp) {
		return;
	}

	if ((*ctxp)->wl_data) {
		free((*ctxp)->wl_data);
		pr_debug("wl_data freed\n");
	}
	
	free(*ctxp);
	*ctxp = NULL;
	pr_debug("ctx freed\n");
}

