#ifndef _MBM_FS_H_
#define _MBM_FS_H_

#include <dirent.h>
#include <time.h>

/* Approx. record has size:
*  arc-file: XXXXXXXX-YYYY-MM-DD-HH-MM-XXXXXXXX &0 = 35
* log-file: YYYY-MM-DD-host-NN &0 = len(host) + 15 = max.63+15=78
* Reserve mem for 50 records in worst conditions
*/
#define MBM_SCAN_DIR_BUF_SIZE			(50 * 78)

/* names of arc-type subdirs */
typedef enum mbm_arc_type {
	MBM_ARC_TYPE_CUR = 0,
	MBM_ARC_TYPE_MON,

	MBM_ARC_TYPE_COUNT
} mbm_arc_type_t;

extern const char *mbm_arc_subdirs[MBM_ARC_TYPE_COUNT];

/* scan dir to buf */

typedef struct mbm_scan_dir_buf {
	char buf[MBM_SCAN_DIR_BUF_SIZE];

	size_t rec_count;			/* current number of filtered records */
	
	size_t rec_len;			/* current record len = string len +1 (zero termination). If rec_len=0 - records have variable length */
	size_t rec_max_count;	/* current max number of records if rec_len > 0, otherwise - is not used */
	struct {
		unsigned eos: 1;		/* scan dir end-of-stream */
	} flags;
} mbm_scan_dir_buf_t;

/* file filter types */

typedef struct mbm_file_filter_item {
	time_t dt_full;
	long add_key;	/* addition key for comparing items: e.g. file order, date containing year and month only.. */
} mbm_file_filter_item_t;

typedef struct mbm_file_filter_data {
//	struct tm *start_tm;
	
	mbm_file_filter_item_t tab[MBM_KEEP_ITEMS_MAX_COUNT];
	size_t max_count;
	size_t start_index;	/* start_index moves from end to the begining of the array */

	struct tm file_tm;
	time_t file_time;
} mbm_file_filter_data_t;

/** Build path dir/name in the path buffer.
* @param dir parent directory
* @param name name in the directory
* @param path result path buffer of size MBM_PATH_MAX. If path points to the same 
*                     buffer that the dir points to then path just appended with name.
*/
extern int mbm_make_path(const char *dir, const char *name, char *path);

/** Move file from oldpath to newpath
* Does not log anything, returns 0 on success or negative errno code on error
*/
extern int mbm_move_file(const char *oldpath, const char *newpath);

/** Create 1-level subdirectory name and ensure that the directory exists.
 * Create the subdirectory as need.
 * @param parent_dir - root directory assumed to exist, size >= MBM_PATH_MAX
 * @param sub_dir - sub-directory name to append to the parent
 * @root_dir_len - >=0 length of app root dir, used for printing relative to root paths into log
 *                      - <0 - do not log anything
 * @return 0 - success, <0 - error
 * @note Used when log is already started, so logs errors
 */
extern int mbm_init_sub_dir(char *parent_dir, const char *sub_dir, int root_dir_len);

/** Callback for _scan_dir procedure which allows to customize entries filtering.
* @param entry  current directory entry
* @param data  pointer to the callback's specific data (shared by filter and accept_entry callbacks)
* @return boolean: 0 - drop the entry, 1 - filter the entry for further processing
*/
typedef int (*mbm_filter_cb)(const struct dirent *entry, void *data);

/** Callback for _scan_dir procedure which allows to customize entries further processing after 
* theye are filterred.
* @param entry current directory entry
* @param data pointer to the callback's specific data (shared by filter and accept_entry callbacks)
* @return boolean: whether to continue directory reading or not: 0 - stop reading more, 1 - continue reading
*/
typedef int (*mbm_accept_entry_cb)(const struct dirent *entry, void *data);

/** Scan directory filtering entries to scan_buf. Uses limited space, so not all fitting entries 
 * can be retreived via one call.
 * @param dir - full path of the directory to scan
 * @param root_dir_len - root directory length for cutting it from logs
 * @param scan_buf - pre-allocated and pre-configured buffer for results of the scanning
 * @param limit - filter no more entries then specified by limit
 * @param filter - callback - returns 1 if given dir entry should be added to the internal buffer of filtered items, 0 - otherwise
 * @param data - filter-specific data 
 */
extern int mbm_scan_dir_to_buf(const char *dir, int root_dir_len,
									mbm_scan_dir_buf_t *scan_buf, int limit,
									mbm_filter_cb filter, void *data);

/** Scan directory dir, filter entries using custom filter callback (filter) with its data (data). 
* If entry is filtered (OK),  it is accepted by custom procedure(accept_entry) with the same data (data).
* If ptr flag_eos provided it is set to signalize whether scanning is ended because no more entries left
* @param dir path to the directory to scan
* @param root_dir_len  root directory length for cutting root part of the directory in user logs
* @param flag_eos 
* @param filter
* @param accept_entry
* @param data
*/
extern int mbm_scan_dir(const char *dir, int root_dir_len, int *flag_eos,
						mbm_filter_cb filter, mbm_accept_entry_cb accept_entry,
						void *data);

/** Parse and check datetime part of log filename. Optionally, return parsed value of datetime.
* @param filename log file's name to parse
* @param file_tm ptr to var to get parsed datetime (can be NULL if not wanted)
* @param file_time ptr to var to get parsed datetime (can be NULL if not wanted)
* @return 0 - success, -1 - wrong datetime part format
*/
extern int mbm_datetime_from_log_filename(const char* filename, struct tm *file_tm,
												time_t *file_time);

/** Parse and check datetime part of log filename. Verify arc ID string if provided.
* Optionally, return parsed value of datetime.
* @param filename log file's name to parse
* @param file_tm ptr to var to get parsed datetime (can be NULL if not wanted)
* @param file_time ptr to var to get parsed datetime (can be NULL if not wanted)
* @param check_arc_id_str if specified, verify whether current filename's arc_id part is equal to the value.
* @return 0 - success, -1 - wrong datetime part format
*/
extern int mbm_datetime_from_arc_filename(const char* filename, struct tm *file_tm,
									time_t *file_time, const char *check_arc_id_str);

/** Extract order number from a log file's name
*/
extern int mbm_order_from_log_filename(const char *fname);

/* file filter methods */
extern void mbm_file_filter_data_setup(mbm_file_filter_data_t *filter_data, 
										size_t max_count);

extern int mbm_comp_arc_filter_item_time_key(const void *item1, const void *item2);
extern int mbm_comp_arc_filter_item_time_full(const void *item1, const void *item2);

/** Make a new arc filter item from data fd->* prepared earlier and add the item to 
* the filter array fd->tab.
* Used by arc fetching and cleaning.
*/
extern int mbm_add_arc_filter_item(const char *fname, int arc_type,
									mbm_file_filter_data_t *fd);
#endif /* _MBM_FS_H_ */
