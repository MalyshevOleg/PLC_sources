//#include <time.h>
//extern char *strptime(const char *s, const char *format, struct tm *tm);

#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>

#include <modbus/modbus.h>
#include "danfoss.h"

/* args: /dev/ttySn speed 8 N 1 [mode [addr]]
* mode=
* 1 (default) - assign addresses with reset all but w/o reset specific addr (stop on first failure)
* 2 - reset all addrs
* 3 - reset specified addr only
* 4 - assign addresses with reset all, assigning, reset as need
*/

typedef struct context_t {
	const char *tty_dev;
	int speed;
	int data_bits;
	char parity;
	int stop_bits;
	
	int mode;
	int addr;
	
	modbus_t *mb;
} context_t;

static context_t ctx;

int parse_args(int argc, char *argv[])
{
	if (argc < 6) {
		printf("port settings args are required\n");
		printf("args: /dev/ttySn speed 8 N 1 [mode [addr]]\n");
		printf("modes:\n");
		printf(
		"* 1 (default) - assign addresses with reset all but\n"
		"                w/o reset specific addr (stop on first failure)\n"
		"* 2 - reset all addrs\n"
		"* 3 - reset specified addr only\n"
		"* 4 - assign addresses with reset all, assigning, reset as need\n");
		return -1;
	}
	ctx.tty_dev = argv[1];
	ctx.speed = atoi(argv[2]);
	ctx.data_bits = atoi(argv[3]);
	ctx.parity = argv[4][0];
	ctx.stop_bits = atoi(argv[5]);
	
	ctx.mode = 1;
	if (argc > 6) {
		ctx.mode = atoi(argv[6]);
	}
	if (ctx.mode == 3) {
		if (argc < 8) {
			printf("mode 3 requires addr arg\n");
			return -1;
		}
		ctx.addr = strtol(argv[7], NULL, 0);
	}
	
	printf("mode=%d\n", ctx.mode);
	printf("port: tty_dev=%s, speed=%d, data_bits=%d, parity=%c, stop_bits=%d\n",
		ctx.tty_dev, ctx.speed, ctx.data_bits, ctx.parity, ctx.stop_bits);
	if (ctx.mode == 3) {
		printf("reset addr=0x%02X\n", ctx.addr);
	}

	return 0;
}

int modbus_init()
{
	int r;
	
	ctx.mb = modbus_new_rtu(ctx.tty_dev, ctx.speed, ctx.parity, ctx.data_bits, ctx.stop_bits);
	if (!ctx.mb) {
		printf("modbus_new_rtu error: %s\n", modbus_strerror(errno));
		goto err_new;
	}
	
	r = modbus_rtu_get_serial_mode(ctx.mb);
	if (r == -1) {
		printf("failed to determine serial mode\n");
	} else {
		printf("serial mode is: %s\n", 
			r == MODBUS_RTU_RS232 ? "RS232" :
			r == MODBUS_RTU_RS485 ? "RS485" : "invalid");
	}
	
	r = modbus_connect(ctx.mb);
	if (r) {
		printf("modbus conenction failed: %s\n", modbus_strerror(errno));
		goto err_conn;
	}
	printf("modbus_connect OK\n");

	r = modbus_rtu_set_serial_mode(ctx.mb, MODBUS_RTU_RS485);
	if (r) {
		printf("failed to set modbus RS485 mode: %s\n", modbus_strerror(errno));
		goto err_setmode;
	}
	printf("set RS485 mode OK\n");

	modbus_set_debug(ctx.mb, 1);
	printf("modbus connection initialized OK\n");
	return 0;

err_setmode:
	modbus_close(ctx.mb);
err_conn:
	modbus_free(ctx.mb);
err_new:
	return -1;
}

static void modbus_done()
{
	modbus_close(ctx.mb);
	modbus_free(ctx.mb);
	printf("modbus done\n");
}

static int reset_all_addrs()
{
	int r;

	r = modbus_set_slave(ctx.mb, MBM_CONFIG_SLAVE_DEV);
	if (r < 0) {
		printf("%s: libmodbus error: %s\n", __func__, modbus_strerror(errno));
		return -1;
	}
	
	r = modbus_write_register(ctx.mb, MBM_RESET_ADDR_REG, MBM_RESET_ALL_ADDRS);
	printf("reset all addresses, rc(ignored)=%d: %s\n",
		r, r < 0 ? modbus_strerror(errno) : "OK");

	return 0;
}

static int reset_addr(int addr)
{
	int r;

	r = modbus_set_slave(ctx.mb, MBM_CONFIG_SLAVE_DEV);
	if (r < 0) {
		printf("%s: libmodbus error: %s\n", __func__, modbus_strerror(errno));
		return -1;
	}

	r = modbus_write_register(ctx.mb, MBM_RESET_ADDR_REG, addr);
	printf("reset addr %d: rc(ignored)=%d: %s\n",
		addr, r, r < 0 ? modbus_strerror(errno) : "OK");

	return 0;
}

int assign_addrs()
{
	int r;
	int addr;
	int attempts;
	
	r = reset_all_addrs(); /* sets slave addr to MBM_CONFIG_SLAVE_DEV */
	if (r < 0) {
		return -1;
	}
	
	addr = MBM_SLAVE_ADDR_MIN;
	do {
		usleep(500 * 1000); /* wait a bit to avoid errors w/o debug + by Semenov*/
		
		r = modbus_write_register(ctx.mb, MBM_SET_ADDR_REG, addr);
		if (r == 1) {
			printf("addr %d assigned\n", addr);
			attempts = 0;
			addr++;
			if (addr > MBM_SLAVE_ADDR_MAX) {
				printf("all valid addresses assigned, stop.\n");
				break;
			}
		} else { /* error */
			if (ctx.mode == 1) {
				printf("mode=1, failed to assign address %d, stop w/o reset and retry\n", addr);
				break;
			}
			
			/* mode=4, try attempts times with reset by algorithm */
			attempts++;
			printf("attempt=%d of assigning addr %d failed\n", attempts, addr);

			usleep(500 * 1000);
			printf("reseting addr %d\n", addr);
			r = reset_addr(addr);
			printf("reseting addr %d done\n", addr);
			
			if (attempts >= MBM_SET_SLAVE_ADDR_ATTEMPTS_MAX) {
				printf("all attempts to set addr %d run out, stop\n", addr);
				break;
			}
		}
	} while(1);
	
	return 0;
}

int main(int argc, char *argv[])
{
	int r;
	
	r = parse_args(argc, argv);
	if (r) {
		return r;
	}
	
	r = modbus_init();
	if (r) {
		return r;
	}

	switch (ctx.mode) {
	case 2:
		r = reset_all_addrs();
		break;
	case 3:
		r = reset_addr(ctx.addr);
		break;
	case 1:
	case 4:
		r = assign_addrs();
		break;
	default:
		printf("mode %d not supported\n", ctx.mode);
		break;
	}

	modbus_done();
	
	return r;
}

