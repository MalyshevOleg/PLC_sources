#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <time.h>

#include "mbm_context.h"

#include "mbm_strings.h"
#include "app_log.h"

#include "mbm_wl.h"
#include "mbm_network.h"
#include "mbm_archives.h"
#include "mbm_modbus_func.h"
#include "mbm_fs.h"

#include "mbm_task_fetch_arcs.h"

typedef struct fetch_arc_info {
	int count;						/* count of arcs fetched */
	int arc_type;						/* current arc type */
	char arc_path[MBM_PATH_MAX];	/* current arc_type dir with pk id subdir and eventually arc filename */
	size_t root_dir_len;
	size_t arc_dir_len;		/* keep length of arc-top directory */
	size_t arc_type_dir_len;	/* keep length of arc-type directory through slave iterations */

	/* pointers to data to pass deep in the chain of calls */
	mbm_wl_index_t *wl_stats;
//	struct tm *start_tm;
	mbm_scan_dir_buf_t *scan_buf;

	/*  changed through arc number iterations*/
	mbm_pk_wl_t *filter_wl;
	mbm_arc_header_t *arc_head;
} fetch_arc_info_t;

/** Save data of archive file.
 * @param file - path of the result file to store the data
 * @param data - pointer to the data buffer
 * @param len - length of the data to save
 * @return 0 - success, <0 - error (check errno)
 */
static int save_arc_file(const char *file, char *data, size_t len)
{
	/* files are very shot - use non buffered IO */
	int fd;
	int r, attempt = 0;
	size_t written = 0;
	ssize_t count;

	fd = open(file, O_CREAT | O_WRONLY, 
			S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP | S_IROTH);
	if (fd < 0) {
		return -errno;
	}

	r = 0;
	while (len > 0 && attempt < 5) {
		count = write(fd, &data[written], len);

		if (count < 0) {
			if (errno == EAGAIN) {
				attempt++;
				continue;
			}
			break;
		}

		len -= count;
		written += count;
	}

	if (count < 0) {
		r = -errno;
	}

	close(fd);
	sync();
	
	return r;
}

static int same_arc_filter(const struct dirent *entry, void *data)
{
	fetch_arc_info_t *info = (fetch_arc_info_t *)data;
	mbm_arc_header_t *arc_head = info->arc_head;
	time_t item_time;
	double time_shift;

	if (mbm_datetime_from_arc_filename(entry->d_name, NULL, &item_time,
										arc_head->arc_id_str) == 0) {
		/* compare time */
		time_shift = difftime(item_time, arc_head->time);
		if (time_shift < 0) {
			time_shift = -time_shift;
		}
		
		if (time_shift < (MBM_SAME_ARC_TIME_SHIFT_MIN * 60)) {
			log_debug("item: '%s' detected as the same (time_shift=%d sec) - filtered", 
				entry->d_name, time_shift);
			return 1;
		}
		log_debug("item: '%s' NOT detected as the same - ignored", entry->d_name);
	}
	return 0;
}

typedef struct old_arc_data {
	int counter;
	mbm_arc_header_t *arc_head;	/* contains arc info and arc time */
	mbm_file_filter_data_t filter_data;
} old_arc_data_t;

/* countdown archives in the directory which are newer than the candidate,
* If the counter reaches 0 filter the item signalizing that max number of better 
* items are already present in the directory, so the candidate should not be fetched
* Note: is not used for monthly arcs - they need unique file for a month (YYYY-MM)
*/
static int old_arc_filter(const struct dirent *entry, void *data)
{
	old_arc_data_t *old_data = (old_arc_data_t *)data;
	mbm_arc_header_t *arc_head = old_data->arc_head;
	time_t item_time;

	if (mbm_datetime_from_arc_filename(entry->d_name, NULL, &item_time,
										arc_head->arc_id_str) == 0) {
		if (item_time > arc_head->time) {
			old_data->counter--;	/* found better arc in the dir */

			if (!old_data->counter) {
				/* max number of 'better' files are found in the dir - filter the latest to signal
				* that candidate should not be fetched
				*/
				log_debug("max number of 'better' arcs are found in the directory for arc time=%s", 
						arc_head->time_str);
				return 1;
			}

			/* max number is not exceeded, so continue counting */
			log_debug("max number of 'better' arcs is not found in the directory for arc time=%s", 
					arc_head->time_str);
		}
	}
	return 0;
	
}

/* return:  bool - 0 - not found, 1 - found */
static int is_same_arc_fetched_already(fetch_arc_info_t *info)
{
	int r;
	char path[MBM_PATH_MAX];
	char *sub_dir;
	int arc_type;

	mbm_scan_dir_buf_t *scan_buf = info->scan_buf;
	mbm_arc_header_t *arc_head = info->arc_head;

	log_debug("examine arc: is the same arc fetched already: arc_id=%s, arc time(filter time)=%s", 
				arc_head->arc_id_str, arc_head->time_str);

	/* scan current dir to find at least an arc file with the same ID which time is up to 15 minutes 
	* differs from the current archive's time 
	 */

	/* prepare archives directory path */
	memcpy(path, info->arc_path, info->arc_dir_len + 1);	/* including '/' */
	sub_dir = &path[info->arc_dir_len + 1];				/* now sub_dir points to variable part of path after xxx/archive/ */

	/* for each arc-type: */
	for (arc_type = 0; arc_type < MBM_ARC_TYPE_COUNT; arc_type++) {
		size_t len;
		struct stat sb;

		/* ... - build next arc directory to scan ...  */
		len = strlen(mbm_arc_subdirs[arc_type]);
		memcpy(sub_dir, mbm_arc_subdirs[arc_type], len);
		sub_dir[len] = '/';
		strcpy(&sub_dir[len + 1], arc_head->arc_id_str);

		/* ... - check if directory exists: ... */
		r = stat(path, &sb);
		if (!r && S_ISDIR(sb.st_mode)) {
			/* ... -- exists - scan for same arc */
			r = mbm_scan_dir_to_buf(path, info->root_dir_len, scan_buf, 1, 
									same_arc_filter, info);
			if (!r && scan_buf->rec_count) {
				log_debug("same arc id=%s found in %s dir, don't fetch it", 
							arc_head->arc_id_str, sub_dir);
				return 1;
			} else {
				log_debug("same arc id=%s not found (dir %s scanned)", 
							arc_head->arc_id_str, sub_dir);
			}
		} else {
			/*
			* ... -- do not exist, not a dir - no same arcs or
			* ... --- scan failed to find a same arc
			*/
			log_debug("same arc id=%s not found (%s - not a dir)", 
						arc_head->arc_id_str, sub_dir);
		}
	}

	return 0;
}

static int arc_file_filter(const struct dirent *entry, void *data)
{
	int r;
	old_arc_data_t *od = (old_arc_data_t *)data;
	mbm_file_filter_data_t *fd = &od->filter_data;

	/* parse & check filename, save entry's time for adding */
	r = mbm_datetime_from_arc_filename(entry->d_name, &fd->file_tm, &fd->file_time,
										od->arc_head->arc_id_str);
	return !r;
}

/* Asume it is called only on filterred log item, so some checks were passed OK 
* Used only for monthly arcs
*/
static int arc_entry_add(const struct dirent *entry, void *data)
{
	old_arc_data_t *od = (old_arc_data_t *)data;
	mbm_add_arc_filter_item(entry->d_name, MBM_ARC_TYPE_MON, &od->filter_data);
	return 1; /* process all entries */
}

/* return:  bool: 1 - old and odd, 0 - otherwise */
static int is_arc_old(fetch_arc_info_t *info)
{
	int r;
	old_arc_data_t old_data;
	mbm_scan_dir_buf_t *scan_buf = info->scan_buf;
	mbm_arc_header_t *arc_head = info->arc_head;

	log_debug("is the arc too old: arc_id=%s, arc time=%s",
			arc_head->arc_id_str, arc_head->time_str);

	old_data.arc_head = arc_head;

	if (info->arc_type == MBM_ARC_TYPE_MON) {
		/* scan dir filling the set of max allowed unique month arcs */
//		old_data.filter_data.start_tm = info->start_tm;
		mbm_file_filter_data_setup(&old_data.filter_data, MBM_KEEP_ARC_MON);
		r = mbm_scan_dir(info->arc_path, info->root_dir_len, NULL, 
							arc_file_filter, arc_entry_add, &old_data);
		if (!r) {
			/* try adding the current arc into the set - if arc is rejected - it is old - don't fetch it */
			old_data.filter_data.file_time = arc_head->time;
			old_data.filter_data.file_tm = arc_head->tm;
			r = mbm_add_arc_filter_item(arc_head->time_str, MBM_ARC_TYPE_MON, &old_data.filter_data);
			if (!r/* rejected */) {
				return 1;
			}
		}
	} else {
		/* assume current archives */
		old_data.counter = MBM_KEEP_ARC_CUR;

		/* scan arc target dir: calc count of arcs in it, calc min time of the arcs */
		r = mbm_scan_dir_to_buf(info->arc_path, info->root_dir_len, scan_buf, 1,
								old_arc_filter, &old_data);
		if (!r && scan_buf->rec_count) {
			/* there are enough better archives present in the dir - candidate is old and odd */
			log_debug("dir %s scanned: arc id=%s, arc time=%s is old, don't fetch it", 
								info->arc_path, arc_head->arc_id_str, arc_head->time_str);
			return 1;
		}
	}

	/* either we haven't managed to determine or candidate is NOT old */
	log_debug("dir %s scanned (r=%d): arc id=%s, arc time=%s is NOT old, fetch it", 
							info->arc_path, r, arc_head->arc_id_str, arc_head->time_str);
	return 0;
}

/* Assume: work_path is set to /root/arcs/arc-type", work_path_len is set properly too
 * return: < 0 - channel free, >=0 - count of fetched archives: 1 or 0
 * channel & mon_shift are used for logging only, mon_shift < 0 means that it should not be logged
 */
static int fetch_slave_channel_archive(mbm_network_t *mb_net, mbm_slave_dev_t *slave,
										mbm_arc_descriptor_t *arc, fetch_arc_info_t *info)
{
	int r;
	mbm_arc_header_t arc_head;
	mbm_modbus_file_t arc_file;
	size_t path_len;

	r = mbm_read_slave_arc_header(mb_net->mb, slave, arc, &arc_head);
	if (r) {
		return 0;	/* error - no file fetched */
	}

	if (arc_head.telegram_size == 0xFF) {
		return -1;	/* channel free */
	}

	/* ensure arc's size > 0 for further use */
	if (!(arc_head.telegram_size > 0)) {
		return 0;
	}

	if (info->filter_wl && 
		!mbm_is_arc_id_in_pk_wl(info->filter_wl, arc_head.arc_id)) {
		log_debug("slave %s (addr %d): arc_id=%s (0x%08X) skipped - not in WL",
					slave->dev_sn_str, slave->addr, arc_head.arc_id_str, arc_head.arc_id);
		return 0;
	}

	info->arc_head = &arc_head;
	
	/* check whether or not the same archive (+-15min) fetched already (before creating of arc's directory) 
	* so if the directory is absent we can skip its scanning, 
	* moreover if the arc is found somewhere else we won't need to create the directory at all
	*/
	r = is_same_arc_fetched_already(info);
	if (r) {
		return 0;	/* no file fetched */
	}

	/* make id directory path and create the directory as need (target directory for archive)
	* Note: the built path is used in the following checking call is_arc_old()
	*/
	r = mbm_init_sub_dir(info->arc_path, arc_head.arc_id_str, info->root_dir_len);
	if (r) {
		return 0;	/* no file fetched */
	}
	/* so arc_path is set to "/root/arcs/arc-type/arc-id" directory, update path's len: 1 - slash, 8 - arc-id*/
	path_len = info->arc_type_dir_len + 1 + 8;

	/* Check whether target directory contains max allowed number of newer archives. */
	r = is_arc_old(info);
	if (r) {
		return 0;	/* no file fetched */
	}
	
	/* fetch and store current arc, if same arc not found, arc is not odd and data size > 0 */
	
	arc_file.addr = (uint8_t)(slave->addr);
	arc_file.file_no = (uint16_t)arc->file_no;
	arc_file.rec_no = 0;
	/* confirmed by OWEN: TelegramSize in bytes, so convert them into regs, 
	* then, when saving file, convert back 
	*/
	arc_file.regs_count = arc_head.telegram_size / 2 + (arc_head.telegram_size & 1);

	r = mbm_modbus_read_file(mb_net->mb, &arc_file);
	if (r < 0) {
		log_err(mbm_str_err_fetch_arc, slave->dev_sn_str, slave->addr, 
				arc->channel, arc->mon_shift, modbus_strerror(errno));
		/* try removing created directory */
		r = rmdir(info->arc_path);
#if DEBUG
		if (r) {
			log_debug("failed to remove dir: %s", info->arc_path);
		} else {
			log_debug("removed successfully dir: %s", info->arc_path);
		}
#endif
		return 0;	/* no file fetched */
	}

	/* prepare arc_path: "/root/arcs/arc-type/arc-id/arc-file-name" 
	* note: path length is checked in init_arc_fs() (and init_root_dir)
	*/
	info->arc_path[path_len] = '/';
	sprintf(&info->arc_path[path_len + 1], "%s-%s-%s",
			arc_head.arc_id_str, arc_head.time_str, slave->dev_sn_str);

	log_debug("file name for arc %s built: %s", arc_head.arc_id_str, info->arc_path);

	/* correct file length as need, see arc_file.regs_count comments above */
	if (arc_head.telegram_size & 1) {
		/* we've read 1 byte more then actual file length */
		arc_file.data_len -= 1;
		log_debug("arc file length corrected by 1 byte: %u", arc_file.data_len);
	} else {
		log_debug("arc file length NOT corrected: %u", arc_file.data_len);
	}

	r = save_arc_file(info->arc_path, (char *)arc_file.data, arc_file.data_len);
	if (r) {
		log_err(mbm_str_err_save_arc, slave->dev_sn_str, slave->addr, 
				arc->channel, arc->mon_shift, strerror(-r));
		return 0;
	}

	log_einfo(mbm_str_arc_fetched, slave->dev_sn_str, 
			arc->channel, arc->mon_shift, &info->arc_path[info->root_dir_len]);
	
	return 1;	/* OK */
}

/*
 * returns count of fetched archives: >= 0 
 */
static int forslave_fetch_archives(mbm_network_t *mb_net, mbm_slave_dev_t *slave, 
								void *data)
{
	int r;
	int channel;	/* the same as sensor order number */
	fetch_arc_info_t *info = (fetch_arc_info_t *)data;
	mbm_arc_descriptor_t arc;
	mbm_pk_wl_t wl;

	info->filter_wl = NULL;

	log_debug("fetch arcs of type %d from dev %s (addr=%d) - started",
				info->arc_type, slave->dev_sn_str, slave->addr);

	log_debug_buf("channel_mask", slave->channel_mask,
					sizeof(slave->channel_mask) / sizeof(slave->channel_mask[0]), 'b');


	/* if wl is used (stats present):
	* 1) check if current slave has count of counters > 0
	* 2) load slave's actual wl, sort (0 val is the greatest, so all 0s will be in the end of the list)
	* 3) check if the wl is not empty
	* - if no wl used - read all possible arcs of the slave w/o filtering
	* - wl used and slave has 0 stats, skip the slave
	* - wl used and slave's wl empty ([0]=0), skip the slave
	* - wl used and slaves wl not empty, read arcs filtering by the wl
	*/

	if (info->wl_stats->count) {
		mbm_wl_index_rec_t *stats_rec;
		stats_rec = mbm_get_wl_stats_record_for_pk(info->wl_stats, slave->dev_sn);
		if (!stats_rec || !stats_rec->count) {
			/* wl is used but for current slave no wl stats or stats is 0 - do not fetch arcs for the slave - skip it */
			log_warn(mbm_str_fetch_arcs_wl_stats_empty, slave->dev_sn_str, slave->addr);
			return 1; /* continue with next slave */
		}

		/* load slave's wl (sorted) */
		r = mbm_read_white_list(mb_net, &wl);
		if (r) {
			log_err(mbm_str_err_wl_read, slave->dev_sn_str, slave->addr, 
					modbus_strerror(errno));
			return 1; /* continue with next slave */
		}

		if (!wl.count) {
			log_warn(mbm_str_fetch_arcs_wl_empty, slave->dev_sn_str, slave->addr);
			return 1; /* continue with next slave */
		}

		/* use the wl as filter */
		info->filter_wl = &wl;
		log_debug_buf("WL", wl.arc_id, wl.count * sizeof(wl.arc_id[0]), 'd');
	}

	switch (info->arc_type) {
	case MBM_ARC_TYPE_CUR:
		for (channel = 0; channel < MBM_ARC_CHANNEL_COUNT; channel++) {
			mbm_make_arc_descriptor(channel, -1, &arc);

			log_debug("fetch arc of type 'CUR' from dev %s (addr=%d): "
				"channel=%d, header_reg=0x%04X, file_no=%d",
						slave->dev_sn_str, slave->addr, 
						arc.channel, arc.header_reg, arc.file_no);

			r = fetch_slave_channel_archive(mb_net, slave, &arc, info);

			/* restore arc-type directory (the function above may change it) */
			info->arc_path[info->arc_type_dir_len] = 0;

			if (r >= 0) {
				/* channel not free - mark it in mask */
				slave->channel_mask[CHANNEL_INDEX(channel)] |= (1 << CHANNEL_BIT(channel));
				log_debug("updated channel_mask[%d]=0x%02X (add_val: 0x%02X", 
							CHANNEL_INDEX(channel),
							slave->channel_mask[CHANNEL_INDEX(channel)],
							(1 << CHANNEL_BIT(channel)));
				/* increase counter of archives */
				info->count += r;
			}
		}
		break;

	case MBM_ARC_TYPE_MON:
		for (channel = 0; channel < MBM_ARC_CHANNEL_COUNT; channel++) {
			int mon_shift;
			/* check if channel is used - fetch only used channels */
/* TODO: testing revealed that current archive may not be present while monthly 
* history available for a channel
* Is it a bug of PK ?
* Anyway, do not use this optimization.
*/
#if 0
			if (!(slave->channel_mask[CHANNEL_INDEX(channel)] & (1 << CHANNEL_BIT(channel)))) {
				/* skip channel - not used by mask */
				log_debug("fetch arc of type 'MON' from dev %s (addr=%d): "
							"channel=%d: skipped - not set by mask",
							slave->dev_sn_str, slave->addr, channel);
				continue;
			}
			/* otherwise fetch channel's month history */
#endif

			for (mon_shift = 0; mon_shift < MBM_ARC_MON_COUNT; mon_shift++) {
				mbm_make_arc_descriptor(channel, mon_shift, &arc);

				log_debug("fetch arc of type 'MON' from dev %s (addr=%d): "
					"channel=%d, header_reg=0x%04X, file_no=%d",
							slave->dev_sn_str, slave->addr, 
							arc.channel, arc.header_reg, arc.file_no);

				r = fetch_slave_channel_archive(mb_net, slave, &arc, info);

				/* restore arc-type directory (the function above may change it) */
				info->arc_path[info->arc_type_dir_len] = 0;

				if (r >= 0) {
					info->count += r;
				} else {
					/* no more deep in history monthly info - stop channel processing */
					log_debug("fetch arc of type 'MON' from dev %s (addr=%d): "
								"channel=%d: no more monthly history information - stop with the channel",
								slave->dev_sn_str, slave->addr, channel);
					break;
				}
			}
		}
		break;
	}

	log_debug("fetch arcs of type %d from dev %s (addr=%d) - done",
				info->arc_type, slave->dev_sn_str, slave->addr);

	return 1;	
}


/*==========================================*/
/*                    Interface                                                   */
/*==========================================*/

int mbm_init_arc_fs(mbm_context_t *ctx)
{
	int r;
	int i;
	size_t arc_dir_len;
	char path[MBM_PATH_MAX];

	strcpy(path, ctx->root_dir);	/* see init_root_dir - it ensures that root_dir is less than MBM_PATH_MAX chars */

	/* create archive dir */
	log_debug("initializing archive dir: %s/%s", path, SUBDIR_ARCHIVE);
	r = mbm_init_sub_dir(path, SUBDIR_ARCHIVE, ctx->root_dir_len);
	if (r) {
		return r;
	}
	arc_dir_len = strlen(path);
	
	/* create archive/subdirs[i] */
	for (i = 0; i < MBM_ARC_TYPE_COUNT; i++) {
		size_t arc_file_max_len;
		/* init work path for next cycle */
		path[arc_dir_len] = 0;
		log_debug("initializing archive subdir: %s/%s", path, mbm_arc_subdirs[i]);
		r = mbm_init_sub_dir(path, mbm_arc_subdirs[i], ctx->root_dir_len);
		if (r) {
			break;
		}

		/* calc max possible arc file path length */
		arc_file_max_len = strlen(path) + 1 + 						/* ..cur|mon/ */
						8 + 1 + 								/* ID/ */
						8 + 1 + sizeof(MBM_DATETIME_LEN) + 8;   /* ID-DATETIME-ID */
		log_debug("possible arc file path length: %d", arc_file_max_len);
		if (arc_file_max_len >= sizeof(path)) {
			log_err(mbm_str_err_arc_path_too_long, arc_file_max_len);
			return -1;
		}
	}
	
	return r;
}

void mbm_fetch_archives(mbm_context_t *ctx)
{
	int r;
	mbm_wl_index_t wl_stats;
	fetch_arc_info_t info;
	char path[MBM_PATH_MAX];

	log_info(mbm_str_fetch_archives_started);

	memset(&info, 0, sizeof(info));	/* channel mask is reset to 0 as well */

	/* load wl stats */
	mbm_make_path(ctx->cfg.state_dir, MBM_FILENAME_WL_STATS, path);
	
	r = mbm_load_white_list_stats(path, -1, &wl_stats);
	if (r) {
		//TODO: is it acceptable to ignore errors? fetching may produce non-consistent result..
		return;
	}

	info.wl_stats = &wl_stats;

	/* prepare root directory for archives */
	strcpy(info.arc_path, ctx->root_dir);
	info.arc_path[ctx->root_dir_len] = '/';
	strcpy(&info.arc_path[ctx->root_dir_len + 1], SUBDIR_ARCHIVE);
	info.arc_dir_len = strlen(info.arc_path); /* len is OK - checked in init_arc_fs*/

	log_debug("fetch archives: work path is set to arc root: '%s'", info.arc_path);

	info.root_dir_len = ctx->root_dir_len;
	
//	info.start_tm = &ctx->start_tm;
	/* setup scan buf */
	info.scan_buf = &ctx->scan_buf;
	info.scan_buf->rec_len = MBM_ARC_FILENAME_LEN + 1;	/* fixed rec len for arcs, incl. term 0 */
	info.scan_buf->rec_max_count = sizeof(info.scan_buf->buf) / info.scan_buf->rec_len;

	log_debug("scan buffer initialized: rec_len=%d, rec_max_count=%d", 
				(int)info.scan_buf->rec_len, (int)info.scan_buf->rec_max_count);

	/* NOTE: optimization of fetching arcs assumes that 1st fetched current archives, then monthly */
	for (info.arc_type = 0; info.arc_type < MBM_ARC_TYPE_COUNT; info.arc_type++) {
		/* set arc-type work path */
		info.arc_path[info.arc_dir_len] = '/';
		strcpy(&info.arc_path[info.arc_dir_len + 1], mbm_arc_subdirs[info.arc_type]);
		info.arc_type_dir_len = info.arc_dir_len + 1 + strlen(mbm_arc_subdirs[info.arc_type]);	/* len is OK - checked in init_arc_fs*/

		log_debug("fetch archives: arc type dir is set: '%s'", info.arc_path);
		mbm_foreach_active_slave(&ctx->mb_net, &forslave_fetch_archives, 
									mbm_str_err_fetch_arcs, &info);
	}
	
	log_info(mbm_str_fetch_archives_done, info.count);
}

