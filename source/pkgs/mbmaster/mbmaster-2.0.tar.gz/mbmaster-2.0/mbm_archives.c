#include <errno.h>
#include <stdio.h>
#include <string.h>

#include "danfoss.h"
#include "mbm_defs.h"

#include "mbm_strings.h"
#include "app_log.h"
#include "mbm_utils.h"

#include "mbm_archives.h"

/* read & parse arc header */
int mbm_read_slave_arc_header(modbus_t *mb, mbm_slave_dev_t *slave,
							mbm_arc_descriptor_t *arc, mbm_arc_header_t *arc_head)
{
	int r;
	int attempts = MBM_MODBUS_RETRY;

	arc_head->telegram_size = 0; /* telegram_size = 0xff - 'means no archive' */

	while(1) {
		r = modbus_read_registers(mb, arc->header_reg, 
								MBM_ARC_HEADER_REG_COUNT, arc_head->raw);
		if (r < 0) {
			attempts--;
			if (attempts <= 0) {
				log_err(mbm_str_err_fetch_arc_header, slave->dev_sn_str, slave->addr, 
							arc->channel, arc->mon_shift, modbus_strerror(errno));
				return -1;
			}
			log_debug("read arc header error: %s (%d) - retry", modbus_strerror(errno), errno);
			continue;
		}
		break; /* OK */
	}

	/* parse header */
	arc_head->telegram_size = arc_head->raw[MBM_ARC_IDX_SIZE];
	if (arc_head->telegram_size == 0xff) {
		log_debug("do not parse header more: size=0xFF");
		return 0; /* OK, but 0xFF - no arc data, channel is not used, TODO: check size for matching to correct ADU? */
	}

	/*
	* MODBUS_GET_INT32_FROM_INT16: low register becomes high word in the result dword
	*/
	arc_head->arc_id = MODBUS_GET_INT32_FROM_INT16(arc_head->raw, MBM_ARC_IDX_ID);
	arcid_to_str(arc_head->arc_id, arc_head->arc_id_str);

	log_debug("arc header: dev %s (addr=%d), channel=%d, mon=%d: "
		"arc_id=%s, %04u-%02u-%02u %02u:%02u:%02u, size=%u BYTES",
		slave->dev_sn_str, slave->addr, arc->channel, arc->mon_shift,
		arc_head->arc_id_str, 
		arc_head->raw[MBM_ARC_IDX_TIME + 5], arc_head->raw[MBM_ARC_IDX_TIME + 4], 
		arc_head->raw[MBM_ARC_IDX_TIME + 3],
		arc_head->raw[MBM_ARC_IDX_TIME + 2], arc_head->raw[MBM_ARC_IDX_TIME + 1],
		arc_head->raw[MBM_ARC_IDX_TIME],
		arc_head->raw[MBM_ARC_IDX_SIZE]);

	/* Arc's time format is:
	 * sec 0..59
	 * min 0..59
	 * hour 0..23
	 * mday 1..31
	 * mon 1.12
	 * year 2010..2100 
	 */
	memset(&arc_head->tm, 0, sizeof(arc_head->tm));
	
	arc_head->tm.tm_isdst = mbm_isdst;
	
	arc_head->tm.tm_sec = arc_head->raw[MBM_ARC_IDX_TIME];
	arc_head->tm.tm_min = arc_head->raw[MBM_ARC_IDX_TIME + 1];
	arc_head->tm.tm_hour = arc_head->raw[MBM_ARC_IDX_TIME + 2];
	arc_head->tm.tm_mday = arc_head->raw[MBM_ARC_IDX_TIME + 3];
	arc_head->tm.tm_mon = arc_head->raw[MBM_ARC_IDX_TIME + 4] - 1;		/* tm_mon - 0..11 */
	arc_head->tm.tm_year = arc_head->raw[MBM_ARC_IDX_TIME + 5] - 1900;	/* tm_year - the number of years since 1900 */

	strftime(arc_head->time_str, sizeof(arc_head->time_str), 
			MBM_DATETIME_FORMAT, &arc_head->tm);
	arc_head->time = mktime(&arc_head->tm);

	return 0;
}	

/*
* channel 0 .. MBM_ARC_CHANNEL_COUNT-1
* mon_shift - -1, 0 .. MBM_ARC_MON_COUNT -1: -1 - current archive, >= 0 - monthly
* return 0 - OK, < 0 - err (inval channel or mon_shift)
*/
int mbm_make_arc_descriptor(int channel, int mon_shift, mbm_arc_descriptor_t *arc)
{
	if (channel < 0 || channel >= MBM_ARC_CHANNEL_COUNT ||
		mon_shift < -1 || mon_shift >= MBM_ARC_MON_COUNT) {
		return -EINVAL;
	}

	if (mon_shift == -1) {
		arc->file_no = MBM_ARC_FILE_NO_BASE_CUR + channel;
		arc->header_reg = MBM_ARC_HEADER_BASE_CUR + 
						(MBM_ARC_HEADER_REG_COUNT) * channel;
	} else {
		arc->file_no = MBM_ARC_FILE_NO_BASE_MON + 
					(MBM_ARC_MON_COUNT) * channel + 
					mon_shift;
		arc->header_reg = MBM_ARC_HEADER_BASE_MON + 
						(MBM_ARC_HEADER_REG_COUNT) * (
							(MBM_ARC_MON_COUNT) * channel + 
							mon_shift
						);
	}
	arc->channel = channel;
	arc->mon_shift = mon_shift;

	return 0;
}

/* Deletes archive with ID arc_id using writing the ID to addr 0x0012
* Return 0 on success, -1 on error
*/
int mbm_delete_slave_arc(modbus_t *mb, mbm_slave_dev_t *slave, uint32_t arc_id)
{
	int r;
	int attempts = MBM_MODBUS_RETRY;
	uint16_t id_data[2];	/* ArcID - two registers */

	id_data[0] = (uint16_t)(arc_id >> 16);	/* high part in low reg, like in arc header - see above */
	id_data[1] = (uint16_t)(arc_id & 0xffff); /* low part in the next reg */

	while(1) {
		r = modbus_write_registers(mb, MBM_ARC_DELETE_REG, 2, (uint16_t *)id_data);
		if (r < 0) {
			attempts--;
			if (attempts <= 0) {
				char id_str[9];
				log_err(mbm_str_err_del_arc, arcid_to_str(arc_id, id_str), 
						slave->dev_sn_str, slave->addr, modbus_strerror(errno));
				return -1;
			}
			log_debug("write arc_id for deleteing archive error: %s (%d) - retry",
						modbus_strerror(errno), errno);
			continue;
		}
		break; /* OK */
	}
	return 0;
}

