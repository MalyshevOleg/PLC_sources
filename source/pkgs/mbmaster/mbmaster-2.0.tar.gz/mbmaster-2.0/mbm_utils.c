#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "app_log.h"

#include "mbm_utils.h"

/* str size is >= 9: 8 decimal digits + terminating 0 
* NOTE: id in normal encoding LE, so in the memory low byte is first
* but string should be with first high byte
*/
const char *devsn_to_str(uint32_t id, char *str)
{
	snprintf(str, 2 + 1, "%02d", (id >> 24));			/* 2 chars + 1 for terminating zero */
	snprintf(str + 2, 6 + 1, "%06d", (id & 0xffffff));	/* 6 chars + 1 for terminating zero */
	return str;
}

uint32_t str_to_devsn(const char *str)
{
	int n;
	uint32_t hi, lo;
	n = sscanf(str, "%02d%06d", &hi, &lo);
	if (n == 2) {
		return (hi << 24) | (lo & 0xffffff);
	}
//	log_err("%s: failed for %s", __func__, str);
	return 0xffffffff;
}

#if OLD_ARC_ID_CONVERSION
const char *arcid_to_str(uint32_t id, char *str)
{
	uint8_t b;
	int i;

	for (i = 0; i < 4; i++) {
		b = ((uint8_t *)&id)[i];
		sprintf(&str[i * 2], "%02X", b);
	}
	return str;
}

uint32_t str_to_arcid(const char *str)
{
	int n;
	uint32_t id = 0, b[4];
	n = sscanf(str, "%02X%02X%02X%02X", &b[0], &b[1], &b[2], &b[3]);
	if (n == 4) {
		while (1) {
			n--;
			id |= (b[n] & 0xff);
			if (!n) {
				break;
			}
			id <<= 8;
		}
		return id;
	}
//	log_err("%s: failed for %s", __func__, str);
	return 0xffffffff;
}
#else

const char *arcid_to_str(uint32_t id, char *str)
{
	sprintf(str, "%08X", id);
	return str;
}

uint32_t str_to_arcid(const char *str)
{
	int n;
	uint32_t id = 0;
	
	n = sscanf(str, "%08X", &id);
	if (n == 1) {
		return id;
	}
//	log_err("%s: failed for %s", __func__, str);
	return 0xffffffff;
}
#endif

void *bsearch_index(const void *key, const void *base, size_t nmemb, size_t size, 
					int (*compar)(const void *, const void *), size_t *index)
{
	size_t li, ri;	/* li - first index to verify, ri - max index to verify + 1 */
	size_t mi;	/* mi - middle index - actual value to compare to */
	int r;
	char *p;
	
	li = 0;
	ri = nmemb;

	while (li < ri) {
		mi = (li + ri ) / 2;
		p = (char *)base + size * mi;

		r = compar(key, p);
		if (!r) {
			if (index) {
				*index = mi;
			}
			return p;
		}

		if (r > 0) {
			li = mi + 1;
		} else {
			ri = mi;
		}
	}

	if (index) {
		*index = li;
	}
	return NULL;
}

extern size_t unique_sorted_array(const void *base, size_t nmemb, size_t size,
									int (*compar)(const void *, const void *))
{
	size_t count;
	char *cur, *next, *gap, *end;
	
	if (nmemb < 2) {
		return nmemb;
	}

	count = nmemb;

	cur = (char *)base;
	next = cur + size;
	gap = NULL;
	end = cur + nmemb * size;

	while (next < end) {
		if (!compar(cur, next)) {
			count--;
			if (!gap) {
				gap = next;
			}
			next += size;
		} else {
			if (gap) {
				memcpy(gap, next, size);
				gap += size;
			}
			cur += size;
			next += size;
		}
	}
	
	return count;
}

/* return codes: 0 - rejected, 1 -replaced, 2 - added(inserted) */
int insert_unique_from_end(const void *item, const void *base,
							size_t max_count, size_t *start_index, size_t size, 
							int (*compar)(const void *, const void *),
							int (*compar_replace)(const void *, const void *))
{
	void *found = NULL;

	size_t sub_count;
	char *sub_base;
	size_t sub_index;

	char *ins_pos;
	size_t ins_index;

	char *shift_dest;
	size_t shift_count;

	sub_count = max_count - (*start_index);
	sub_base = (char *)base + (*start_index) * size;
	sub_index = 0;

	if (sub_count) {
		found = bsearch_index(item, sub_base, sub_count, size, compar, &sub_index);
	}

	if (found) {
		if (compar_replace(found, item) < 0) {
			memcpy(found, item, size);
			return 1;
		}
		/* else rejected */
		return 0;
	} 

	if (!sub_index && !*start_index) {
		/* rejected: should be inserted to the leftmost position, but there is no room */
		return 0;
	}

	/* ins_* - points to new element place. So all elements from this place and to the left
	* should be shifted to the left.
	* sub_index - is count of elements which are have to be shifted
	*/
	ins_index = *start_index + sub_index - 1; /* can't be less then 0 due to condition above */
	ins_pos = (char*)base + ins_index * size;

	if (!sub_index) {
		memcpy(ins_pos, item, size);
		(*start_index)--;
		/* item added(appended to the left and array extended to the left: start_index updated) */
		return 2;
	}

	/* ..else we have to shift sub_index elements.
	* But if there is no room (i.e. !*start_index) we have to shift one item less 
	* Determine destination and count
	*/
	if (!*start_index) {
		shift_dest = (char*)base;
		shift_count = sub_index - 1;
	} else {
		(*start_index)--;
		shift_dest = (char *)base + (*start_index) * size;
		shift_count = sub_index;
	}

	if (shift_count) {
		memmove(shift_dest, shift_dest + size, shift_count * size);
	}
	memcpy(ins_pos, item, size);
	/* item added(inserted and either array extended or data shited and the leftmost item pushed away) */
	return 2;
}

int uint32cmp(const void *n1, const void *n2)
{
	return COMPARE_NUM(*((uint32_t *)n1), *((uint32_t *)n2));
}
