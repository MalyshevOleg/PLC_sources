#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <stdlib.h>

#include "danfoss.h"
#include "mbm_defs.h"
#include "mbm_strings.h"
#include "app_log.h"

#include "mbm_args.h"

/* default config */
static mbm_config_t def_cfg = {
	.root_dir = "/home",
	.state_dir = MBM_DIR_STATE,

	.port = {
		.tty_dev = "/dev/ttyS1",
		.baud_rate = 115200,
		.parity = 'N',
		.data_bits = 8,
		.stop_bits = 1,
	},

	.delay_min = MBM_WHITE_LIST_WAIT_MINUTES,
};

static void mbm_usage(void)
{
	printf(
		APP_NAME " (" APP_VERSION "): perform modbus master's tasks\n"
		"Usage:\n"
		"   " APP_NAME " options\n"
		"\nOptions:\n"
		"  -m mode        what should be done (default: %d):\n"
		"                   0 - fetch archives\n"
		"                   1 - make white list\n"
		"                   2 - load white list to slaves\n"
		"                   3 - synchronize time only on slaves\n"
		"                   4 - (debug) get actual WL set on slaves -serviceOK/setList_actual*.csv\n"
		"  -R rootdir     root directory of the dir/file hierarchy on FTP (default: %s)\n"
		"  -S statedir    state directory on a non-volatile partition to keep\n"
		"                 data through different launching of the app (default: %s)\n"
		"\n"
		"  -t ttydev      tty device connected to the bus (default: %s)\n"
		"  -b baudrate    baud rate (default: %d)\n"
		"  -p N|O|E       parity, respectively: none, odd, even (default: %c)\n"
		"  -d databits    data bits (default: %d)\n"
		"  -s stopbits    stop bits (default: %d)\n"
		"\n"
		"  -l level       log level, default: INFO\n"
		"\nmode-specific options:\n"
		"  -D minutes     delay before reding archives for white list statistics (default: %d)",
		(int)(def_cfg.mode), def_cfg.root_dir, def_cfg.state_dir,
		def_cfg.port.tty_dev, def_cfg.port.baud_rate, def_cfg.port.parity,
		def_cfg.port.data_bits, def_cfg.port.stop_bits,
		def_cfg.delay_min
	);
}

int mbm_parse_args(int argc, char *argv[], mbm_config_t *cfg, int *hr)
{
	int opt;
	opterr = 0;
	
	memcpy(cfg, &def_cfg, sizeof(*cfg));
	
	while ((opt = getopt(argc, argv, "hm:R:S:t:b:p:d:s:l:D:")) != -1) {
		switch (opt) {
		case 'h':
			*hr = 1;
			break;
		case '?':
			pr_err("incorrect option '%c' - ignored\n", optopt);
			break;

		case 'm':
			cfg->mode = atoi(optarg);
			break;
		case 'R':
			cfg->root_dir = optarg;
			break;
		case 'S':
			cfg->state_dir = optarg;
			break;

		case 't':
			cfg->port.tty_dev = optarg;
			break;
		case 'b':
			cfg->port.baud_rate = atoi(optarg);
			break;
		case 'p':
			cfg->port.parity = *optarg;
			break;
		case 'd':
			cfg->port.data_bits = atoi(optarg);
			break;
		case 's':
			cfg->port.stop_bits = atoi(optarg);
			break;

		case 'l':
			cfg->log_level = atoi(optarg);
			app_log_set_level(cfg->log_level);
			break;

		case 'D':
			{
				int val = atoi(optarg);
				if (val >= 0) {
					cfg->delay_min = val;
				}
			}
			break;
		
		default:
			/* ignore */
			break;
		} /* switch */
	} /* while */

	if (*hr) {
		mbm_usage();
		return 0;
	}
	if (cfg->port.parity != 'N' && cfg->port.parity != 'E' &&
		cfg->port.parity != 'O') {
		pr_err("parity option is incorrect\n");
		mbm_usage();
		return -1;
	}
	if (cfg->mode < 0 || cfg->mode >= MBM_MODE_COUNT) {
		pr_err("mode is incorrect\n");
		mbm_usage();
		return -1;
	}
	{
		size_t len;
		len = strlen(cfg->state_dir) + 1 + MBM_STATE_FILENAME_MAX_LEN + 1;
		if (len > MBM_PATH_MAX) {
			pr_err("state directory is too long - use shorter paths\n");
			mbm_usage();
			return -1;
		}
	}
	return 0;
}

#ifdef DEBUG
void mbm_dump_config(mbm_config_t *cfg)
{
	pr_debug("Used config:\n");
	pr_debug("root_dir=%s, state_dir=%s\n", cfg->root_dir, cfg->state_dir);
	pr_debug("tty: device=%s, baud_rate=%d, parity=%c, data_bits=%d, stop_bits=%d\n",
		cfg->port.tty_dev, cfg->port.baud_rate, cfg->port.parity, 
		cfg->port.data_bits, cfg->port.stop_bits);
	pr_debug("mode: %d\n", cfg->mode);
	pr_debug("sleep time for WL: %d min\n", cfg->delay_min);
}
#endif

