#ifndef _MBM_TASK_WL_
#define _MBM_TASK_WL_


/** Create dir structure for WL making and setting:
* service[OK]/setList
*/
extern int mbm_init_wl_fs(mbm_context_t *ctx);

/** Create white list based on all arcs from all PKs and save it to the file in setList/
*/
extern int mbm_make_white_list(mbm_context_t *ctx);

/* load white list to all PKs from the file in service/setList/setList.csv */
extern int mbm_set_white_list(mbm_context_t *ctx);

/* read every PK and compile common WL.
* Save the WL to 
* - serviceOK/setList_actual.csv ordered by Arc ID
* - serviceOK/setList_actual_pk.csv ordered by PK ID, then Arc ID
* NOTE: now is for debugging purposes only, so no Russian messages etc.
*/
extern int mbm_get_actual_white_list(mbm_context_t *ctx);

#endif /* _MBM_TASK_WL_ */
