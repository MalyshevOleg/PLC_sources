#ifndef _MBM_MODBUS_FUNC_H_
#define _MBM_MODBUS_FUNC_H_

#include <modbus/modbus.h>

/* RTU max ADU len: 1 byte addr, PDU: FC(1)+ DL(1)+FL(1)+RT(1)+data, 2 bytes CRC = 7 + data len, so
* file data length is: max ADU len - 7 
*/
#define MBM_MAX_FILE_DATA_LEN			(MODBUS_RTU_MAX_ADU_LENGTH - 7)

/* note (OWEN-speicifc): provide functionality to request 1 record at a time */
typedef struct mbm_modbus_file {
	/* input data */
	uint8_t addr;						/* slave address */
	uint16_t file_no;					/* number of the file to read from */
	uint16_t rec_no;					/* number of the record to read */
	uint16_t regs_count;				/* number of regs (2-byte) to read: confirmed by OWEN */
	
	/* output data */
	uint8_t data[MBM_MAX_FILE_DATA_LEN];	/* response file data */
	uint8_t data_len;					/* response file data len in bytes */
} mbm_modbus_file_t;

/** Read a record from a file
* @param ctx - app context
* @param file_data - input: slave device file record info, output: data of file read and its length
* return 1 - OK (like libmodbus functions), data read, -1 -error, errno is set by libmodbus
*/
extern int mbm_modbus_read_file(modbus_t *mb, mbm_modbus_file_t *file_data);

#endif /* _MBM_MODBUS_FUNC_H_ */

