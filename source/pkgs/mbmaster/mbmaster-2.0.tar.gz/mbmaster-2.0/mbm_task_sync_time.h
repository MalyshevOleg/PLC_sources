#ifndef _MBM_TASK_SYNC_TIME_H_
#define _MBM_TASK_SYNC_TIME_H_

/* Time synchronization correction in seconds:
 * amount of seconds which is added to the time got on 
 * master to get future time that is sent to the target device
 * This time shift should compensate the delay that occurs 
 * between the moment of reception of local time 
 * and the moment of applying this time on the target device after
 * transferring the value via modbus
 * The value >=0 has a sence
 */
#define MBM_TIME_CORRECTION_SEC		3

extern void mbm_sync_time(mbm_network_t *mb_net);

#endif /* _MBM_TASK_SYNC_TIME_H_ */
