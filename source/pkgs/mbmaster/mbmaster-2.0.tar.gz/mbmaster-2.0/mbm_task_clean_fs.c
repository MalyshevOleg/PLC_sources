#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <stdlib.h>

#include "mbm_context.h"

#include "mbm_strings.h"
#include "app_log.h"
#include "mbm_utils.h"
#include "mbm_fs.h"

#include "mbm_task_clean_fs.h"

typedef struct clean_info {
	mbm_file_filter_data_t filter_data;

	char path[MBM_PATH_MAX];
	char *file_name;
	size_t root_dir_len;

	time_t time_min;	/* if old files are deleted by age */

	/* arcs only */
	int arc_type;
	char arc_id[8 + 1];
} clean_info_t;

typedef struct arc_type_scan_info {
	clean_info_t clean_info;
	size_t max_count;
	size_t arc_type_dir_len;
} arc_type_scan_info_t;

/*===============*/
/* Cleaning logs */
/*===============*/

#ifdef MBM_KEEP_LOG_NUM
static int comp_log_filter_item_time_and_order(const void *item1, const void *item2)
{
	int c1;
	mbm_file_filter_item_t *i1 = (mbm_file_filter_item_t *)item1;
	mbm_file_filter_item_t *i2 = (mbm_file_filter_item_t *)item2;

	c1 = COMPARE_NUM(i1->dt_full, i2->dt_full);

	/* dates are equal, compare orders */
	return c1 ? c1 : COMPARE_NUM(i1->add_key, i2->add_key);
}
#endif

/* filter any valid log file */
static int log_file_filter(const struct dirent *entry, void *data)
{
	int r;
	clean_info_t *info = (clean_info_t *)data;
	mbm_file_filter_data_t *fd = &info->filter_data;

	/* parse & check filename, save entry's time for adding */
	r = mbm_datetime_from_log_filename(entry->d_name, &fd->file_tm, &fd->file_time);
	return !r;
}

#ifdef MBM_KEEP_LOG_NUM
/* Asume it is called only on filterred log item, so some checks were passed OK */
static int log_entry_add(const struct dirent *entry, void *data)
{
	mbm_file_filter_item_t item;
	clean_info_t *info = (clean_info_t *)data;
	mbm_file_filter_data_t *fd = &info->filter_data;

	item.dt_full = fd->file_time;
	item.add_key = (long)mbm_order_from_log_filename(entry->d_name);

#ifdef DEBUG
	{
		int r =
#endif
		insert_unique_from_end(&item, fd->tab, fd->max_count,
								&fd->start_index, sizeof(item),
								&comp_log_filter_item_time_and_order,
								&comp_log_filter_item_time_and_order); /* key time == full time for logs */
#ifdef DEBUG
		log_debug("insert item %s: %d (%s)", entry->d_name, r,
				r == 1 ? "replaced" : (r == 2 ? "added/inserted" : "rejected"));
	}
#endif

	return 1; /* process all entries */
}

static int log_file_del(const struct dirent *entry, void *data)
{
	int r;
	mbm_file_filter_item_t item;
	clean_info_t *info = (clean_info_t *)data;
	mbm_file_filter_data_t *fd = &info->filter_data;

	/* if entry is not in the filter - delete it */
	item.dt_full = fd->file_time;
	item.add_key = (long)mbm_order_from_log_filename(entry->d_name);
	
	if (!bsearch(&item, &fd->tab[fd->start_index], fd->max_count - fd->start_index,
				sizeof(item), &comp_log_filter_item_time_and_order)) {
		/* entry is not found */
		strcpy(info->file_name, entry->d_name);
		r = unlink(info->path);
		if (r) {
			log_err(mbm_str_err_remove, &info->path[info->root_dir_len + 1], strerror(errno));
		} else {
			log_einfo(mbm_str_old_removed, &info->path[info->root_dir_len + 1]);
		}
	} else {
		log_debug("do not delete %s - filtered to keep", entry->d_name);
	}
		
	return 1; /* process all entries */
}
#endif

#ifndef MBM_KEEP_LOG_NUM
static int log_file_del_old(const struct dirent *entry, void *data)
{
	int r;
	clean_info_t *info = (clean_info_t *)data;
	mbm_file_filter_data_t *fd = &info->filter_data;

	log_debug("file_time=%d, time_min=%d", fd->file_time, info->time_min);
	if (fd->file_time < info->time_min) {
		/* file is too old - delete */
		strcpy(info->file_name, entry->d_name);
		r = unlink(info->path);
		if (r) {
			log_err(mbm_str_err_remove, &info->path[info->root_dir_len + 1], strerror(errno));
		} else {
			log_einfo(mbm_str_old_removed, &info->path[info->root_dir_len + 1]);
		}
	} else {
		log_debug("do not delete %s - is not old", entry->d_name);
	}
		
	return 1; /* process all entries */
}
#endif

/*===================*/
/* Cleaning archives */
/*===================*/

/* filter any valid log file */
static int arc_file_filter(const struct dirent *entry, void *data)
{
	int r;
	clean_info_t *info = (clean_info_t *)data;
	mbm_file_filter_data_t *fd = &info->filter_data;

	/* parse & check filename, save entry's time for adding */
	r = mbm_datetime_from_arc_filename(entry->d_name, &fd->file_tm, &fd->file_time,
										info->arc_id);
	return !r;
}

/* Asume it is called only on filterred log item, so some checks were passed OK */
static int arc_entry_add(const struct dirent *entry, void *data)
{
	clean_info_t *info = (clean_info_t *)data;
	mbm_add_arc_filter_item(entry->d_name, info->arc_type, &info->filter_data);
	return 1; /* process all entries */
}

static int arc_file_del(const struct dirent *entry, void *data)
{
	int r;
	mbm_file_filter_item_t item;
	clean_info_t *info = (clean_info_t *)data;
	mbm_file_filter_data_t *fd = &info->filter_data;

	/* if entry is not in the filter - delete it */
	item.dt_full = fd->file_time;
	
	if (!bsearch(&item, &fd->tab[fd->start_index], fd->max_count - fd->start_index,
				sizeof(item), &mbm_comp_arc_filter_item_time_full)) {
		/* entry is not found */
		*(info->file_name - 1) = '/';
		strcpy(info->file_name, entry->d_name);
		r = unlink(info->path);
		if (r) {
			log_err(mbm_str_err_remove, &info->path[info->root_dir_len + 1], strerror(errno));
		} else {
			log_einfo(mbm_str_old_removed, &info->path[info->root_dir_len + 1]);
		}
	} else {
		log_debug("do not delete %s - filtered to keep", entry->d_name);
	}
		
	return 1; /* process all entries */
}

static int arc_id_dir_filter(const struct dirent *entry, void *data)
{
	if (strlen(entry->d_name) != 8) {
		log_debug("entry: %s, len != 8 - ignoring", entry->d_name);
		return 0;
	}
	return 1;
}

/* Asume it is called only on filterred log item, so some checks were passed OK */
static int arc_id_dir_clean(const struct dirent *entry, void *data)
{
	int r;
	arc_type_scan_info_t *scan_info = (arc_type_scan_info_t *)data;

	scan_info->clean_info.path[scan_info->arc_type_dir_len] = '/';
	strcpy(&scan_info->clean_info.path[scan_info->arc_type_dir_len + 1], entry->d_name); /* 8 chars */
	strcpy(scan_info->clean_info.arc_id, entry->d_name); /* len checked by _filter callback above */
	
	mbm_file_filter_data_setup(&scan_info->clean_info.filter_data, scan_info->max_count);

	log_debug("cleaning arcs in counter dir: '%s' - started", scan_info->clean_info.path);

	r = mbm_scan_dir(scan_info->clean_info.path, scan_info->clean_info.root_dir_len,
						NULL, arc_file_filter, arc_entry_add, &scan_info->clean_info);
	/* restore current counter's dir name */
	scan_info->clean_info.path[scan_info->arc_type_dir_len + 1 + 8] = 0;
	if (!r) {
		/* NOTE: manual page for readdir says nothing about impossibility to delete entries
		* from a directory while reading the directory, so assume this is correct operation:
		* perform deleteing files while reading the directory.
		*/
		r = mbm_scan_dir(scan_info->clean_info.path, scan_info->clean_info.root_dir_len,
							NULL, arc_file_filter, arc_file_del, &scan_info->clean_info);
		/* restore current counter's dir name */
		scan_info->clean_info.path[scan_info->arc_type_dir_len + 1 + 8] = 0;

#if 0
		/* try removing the counter dir - if it's empty it will be removed */
		r = rmdir(scan_info->clean_info.path);
		if (!r) {
			log_einfo(mbm_str_old_arcdir_removed, 
						&scan_info->clean_info.path[scan_info->clean_info.root_dir_len + 1]);
		} else {
			log_debug("failed to remove counter arc directory '%s': %s (not empty - is not error)",
				scan_info->clean_info.path, strerror(errno));
		}
#endif
	}
	
	log_debug("cleaning arcs in counter dir: '%s' - done: %d", scan_info->clean_info.path, r);

	return 1;
}

/*===========*/
/* Interface */
/*===========*/

/* NOTE: all paths' lengths are verified in mbm_init_arc_fs(), so
 * this function skips these verifications
 */
int mbm_clean_archives(mbm_context_t *ctx)
{
	arc_type_scan_info_t scan_info;
	int i;
	size_t len;	/* length of ..archive/' directory in clean_info.path */

	log_info(mbm_str_clean_arc_started);

	memset(&scan_info, 0, sizeof(scan_info));
//	scan_info.clean_info.filter_data.start_tm = &ctx->start_tm;

	scan_info.clean_info.root_dir_len = ctx->root_dir_len;
	strcpy(scan_info.clean_info.path, ctx->root_dir);
	scan_info.clean_info.path[ctx->root_dir_len] = '/';
	len = ctx->root_dir_len + 1;
	strcpy(&scan_info.clean_info.path[len], SUBDIR_ARCHIVE);
	len += sizeof(SUBDIR_ARCHIVE) - 1;
	scan_info.clean_info.path[len++] = '/';

	for (i = 0; i < MBM_ARC_TYPE_COUNT; i++) {
		int eos;
		int r;
		
		log_debug("start processing of subdir %s/%s..", SUBDIR_ARCHIVE,
					mbm_arc_subdirs[i]);

		switch (i) {
			case MBM_ARC_TYPE_MON:
				scan_info.max_count = MBM_KEEP_ARC_MON;
				break;
			default:
			case MBM_ARC_TYPE_CUR:
				scan_info.max_count = MBM_KEEP_ARC_CUR;
				break;
		}
		scan_info.clean_info.arc_type = i;
		strcpy(&scan_info.clean_info.path[len], mbm_arc_subdirs[i]);
		scan_info.arc_type_dir_len = len + strlen(mbm_arc_subdirs[i]);

		scan_info.clean_info.file_name = &scan_info.clean_info.path[scan_info.arc_type_dir_len + 1 + 8 + 1]; /* /XXXXXXXX/ */

		r = mbm_scan_dir(scan_info.clean_info.path, scan_info.clean_info.root_dir_len, &eos, 
							arc_id_dir_filter, arc_id_dir_clean, &scan_info);
		log_debug("done processing of subdir %s/%s: %d", SUBDIR_ARCHIVE,
					mbm_arc_subdirs[i], r);
	}

	log_info(mbm_str_clean_arc_done);
	
	return 0;
}

int mbm_clean_logs(mbm_context_t *ctx)
{
	int r;
	clean_info_t info;
	

	log_info(mbm_str_clean_log_started);

	memset(&info, 0, sizeof(info));
//	info.filter_data.start_tm = &ctx->start_tm;
	info.root_dir_len = ctx->root_dir_len;
	strcpy(info.path, ctx->log_dir);
	info.path[ctx->log_dir_len] = '/';
	info.file_name = &info.path[ctx->log_dir_len + 1];

#ifdef MBM_KEEP_LOG_NUM
	mbm_file_filter_data_setup(&info.filter_data, MBM_KEEP_LOG_NUM);

	r = mbm_scan_dir(ctx->log_dir, ctx->root_dir_len, NULL,
						log_file_filter, log_entry_add, &info);
	if (!r) {
		r = mbm_scan_dir(ctx->log_dir, ctx->root_dir_len, NULL,
							log_file_filter, log_file_del, &info);
	}
#else
#ifdef MBM_KEEP_LOG_DAYS
	{
		struct tm tm_min;
//		tm_min = *(info.filter_data.start_tm);
		tm_min = ctx->start_tm;
		tm_min.tm_mday -= MBM_KEEP_LOG_DAYS;
		tm_min.tm_hour = 0;
		tm_min.tm_min = 0;
		tm_min.tm_sec = 0;
		info.time_min = mktime(&tm_min);
		log_debug("time_min=%d", info.time_min);
		r = mbm_scan_dir(ctx->log_dir, ctx->root_dir_len, NULL,
							log_file_filter, log_file_del_old, &info);
	}
#endif
#endif

	log_info(mbm_str_clean_log_done);
	return r;
}

