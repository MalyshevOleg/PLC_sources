#include <errno.h>
#include <string.h>

/* for app-specific constcnts */
#include "mbm_defs.h"

#include "mbm_strings.h"
#include "app_log.h"

#include "mbm_modbus_func.h"

/* "read file record" function code */
#define MBM_FC_READ_FILE_RECORD 0x14

/* check response:
 * follow libmodbus's check_confirmation sequence:
 *  - check expected length
 *     - if: 
 *         OK - chek FC, data length and fields..
 *         not OK - check for Exception response length 
 *         - if:
 *              OK - check exception code
 *              not OK - error
 */
static int check_confirmation(modbus_t *mb, uint8_t *req, 
							uint8_t *rsp, int rsp_len, int exp_rsp_len)
{
	if (rsp_len == exp_rsp_len) {
		int dl, fl, rt;
		/* check function */
		if (rsp[1] != req[1]) {			/* MODBUS: function code */
			log_debug("received function not corresponding to request: %d != %d", 
						rsp[1], req[1]);
			errno = EMBBADDATA;
			return -1;
		}

		/* function is OK - check length of data and rsp header  */
		dl = rsp[2];					/* MODBUS (FC=0x14): Resp. data Length */
		fl = rsp[3];					/* MODBUS (FC=0x14): Sub-Req. x, File Resp. length */
		rt = rsp[4];					/* MODBUS (FC=0x14): Sub-Req. x, Reference Type == 6 */
		if ((rt != 6) || 
			(dl != exp_rsp_len - 5) ||
			(fl != exp_rsp_len - 6)) {
			log_debug("bad lengths or ref type: "
				"rt=%d, dl: rsp=%d, exp=%d; fl: rsp=%d, exp=%d",
				rt, dl, exp_rsp_len - 5, fl, exp_rsp_len - 6);
			errno = EMBBADDATA;
			return -1;
		}

		/* OK */
		return exp_rsp_len - 7;	/* expected number of data bytes */
	} else if ((rsp_len == 5) && 
			(rsp[1] - 0x80 == req[1])) { /* adr(1)+fc_exc(1) + exc(1)+crc(2) */
		int exception_code = rsp[2];	/* MODBUS: Exception code */
		if (exception_code < MODBUS_EXCEPTION_MAX) {
			errno = MODBUS_ENOBASE + exception_code;
			log_debug("rsp: exception code: %02X", rsp[2]);
		} else {
			errno = EMBBADEXC;
			log_debug("rsp: exception code: %02X - BAD", rsp[2]);
		}
		return -1;
	}

	log_debug("response length not corresponding to computed length %d != %d",
				rsp_len, exp_rsp_len);

	errno = EMBBADDATA;
	return -1;
}

int mbm_modbus_read_file(modbus_t *mb, mbm_modbus_file_t *file_data)
{
	int r;
	uint8_t raw_req[10];
	int req_len, exp_rsp_len;
	uint8_t rsp[MODBUS_RTU_MAX_ADU_LENGTH];
	int attempts = MBM_MODBUS_RETRY;

	if (!file_data->file_no) {
		log_debug("wrong file_no = 0");
		errno = EINVAL;
		return -1;
	}

	/* calc expected response length and check it */
	exp_rsp_len = file_data->regs_count * 2;		/* in 2-byte registers */
	exp_rsp_len += 7;		/* RTU: 1 byte addr, PDU: FC(1)+ DL(1)+FL(1)+RT(1)+data, 2 bytes CRC */

	if (exp_rsp_len > MODBUS_RTU_MAX_ADU_LENGTH) {
		log_debug("wrong expected ADU length: %d", exp_rsp_len);
		errno = EINVAL;
		return -1;
	}

	raw_req[0] = file_data->addr;
	raw_req[1] = MBM_FC_READ_FILE_RECORD;
	raw_req[2] = 7;	/* length of bytes */
	/* 7 bytes are following */
	raw_req[3] = 6;	/* reference type - always 6 */
	
	raw_req[4] = (uint8_t)(file_data->file_no >> 8);	/* file num HI */
	raw_req[5] = (uint8_t)file_data->file_no;			/* file num LO */
	
	raw_req[6] = (uint8_t)(file_data->rec_no >> 8);	/* record num HI */
	raw_req[7] = (uint8_t)file_data->rec_no;			/* record num LO */

	raw_req[8] = (uint8_t)(file_data->regs_count >> 8);	/* record length HI */
	raw_req[9] = (uint8_t)file_data->regs_count;			/* record length LO */

	log_debug_buf("raw request", raw_req, 10, 'b');

	while (1) {
		req_len = modbus_send_raw_request(mb, raw_req, 10);
		if (req_len < 0) {
			return -1;
		}
		
		log_debug("request length=%d, expected: 12", req_len);
		req_len = modbus_receive_confirmation(mb, rsp);
		if (req_len < 0) {
			attempts--;
			if (attempts <= 0) {
				return -1;
			}
			log_debug("read file record error: %s (%d) - retry", modbus_strerror(errno), errno);
			continue;
		}
		break; /* OK */
	}
	
	log_debug_buf("raw response", rsp, req_len, 'b');

	/* check response */
	r = check_confirmation(mb, raw_req, rsp, req_len, exp_rsp_len);
	if (r < 0) {
		return -1;
	}

	/* Response OK: extract and convert data.
	* Danfoss-specific: data sould be stored in file in BE format, so
	* do not convert it to LE, just copy instead.
	*/
	/* MODBUS (FC=0x14): data bytes start at index 5 */
#if 0
	{
		int i;
		for (i = 0; i < file_data->regs_count; i++) {
			/* 5 - offset of data start in the response */
			file_data->data[i * 2] = rsp[5 + i * 2 + 1];	/* write LO byte of response first */
			file_data->data[i * 2 + 1] = rsp[5 + i * 2];	/* write HI byte of response next */
		}
	}
#else
	memcpy(file_data->data, &rsp[5], file_data->regs_count * 2);
#endif
	file_data->data_len = file_data->regs_count * 2;
	log_debug_buf("result data", file_data->data, file_data->data_len, 'b');

	return 1;
}

