#ifndef _MBM_ARGS_H_
#define _MBM_ARGS_H_

#include "mbm_network.h"

typedef enum mbm_mode {
	MBM_MODE_FETCH_ARCHIVES = 0,
	MBM_MODE_MAKE_WHITE_LIST,
	MBM_MODE_SET_WHITE_LIST,
	MBM_MODE_SYNC_TIME,
	MBM_MODE_GET_ACTUAL_WHITE_LIST,

	MBM_MODE_COUNT,
} mbm_mode_t;

typedef struct mbm_config {
	int log_level;
	const char *root_dir;	/* target files root dir */
	const char *state_dir;	/* keep state in this dir - should exist before running the app */

	mbm_mode_t mode;	/* what should be done: fetch arcs, make white list, etc. */

	mbm_port_config_t port;

	int delay_min;		/* for make white list mode (1) - alternative delay after resetting WLs on devices */
} mbm_config_t;

/* @return 0 - success, <0 - error */
extern int mbm_parse_args(int argc, char *argv[], mbm_config_t *cfg, int *hr);

#ifdef DEBUG
extern void mbm_dump_config(mbm_config_t *cfg);
#else
#define mbm_dump_config(cfg);
#endif

#endif /*_MBM_ARGS_H_*/
