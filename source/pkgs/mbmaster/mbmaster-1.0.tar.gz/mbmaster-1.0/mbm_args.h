#ifndef _MBM_ARGS_H_
#define _MBM_ARGS_H_

/* @return 0 - success, <0 - error */
extern int mbm_parse_args(int argc, char *argv[], mbm_context *ctx);

#ifdef DEBUG
extern void mbm_dump_config(mbm_context *ctx);
#else
#define mbm_dump_config(ctx);
#endif

#endif /*_MBM_ARGS_H_*/
