#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <limits.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <stdlib.h>

#include "mb_master.h"
#include "mbm_strings.h"
#include "app_log.h"
#include "mbm_fs.h"

const char *mbm_arc_subdirs[MBM_ARC_TYPE_COUNT] = {
	SUBDIR_ARCHIVE_CUR,
	SUBDIR_ARCHIVE_MON,
};

/******************/
/* Local methods      */
/******************/

/* build root_dir / sub_name and create the directory 
 * check that length of result dir with terminating 0 <= MBM_PATH_MAX
 * Doesn't use log - it may not have beed started yet
 * Note: root_dir MUST have length >= MBM_PATH_MAX
 * return codes:
 * 	0 - success:	directory exists
 *	1 - success:	directory created
 *	<0 = -errno fail:
 *	
 */
static int init_subdir(char *root_dir, const char *sub_name)
{
	struct stat sbuf;
	size_t root_len, sub_len;
	int r;

	root_len = strlen(root_dir);
	sub_len = strlen(sub_name);
	if (root_len + 1 + sub_len + 1 > MBM_PATH_MAX) {
		return -ENAMETOOLONG;
	}

	root_dir[root_len] = '/';
	memcpy(&root_dir[root_len + 1], sub_name, sub_len + 1);

	r = stat(root_dir, &sbuf);
	if (!r) {
		if (!S_ISDIR(sbuf.st_mode)) {
			return -ENOTDIR;		/* exists but not directory */
		}
		return 0;				/* exists and directory - OK */
	}
	
	/* some error - assume path does not exist - create */
	r = mkdir(root_dir, S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
	if (r) {
		return -errno;			/* directory creation failed */
	}
	
	return 1;					/* OK - directory created */
}

/******************/
/* Interface methods */
/******************/

/* log is not started yet */
int mbm_init_root_dir(mbm_context *ctx)
{
	mbm_config *cfg = &ctx->cfg;

	/* normalize root dir path and check */
	if (!realpath(cfg->root_dir, ctx->root_dir)) {
		pr_err("incorrect root dir '%s' specified: %s\n",
			cfg->root_dir, strerror(errno));
		return -1;
	}

	ctx->root_dir_len = strlen(ctx->root_dir);
	return 0;
}

int mbm_init_log_fs(mbm_context *ctx)
{
	int r;
	DIR *d;
	struct dirent *ep;
	struct dirent entry;
	int max_order;

	/* check result length to prevent logging in mbm_ensure_subdir */
	ctx->work_path_len = ctx->root_dir_len + 1 + sizeof(SUBDIR_SERVICE) + sizeof(SUBDIR_SERVICE_LOG) -1; /* / + service/ + log (w/o terminating 0) */
	if (ctx->work_path_len >= sizeof(ctx->work_path)) {
		pr_err("log directory path too long: %u\n", (unsigned)ctx->work_path_len);
		return -1;
	}

	strcpy(ctx->work_path, ctx->root_dir);
	r = init_subdir(ctx->work_path, SUBDIR_SERVICE);
	if (r >= 0) {
		r = init_subdir(ctx->work_path, SUBDIR_SERVICE_LOG);
	}

	if (r < 0) {
		pr_err("failed to create log subdirs: %s\n", strerror(-r));
		return -1;
	}

	/* scan log dir for current date and determine max order number */
	max_order = 0;
	d = opendir(ctx->work_path);
	if (!d) {
		pr_err("failed to open log directory '%s': %s\n", 
				ctx->work_path, strerror(errno));
		return -1;
	}

	while ((r = readdir_r(d, &entry, &ep)) == 0) {
		if (!ep) {
			break; /* end of stream */
		}
		/* lookup log files: YYYY-MM-DD-HH-mm-??hostname??-NN 
		 * for current day "YYYY-MM-DD-" get max number NN
		 */
		if (!strncmp(ep->d_name, ctx->start_dt_str, 11)) {
			int order;
			char *p = strrchr(ep->d_name, MBM_FNAME_SEP_CHAR);
			if (!p) {
				pr_err("wrong log file name '%s'\n", ep->d_name);
				continue;
			}
			p++;
			order = atoi(p);
			if (order > max_order) {
				max_order = order;
			}
		}
	}

	if (r) {
		pr_err("error while reading log dir '%s': %s\n", 
				ctx->work_path, strerror(r));
		closedir(d);
		return -1;
	}

	closedir(d);

	pr_debug("max_order=%d\n", max_order);
	max_order++;
	if (max_order > 99) {
		max_order = 99;	/* will stay at this number if overflows */
	}
	pr_debug("cur log order=%d\n", max_order);

	/* so we can build log file name now */
	ctx->log_file_name_len = MBM_DATETIME_LEN + 1 + ctx->hostname_len + 1 + 2; /* dir/YYYY-MM-DD-HH-mm-hn-NN (w/o terminating 0) */
	ctx->work_path_len += 1 + ctx->log_file_name_len;
	if (ctx->log_file_name_len >= sizeof(ctx->log_file_name) || 
		ctx->work_path_len >= sizeof(ctx->work_path)) {
		pr_err("log file name (%d) or path (%d) too long\n", 
				(int)ctx->log_file_name_len, (int)ctx->work_path_len);
		return -1;
	}

	sprintf(ctx->log_file_name, "%s-%s-%02d",
			ctx->start_dt_str, ctx->hostname, max_order);	/* log_file_name_len already calculated */
	strcat(ctx->work_path, "/");
	strcat(ctx->work_path, ctx->log_file_name);				/* work_path_len already calculated */
	
#ifdef DEBUG
	pr_debug("log_file_name_len: calc=%d, real=%d\n", 
				(int)ctx->log_file_name_len, (int)strlen(ctx->log_file_name));
	pr_debug("work_path_len: calc=%d, real=%d\n",
				(int)ctx->work_path_len, (int)strlen(ctx->work_path));
#endif
	return 0;
}

int mbm_init_arc_fs(mbm_context *ctx)
{
	int r;
	int i;
	size_t arc_dir_len;

	strcpy(ctx->work_path, ctx->root_dir);

	/* create archive dir */
	log_debug("initializing archive dir: %s/%s", ctx->work_path, SUBDIR_ARCHIVE);
	r = mbm_init_subdir(ctx, ctx->work_path, SUBDIR_ARCHIVE);
	if (r) {
		return r;
	}
	arc_dir_len = strlen(ctx->work_path);
	
	/* create archive/subdirs[i] */
	for (i = 0; i < MBM_ARC_TYPE_COUNT; i++) {
		size_t arc_file_max_len;
		/* init work_path for next cycle */
		ctx->work_path[arc_dir_len] = 0;
		log_debug("initializing archive subdir: %s/%s", ctx->work_path, mbm_arc_subdirs[i]);
		r = mbm_init_subdir(ctx, ctx->work_path, mbm_arc_subdirs[i]);
		if (r) {
			break;
		}

		/* calc max possible arc file path length */
		arc_file_max_len = strlen(ctx->work_path) + 1 + 			/* ..cur|mon/ */
						8 + 1 + 								/* ID/ */
						8 + 1 + sizeof(MBM_DATETIME_LEN) + 8;   /* ID-DATETIME-ID */
		log_debug("possible arc file path length: %d", arc_file_max_len);
		if (arc_file_max_len >= sizeof(ctx->work_path)) {
			log_err(mbm_str_err_arc_path_too_long, arc_file_max_len);
			return -1;
		}
	}
	
	return r;
}

/* here we can use log because it's assumed to have been started */
int mbm_init_subdir(mbm_context *ctx, char *root_dir, const char *sub_name)
{
	int r;

	/* root_dir will contain full sub-directory path upon successful call */
	r = init_subdir(root_dir, sub_name);
	
	switch (r) {
		case 0:
			break;
		case 1:
			log_info(mbm_str_dir_created, &root_dir[ctx->root_dir_len + 1]);
			r = 0;
			break;
		default:
			log_err(mbm_str_dir_failure, &root_dir[ctx->root_dir_len + 1], strerror(r));
			r = -1;
			break;
	}
	
	return r;
}

/* Assumes that:
 * 	- ctx->scan_buf allocated
 * If ctx->rec_len > 0:
 *	- ctx->rec_max_count >= 1
 *	- ctx->rec_len > 1
 * 	- ctx->rec_len  * ctx->rec_max_count <= ctx->scan_buf_size
 * If limit > 0 filter no more than specified number of entries, otherwise filter as many as possible
 */
int mbm_scan_dir(mbm_context *ctx, const char *dir, mbm_filter_cb filter, int limit)
{
	int r;
	DIR *d;
	struct dirent *ep;
	struct dirent entry;
	char *p;

	ctx->rec_count = 0;
	p = ctx->scan_buf;
	ctx->flags.scan_eos = 0;

	log_debug("scanning dir '%s'...", dir);

	d = opendir(dir);
	if (!d) {
		log_err(mbm_str_err_opendir, &dir[ctx->root_dir_len + 1], strerror(errno));
		return -1;
	}

	while ((r = readdir_r(d, &entry, &ep)) == 0) {
		if (!ep) {
			log_debug("dir '%s' reading done - no more items", dir);
			ctx->flags.scan_eos = 1;
			break; /* OK: end of stream */
		}

		if (filter(ctx, ep)) {
			/* add the entry name to the buffer */
			if (ctx->rec_len > 0) { /* fixed rec_len */
				strncpy(p, ep->d_name, ctx->rec_len -1);
				p[ctx->rec_len - 1] = 0;
				p += ctx->rec_len;
				ctx->rec_count++;
				log_debug("item '%s' added to scan buf, current count: %d",
							(p - ctx->rec_len), ctx->rec_count);

				/* check if more entries can be accumulated */
				if (ctx->rec_count >= ctx->rec_max_count) {
					log_debug("dir '%s' reading done - max item count in scan buf reached", dir);
					break;	/* OK: max_count of entries filtered */
				}
			} else { /* variable rec_len */
				size_t len = strlen(ep->d_name);
				if (ctx->scan_buf_size - (p - ctx->scan_buf) <= len) {
					log_debug("dir '%s' reading done - scan buf can't accept more entries", dir);
					break;	/* OK: buffer fulfilled */
				}
				strcpy(p, ep->d_name);
				p += len + 1;			/* every item includes terminating zero */
				ctx->rec_count++;
				log_debug("item '%s' added to scan buf, current count: %d",
							(p - len - 1), ctx->rec_count);
			}

			if (limit > 0 && ctx->rec_count >= limit) {
				log_debug("dir '%s' reading done - limit(%d) item count in scan buf reached", 
							dir, limit);
				break;		/* OK: limit of entries filtered*/
			}
		}
	}
	
	if (r) {
		log_err(mbm_str_err_readdir, &dir[ctx->root_dir_len + 1], strerror(r));
		//closedir(d);
		//return -1;	/* filtered entries still can be processed */
	}

	closedir(d);
	log_debug("scanning dir '%s'...done", dir);
	return 0;
}

int mbm_save_arc_file(mbm_context *ctx, char *data, size_t len)
{
	/* files are very shot - use non buffered IO */
	int fd;
	int r, attempt = 0;
	size_t written = 0;
	ssize_t count;

	fd = open(ctx->work_path, O_CREAT | O_WRONLY, 
			S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP | S_IROTH);
	if (fd < 0) {
		return -errno;
	}

	r = 0;
	while (len > 0 && attempt < 5) {
		count = write(fd, &data[written], len);

		if (count < 0) {
			if (errno == EAGAIN) {
				attempt++;
				continue;
			}
			break;
		}

		len -= count;
		written += count;
	}

	if (count < 0) {
		r = -errno;
	}

	close(fd);
	sync();	/* TODO: ?? or do it after all files saved */
	
	return r;
}


