#ifndef _DANFOSS_H_
#define _DANFOSS_H_

/* max addr 246 'cause 247 is used for network configuration purpose */
#define MBM_SLAVE_ADDR_MIN		1
#define MBM_SLAVE_ADDR_MAX		246

#define MBM_CONFIG_SLAVE_DEV	247
#define MBM_RESET_ADDR_REG	0xfff0
#define MBM_SET_ADDR_REG		0xfff1
#define MBM_RESET_ALL_ADDRS	0x0100

#define MBM_INFO_REG			0x0000
#define MBM_INFO_REG_COUNT	6

#define MBM_INFO_IDX_NAME		0
#define MBM_INFO_IDX_SN		3
#define MBM_INFO_IDX_STATUS	5

#define MBM_ST_OFF_FLASH				0
#define MBM_ST_OFF_RADIO				1
#define MBM_ST_OFF_NO_ARC				2
#define MBM_ST_OFF_NO_MON_ARC		3
#define MBM_ST_OFF_SENSOR_COUNT		7

/* Calendar: 6 regs: 0x0006 -0x000B*/
#define MBM_CALENDAR_REG		0x0006

#define MBM_SET_SLAVE_ADDR_ATTEMPTS_MAX	5
#define MBM_VERIFY_SLAVE_ADDR_COUNT			3

#define MBM_ARC_CUR_BASE_REG		0x0100
#define MBM_ARC_MON_BASE_REG		0x1000
#define MBM_ARC_IDX_ID				0
#define MBM_ARC_IDX_TIME			2
#define MBM_ARC_IDX_SIZE			8

#define MBM_ARC_CHANNEL_COUNT		256
#define MBM_ARC_MON_COUNT			18

#define MBM_ARC_HEADER_REG_COUNT	9

#define MBM_ARC_FILE_NO_BASE_CUR		1
#define MBM_ARC_HEADER_BASE_CUR		0x0100
#define MBM_ARC_FILE_NO_BASE_MON		1000
#define MBM_ARC_HEADER_BASE_MON		0x1000

#endif /* _DANFOSS_H_ */
