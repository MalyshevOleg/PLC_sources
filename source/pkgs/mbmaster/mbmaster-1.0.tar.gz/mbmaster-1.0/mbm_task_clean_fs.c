#define _XOPEN_SOURCE /* glibc2 needs this */
#include <time.h>

#include <unistd.h>
#include <errno.h>
#include <string.h>

#include "mb_master.h"
#include "mbm_strings.h"
#include "app_log.h"
#include "mbm_fs.h"

#include "mbm_task_clean_fs.h"

static int old_file_filter(mbm_context *ctx, const struct dirent *entry, size_t dt_offset)
{
	char *p;
	struct tm item_tm;
	time_t item_time;

	if ((entry->d_name[0] == '.') && 
		(entry->d_name[1] == '.' || entry->d_name[1] == 0)) {
		log_debug("item: '%s' - special - ignored", entry->d_name);
		return 0;
	}

	/* get date-time from the file name */
	memset(&item_tm, 0, sizeof(item_tm));
	p = strptime(&entry->d_name[dt_offset], MBM_DATETIME_FORMAT, &item_tm);

	/* sanity check */
	if (p && (*p == '-') && (p - &entry->d_name[dt_offset] == MBM_DATETIME_LEN)) {
		/* convert to time */
		item_tm.tm_isdst = ctx->start_tm.tm_isdst;
		item_time = mktime(&item_tm);
		log_debug("item: '%s' item_time=%ld", entry->d_name, (long)item_time);
		/* compare to min_time_log */
		if (item_time < ctx->filter_time) {
			log_debug("item: '%s' detected as OLD - filtered", entry->d_name);
			return 1;
		}
		log_debug("item: '%s' NOT detected as old - ignored", entry->d_name);
	} else {
		log_debug("item: '%s' has not correct log name - ignored", entry->d_name);
	}

	return 0;
}

static int old_log_filter(mbm_context *ctx, const struct dirent *entry)
{
	if (!strcmp(entry->d_name, ctx->log_file_name)) {
		log_debug("item: '%s' - current log - ignored", entry->d_name);
		return 0;
	}

	return old_file_filter(ctx, entry, 0);
}

static int old_arc_filter(mbm_context *ctx, const struct dirent *entry)
{
	return old_file_filter(ctx, entry, 9);	/* XXXXXXXX- = 9 */
}

/* assume that length of 'dir + / + filename' is less than 'dir' buffer:
 *  - for log_dir this is true because at this moment we've managed to build log_file
 *  - for arc dirs - verification of the length should be done before calling this function
 * dir is modified to build every file item, than dir is restored to its original value
 */
static int remove_filtered_files(mbm_context *ctx, char *dir, size_t dir_len)
{
	int i;
	char *p = ctx->scan_buf;
	int rc = 0;
	
	dir[dir_len] = '/';

	for (i = 0; i < ctx->rec_count; i++) {
		size_t len;
		int r;

		/* build current item filename */
		strcpy(&dir[dir_len + 1], p);
		log_debug("file name built: '%s'", dir);

		r = unlink(dir);
		
		/* log the relative to root_dir path of the item */
		if (r) {
			log_err(mbm_str_err_remove, &dir[ctx->root_dir_len + 1], strerror(errno));
			rc = -1;
		} else {
			log_info(mbm_str_old_removed, &dir[ctx->root_dir_len + 1]);
		}

		len = strlen(p);
		p += len + 1;
	}

	/* restore dir */
	dir[dir_len] = 0;
	log_debug("dir restored: '%s'", dir);

	return rc;
}

static void set_cleanup_filter_time(mbm_context *ctx, int months_ago)
{
	struct tm min_tm;

	/* determine min time to keep logs */
	min_tm = ctx->start_tm;
	min_tm.tm_mon -= months_ago;
	ctx->filter_time = mktime(&min_tm);

	/* re-check :
	 * if previous month doesn't have this day of month, then date is shifted to next month, so
	 * month difference is not satisfied  - correct such cases
	 */
	localtime_r(&ctx->filter_time, &min_tm);
	if (ctx->start_tm.tm_mon - min_tm.tm_mon != months_ago) {
		/* reset days of min_tm */
		min_tm.tm_mday = 0;
		min_tm.tm_hour = 23;
		min_tm.tm_min = 59;
		ctx->filter_time = mktime(&min_tm);
		localtime_r(&ctx->filter_time, &min_tm);
	}

#ifdef DEBUG
	{
		char time_buf[17];
		strftime(time_buf, sizeof(time_buf), MBM_DATETIME_FORMAT, &min_tm);
		log_debug("min_time= %ld => %s", (long)ctx->filter_time, time_buf);
	}
#endif
}

/* use work_path as directory and given subdir name as subdirectory */
static void clean_archives_in_subdir(mbm_context *ctx)
{
	int r;

	log_debug("cleaning arcs in counter dir: '%s' - started", ctx->work_path);

	do {
		r = mbm_scan_dir(ctx, ctx->work_path, &old_arc_filter, 0);
		if (!r) {
			r = remove_filtered_files(ctx, ctx->work_path, ctx->work_path_len);
			if (r) {
				log_debug("removing failed - no more arc dir scanning");
			}
		}
	} while (!r && !ctx->flags.scan_eos);

	/* try removing the counter dir - if it's empty it will be removed */
	r = rmdir(ctx->work_path);
	if (!r) {
		log_info(mbm_str_old_arcdir_removed, &ctx->work_path[ctx->root_dir_len]);
	} else {
		log_debug("failed to remove counter arc directory '%s': %s (not empty - is not error)",
			ctx->work_path, strerror(errno));
	}

	log_debug("cleaning arcs in counter dir: '%s' - done", ctx->work_path);
}

/* NOTE: all paths' lengths are verified in mbm_init_arc_fs(), so
 * this function skips these verifications
 */
int mbm_clean_archives(mbm_context *ctx)
{
	int i;
	int r;
	size_t arc_dir_len;
	
	log_info(mbm_str_clean_arc_started);

	/* setup scan buffer for arc files */
	ctx->rec_len = ctx->fname_size_arc;	/* fixed rec len for archive files */
	ctx->rec_max_count = ctx->scan_buf_size / ctx->rec_len;

	log_debug("ARC: rec_len=%d, rec_max_count=%d", 
				(int)ctx->rec_len, (int)ctx->rec_max_count);

	set_cleanup_filter_time(ctx, MBM_OLD_ARC_MONTH);

	/* process directories */

	arc_dir_len = ctx->root_dir_len + 1 + sizeof(SUBDIR_ARCHIVE) - 1;
	strcpy(ctx->work_path, ctx->root_dir);								/* work_path: /root */
	ctx->work_path[ctx->root_dir_len] = '/';
	strcpy(&ctx->work_path[ctx->root_dir_len + 1], SUBDIR_ARCHIVE);		/* work_path: /root/archive */

	for (i = 0; i < MBM_ARC_TYPE_COUNT; i++) {
		DIR *d;
		struct dirent entry;
		struct dirent *ep;
		size_t arc_type_dir_len;
		size_t arc_counter_dir_len;

		log_debug("start processing subdir %s/%s..", SUBDIR_ARCHIVE, mbm_arc_subdirs[i]);

		arc_type_dir_len = arc_dir_len + 1 + strlen(mbm_arc_subdirs[i]);
		ctx->work_path[arc_dir_len] = '/';
		strcpy(&ctx->work_path[arc_dir_len + 1], mbm_arc_subdirs[i]);	/* work_path: /root/archive/current */

		/* now we can calc ID dir length: name length of a counter dir is constant = 8 chars */
		arc_counter_dir_len = 8 + 1 + arc_type_dir_len;

		log_debug("opening dir '%s'", ctx->work_path);
		d = opendir(ctx->work_path);
		if (!d) {
			log_err(mbm_str_err_opendir, &ctx->work_path[ctx->root_dir_len + 1], 
					strerror(errno));
			continue;
		}

		while ((r = readdir_r(d, &entry, &ep)) == 0) {
			if (!ep) {
				log_debug("dir '%s' reading done - no more items", ctx->work_path);
				break; /* OK: end of stream */
			}
			log_debug("entry: %s", ep->d_name);
			if (strlen(ep->d_name) != 8) {
				log_debug("entry: %s, len != 8 - ignoring", ep->d_name);
				continue;
			}

			/* build work_path:=work_path + /entry */
			ctx->work_path[arc_type_dir_len] = '/';
			strcpy(&ctx->work_path[arc_type_dir_len + 1], ep->d_name);	/* work_path: /root/archives/current/IDXX */
			ctx->work_path_len = arc_counter_dir_len;
			/* process the counter's directory */
			clean_archives_in_subdir(ctx);
			/* restore upper directory */
			ctx->work_path[arc_type_dir_len] = 0;						/* work_path: /root/archives/current */
		}

		if (r) {
			log_err(mbm_str_err_readdir, &ctx->work_path[ctx->root_dir_len + 1], 
					strerror(r));
			continue;
		}

		closedir(d);
	}
	
	log_info(mbm_str_clean_arc_done);
	return 0;
}

int mbm_clean_logs(mbm_context *ctx)
{
	int r;

	log_info(mbm_str_clean_log_started);
	
	/* setup scan buffer for log files */
//	ctx->rec_len = ctx->fname_size_log;
//	ctx->rec_max_count = ctx->scan_buf_size / ctx->rec_len;
	ctx->rec_len = 0; /* variable rec len: in order to process records created before hostname change */

	log_debug("LOG: rec_len=%d, rec_max_count=%d", 
				(int)ctx->rec_len, (int)ctx->rec_max_count);

	set_cleanup_filter_time(ctx, MBM_OLD_LOG_MONTH);

	/* set work_path to log directory, 
	 * check for length is not needed - it's been already done before log opened
	 */
	strcpy(ctx->work_path, ctx->root_dir);
	strcat(ctx->work_path, "/");
	strcat(ctx->work_path, SUBDIR_SERVICE);
	strcat(ctx->work_path, "/");
	strcat(ctx->work_path, SUBDIR_SERVICE_LOG);
	ctx->work_path_len = strlen(ctx->work_path);

	do {
		r = mbm_scan_dir(ctx, ctx->work_path, &old_log_filter, 0);
		if (!r) {
			r = remove_filtered_files(ctx, ctx->work_path, ctx->work_path_len);
			if (r) {
				log_debug("removing failed - no more log dir scanning");
			}
		}
	} while (!r && !ctx->flags.scan_eos);

	log_info(mbm_str_clean_log_done);
	
	return 0;
}

