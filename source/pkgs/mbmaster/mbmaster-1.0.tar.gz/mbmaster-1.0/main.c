#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <time.h>
#include <stdlib.h>

#include "mb_master.h"
#include "mbm_strings.h"
#include "app_log.h"
#include "mbm_args.h"
#include "mbm_fs.h"
#include "mbm_task_modbus.h"
#include "mbm_task_clean_fs.h"

/* default config */
static mbm_config def_cfg = {
	.root_dir = "/home/alex/owen/tmp/ftp",
	
	.tty_dev = "/dev/ttyS1",
	.baud_rate = 9600,
	.parity = 'N',
	.data_bits = 8,
	.stop_bits = 1,
	
};

static int mbm_init(int argc, char *argv[], mbm_context *ctx)
{
	int r;
	time_t start_time = time(NULL);
	
	/* init context and set default config */
	memset(ctx, 0, sizeof(*ctx));
	ctx->def_cfg = &def_cfg;
	memcpy(&ctx->cfg, &def_cfg, sizeof(ctx->cfg));

	/* TODO: read_config (from /etc/mbm.cfg)
	 * - move? root_dir there: ?do not allow override root_dir from command line 
	 * can be worked around by wrapping shell script with root_dir specified,
	 * so user should specify running of the script in his crontab
	 */

	/* parse args */
	r = mbm_parse_args(argc, argv, ctx);
	if (r || ctx->flags.need_help) {
		return r;
	}
	mbm_dump_config(ctx);

	/* build and check root dir */
	r = mbm_init_root_dir(ctx);
	if (r) {
		return r;
	}

	/* prepare start date-time values */
	ctx->start_time = start_time;
	localtime_r(&start_time, &ctx->start_tm);
	strftime(ctx->start_dt_str, sizeof(ctx->start_dt_str), 
				MBM_DATETIME_FORMAT, &ctx->start_tm);
	ctx->start_dt_str[sizeof(ctx->start_dt_str) - 1] = 0;

	/* build hostname */
	if (gethostname(ctx->hostname, sizeof(ctx->hostname)) < 0) {
		pr_err("failed to determine hostname: %s\n", strerror(errno));
		strcpy(ctx->hostname, "localhost");
	}
	ctx->hostname_len = strlen(ctx->hostname);

#if MBM_USE_FULL_DOMAIN_HOSTNAME
	/* append dot */
	ctx->hostname[ctx->hostname_len] = '.';
	/* getdomainname requires echo "domain name" > /proc/sys/kernel/domainname 
	 * or "(none)" will be returned
	 */
	if (getdomainname(&ctx->hostname[ctx->hostname_len + 1], 
					sizeof(ctx->hostname) - (ctx->hostname_len + 1)) < 0) {
		pr_err("failed to determine domainname: %s\n", strerror(errno));
		strcpy(&ctx->hostname[ctx->hostname_len + 1], "localdomain");
	}
	ctx->hostname_len = strlen(ctx->hostname);
#endif

	/* make up log dir and file name, create subdirs as need */
	r = mbm_init_log_fs(ctx);
	return r;
}

static int mbm_setup(mbm_context *ctx)
{
	/* estimate scan buffer size and allocate it */
	
	ctx->fname_size_log = 20 + ctx->hostname_len + 1;	/* YYYY-mm-DD-HH-MM-hostname-NN &0 */
	ctx->fname_size_arc = 34 + 1;						/* XXXXXXXX-YYYY-mm-DD-HH-MM-XXXXXXXX &0 */
	
	/* alloc scan buffer for MBM_SCAN_BUF_MAX_RECORDS max. records */
	ctx->scan_buf_size = ctx->fname_size_log > ctx->fname_size_arc ? 
						ctx->fname_size_log : ctx->fname_size_arc;
	ctx->scan_buf_size *= MBM_SCAN_BUF_MAX_RECORDS ;

	ctx->scan_buf = malloc(ctx->scan_buf_size);
	if (!ctx->scan_buf) {
		log_err(mbm_str_err_scan_buf_alloc, ctx->scan_buf_size);
		ctx->scan_buf_size = 0;
		return -1;
	}

	log_debug("scan_buf allocated, size=%d bytes", ctx->scan_buf_size);
	return 0;
}

static void mbm_done(mbm_context *ctx)
{
	/* free scan buffer */
	if (ctx->scan_buf) {
		free(ctx->scan_buf);
		ctx->scan_buf = NULL;
		ctx->scan_buf_size = 0;
	}
}

int main(int argc, char *argv[])
{
	int r, arc_fs_init = 0;
	mbm_context ctx;

	/* initialization before log start */
	r = mbm_init(argc, argv, &ctx);
	if (r || ctx.flags.need_help) {
		return r;
	}

	/* init logging */
	r = app_log_start(ctx.work_path, APP_NAME, mbm_str_log_started);
	if (r) {
		pr_err("failed to init log '%s': %s\n", 
				ctx.work_path, strerror(errno));
		return r;
	}

	r = mbm_setup(&ctx);
	if (r) {
		return r;
	}

	/* log is available now */	
	do {
		r = mbm_init_arc_fs(&ctx);
		arc_fs_init = (r == 0);
		if (!arc_fs_init) {
			log_err(mbm_str_err_fail_init_arc_fs);
		}

		if (mbm_modbus_init(&ctx) == 0) {	/* init lib, assign addresses to salves */
			if (arc_fs_init) {
				mbm_fetch_archives(&ctx);
			}
			mbm_sync_time(&ctx);
			mbm_modbus_done(&ctx);
		}

		if (arc_fs_init) {
			mbm_clean_archives(&ctx);
		}
		mbm_clean_logs(&ctx);
	} while (0);

	mbm_done(&ctx);

	/* stop logging */
	app_log_stop(mbm_str_log_stopped);
	
	return r;
}

