#ifndef _MBM_TASK_CLEAN_FS_H_
#define _MBM_TASK_CLEAN_FS_H_

extern int mbm_clean_archives(mbm_context *ctx);
extern int mbm_clean_logs(mbm_context *ctx);

#endif /* _MBM_TASK_CLEAN_FS_H_ */

