#ifndef _MB_MASTER_H_
#define _MB_MASTER_H_

#include <limits.h>
#include <time.h>
#include <stdint.h>
#include <stdio.h>

#include <modbus/modbus.h>

/* danfoss & modbus constants */
#include "danfoss.h"

#include "version.h"

/* for testing paths vars length checking */
#define MBM_PATH_MAX					PATH_MAX
//#define MBM_PATH_MAX					

#define MBM_FNAME_SEP_CHAR			'-'
#define MBM_SCAN_BUF_MAX_RECORDS	100
#define MBM_DATETIME_FORMAT			"%Y-%m-%d-%H-%M"
#define MBM_DATETIME_LEN				16

/* clean log files elder than specified months */
#define MBM_OLD_LOG_MONTH				1
/* clean arc files elder than specified months */
#define MBM_OLD_ARC_MONTH				18

#define MBM_SAME_ARC_TIME_SHIFT_MIN	15

/* Time synchronization correction in seconds:
 * amount of seconds which is added to the time got on 
 * master to get future time that is sent to the target device
 * This time shift should compensate the delay that occurs 
 * between the moment of reception of local time 
 * and the moment of applying this time on the target device after
 * transferring the value via modbus
 * The value >=0 has a sence
 */
#define MBM_TIME_CORRECTION_SEC		3

/* note using full-domain hostname requires system 
 * to return domain name via getdomainname() - 
 * for that the system should be configured before: echo domain > /proc/sys/kernel/domainname
 */
#define MBM_USE_FULL_DOMAIN_HOSTNAME	0

#if MBM_USE_FULL_DOMAIN_HOSTNAME
/* RFC2181: length of a full domain name is up to 255 octets */
#define MBM_MAX_HOSTNAME_LEN			255
#else
/* RFC2181: length of a label 1..63 octets */
#define MBM_MAX_HOSTNAME_LEN			63
#endif

#define SUBDIR_ARCHIVE			"archive"
#define SUBDIR_ARCHIVE_CUR		"current"
#define SUBDIR_ARCHIVE_MON	"monthly"
#define SUBDIR_SERVICE			"service"
#define SUBDIR_SERVICE_LOG		"LogFile"

typedef struct mbm_config {
	int log_level;
	const char *root_dir;	/* target files root dir */

	const char *tty_dev;	/* tty device for access to the bus */
	int baud_rate;
	char parity;
	int data_bits;
	int stop_bits;
	
} mbm_config;

typedef struct mbm_slave_dev {
	char dev_name[6 + 1]; /* zero terminated */
	uint32_t dev_sn; /* MODBUS_GET_INT32_FROM_INT16 - low register becomes high word in the result dword */
	char dev_sn_str[8 + 1];
	uint16_t status;
	int sensor_count;		/* from status - count of sensors being archived by the slave */
	struct {
		unsigned addr_check_passed: 1;

		/* status flags */
		unsigned no_arc: 1;			/* can't perform operations with archives - OP2 */
		unsigned no_mon_arc: 1;		/* can't perform operations with last mon archives - OP1 */
		unsigned fail_radio: 1;
		unsigned fail_flash: 1;
	} flags;
} mbm_slave_dev;

typedef struct mbm_context {
	mbm_config *def_cfg;
	mbm_config cfg;

	struct {
		unsigned need_help: 1;	/* help requested */

		unsigned scan_eos: 1;		/* scan dir end-of-stream */
	} flags;

	char hostname[MBM_MAX_HOSTNAME_LEN + 1];	/* + 1 - terminating 0 */
	size_t hostname_len;

	/* start time */
	time_t start_time;
	struct tm start_tm;
	char start_dt_str[MBM_DATETIME_LEN + 1];	/* YYYY-MM-DD-HH-mm0 */
	
	/* directories */
	char root_dir[MBM_PATH_MAX];
	size_t root_dir_len;

	char work_path[MBM_PATH_MAX];
	size_t work_path_len;
	char log_file_name[MBM_DATETIME_LEN + 1 + 1 + MBM_MAX_HOSTNAME_LEN + 2 + 1];
	size_t log_file_name_len;
	
	/* directory processing stuff */
	size_t fname_size_log;
	size_t fname_size_arc;
	
	char *scan_buf;			/* records of variable len are possible: for log files if hostname is changed */
	size_t scan_buf_size;
	size_t rec_count;			/* current number of filtered records */
	size_t rec_len;			/* current record len = string len +1 (zero termination). If rec_len=0 - records have variable length */
	size_t rec_max_count;	/* current max number of records if rec_len > 0, otherwise - is not used */

	time_t filter_time;		/* calculated time to be used in item filter (e.g. min time of files to filter, or time of cur archive) */
	char id_str[8 + 1];		/* uint32_t -> numeric string of 8 digits, zero-terminated 
							* MODBUS_GET_INT32_FROM_INT16 - low register becomes high word in the result dword
							*/

	/* modbus data */
	modbus_t *mb;			/* libmodbus context */
	mbm_slave_dev mb_slave[MBM_SLAVE_ADDR_MAX + 1]; /* indexed by slave addr */
	int mb_max_addr;		/* max slave addr assigned:  MBM_MB_SLAVE_ADDR_ MIN..MAX*/
	int mb_slaves_count;		/* number of slaves successfully passed addr check */
} mbm_context;

#define pr_err(fmt, ...) \
	do {\
		fprintf(stderr, APP_NAME ": Error(%s): " fmt, __func__, ##__VA_ARGS__);\
	} while(0)

#ifdef DEBUG
#define pr_debug(fmt, ...) \
	do {\
		fprintf(stderr, APP_NAME ": " fmt, ##__VA_ARGS__);\
	} while(0)
#else
#define pr_debug(fmt, ...)
#endif

#endif /*_MB_MASTER_H_*/
