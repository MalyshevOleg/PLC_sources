#!/bin/sh

cat > $PWD/version.h << END
#ifndef _VERSION_H_
#define _VERSION_H_

#define APP_NAME "$1"
#define APP_VERSION "$2"

#endif
END
