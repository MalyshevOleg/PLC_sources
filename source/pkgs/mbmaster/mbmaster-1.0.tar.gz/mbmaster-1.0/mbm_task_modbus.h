#ifndef _MBM_TASK_MODBUS_H_
#define _MBM_TASK_MODBUS_H_

extern int mbm_modbus_init(mbm_context *ctx);
extern void mbm_modbus_done(mbm_context *ctx);
extern int mbm_fetch_archives(mbm_context *ctx);
extern int mbm_sync_time(mbm_context *ctx);

#endif /* _MBM_TASK_MODBUS_H_ */
