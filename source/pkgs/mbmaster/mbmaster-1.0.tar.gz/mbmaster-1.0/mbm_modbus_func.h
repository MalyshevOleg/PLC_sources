#ifndef _MBM_MODBUS_FUNC_H_
#define _MBM_MODBUS_FUNC_H_

#define MBM_MAX_DATA_LEN 252

/* note (OWEN-speicifc): provide functionality to request 1 record at a time */
typedef struct mbm_modbus_file {
	/* input data */
	uint8_t addr;						/* slave address */
	uint16_t file_no;					/* number of the file to read from */
	uint16_t rec_no;					/* number of the record to read */
	uint16_t regs_count;				/* number of regs (2-byte) to read: confirmed by OWEN */
	
	/* output data */
	uint8_t data[MBM_MAX_DATA_LEN];	/* response file data */
	uint8_t data_len;					/* response file data len in bytes */
} mbm_modbus_file;

/** Read a record from a file
* @param ctx - app context
* @param file_data - input: slave device file record info, output: data of file read and its length
* return 1 - OK (like libmodbus functions), data read, -1 -error, errno is set by libmodbus
*/
extern int mbm_modbus_read_file(mbm_context *ctx, mbm_modbus_file *file_data);

#endif /* _MBM_MODBUS_FUNC_H_ */

