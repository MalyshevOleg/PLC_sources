#ifndef _MBM_STRINGS_H_
#define _MBM_STRINGS_H_

const char *mbm_str_log_started;
const char *mbm_str_log_stopped;

const char *mbm_str_dir_created;
const char *mbm_str_dir_failure;

const char *mbm_str_err_arc_path_too_long;
const char *mbm_str_err_scan_buf_alloc;
const char *mbm_str_err_opendir;
const char *mbm_str_err_readdir;
const char *mbm_str_err_remove;
const char *mbm_str_err_fail_init_arc_fs;
const char *mbm_str_err_assign_addrs;
const char *mbm_str_err_libmodbus;

const char *mbm_str_warn_set_slave_addr;
const char *mbm_str_err_set_slave_addr;
const char *mbm_str_err_slave_addr_verify;
const char *mbm_str_received_addr_different;
const char *mbm_str_err_slave_info;
const char *mbm_str_err_sync_time;
const char *mbm_str_err_sys_time;
const char *mbm_str_err_fetch_arc_header;
const char *mbm_str_err_fetch_arc;
const char *mbm_str_err_save_arc;
const char *mbm_str_err_fetch_arcs;

const char *mbm_str_slave_found;
const char *mbm_str_slave_addrs_assigned;
	
const char *mbm_str_old_removed;
const char *mbm_str_old_arcdir_removed;

const char *mbm_str_fetch_archives_started;
const char *mbm_str_arc_fetched;
const char *mbm_str_fetch_archives_stopped;

const char *mbm_str_sync_time_started;
const char *mbm_str_slave_time_synced;
const char *mbm_str_sync_time_stopped;

const char *mbm_str_clean_log_started;
const char *mbm_str_clean_log_done;
const char *mbm_str_clean_arc_started;
const char *mbm_str_clean_arc_done;

#endif /* _MBM_STRINGS_H_ */

