#define _XOPEN_SOURCE /* glibc2 needs this */
#include <time.h>

#include <errno.h>
#include <string.h>
#include <unistd.h>

int usleep(useconds_t usec); /*TODO: _XOPEN_SOURCE makes the declaration unavailable?? */
 
#include "mb_master.h"
#include "mbm_strings.h"
#include "app_log.h"
#include "mbm_fs.h"
#include "mbm_modbus_func.h"

#include "mbm_task_modbus.h"

typedef struct arc_header {
	uint16_t arc_id[2];
	uint16_t arc_time[6];
	uint16_t arc_size[1];
} arc_header;

/* str size is >= 9: 8 decimal digits + terminating 0 
* NOTE: id in normal encoding LE, so in the memory low byte is first
* but string should be with first high byte
*/
static void devsn_to_str(uint32_t id, char *str)
{
	sprintf(str, "%02d", (id >> 24));
	sprintf(str + 2, "%06d", (id & 0xffffff));
}
static void arcid_to_str(uint32_t id, char *str)
{
	uint8_t b;
	int i;

	for (i = 0; i < 4; i++) {
		b = ((uint8_t *)&id)[i];
		sprintf(&str[i * 2], "%02X", b);
	}
}

static int assign_slave_addrs(mbm_context *ctx)
{
	int r;
	int attempts;
	int count;
	int addr;
	
	/* start addr assigning - target addr:=0xfe */
	r = modbus_set_slave(ctx->mb, MBM_CONFIG_SLAVE_DEV);
	if (r < 0) {
		log_err(mbm_str_err_libmodbus, modbus_strerror(errno));
		return -1;	/* fatal: can't assign addresses */
	}

	r = modbus_write_register(ctx->mb, 
		MBM_RESET_ADDR_REG, MBM_RESET_ALL_ADDRS);
	log_debug("reset all addresses, rc(ignored)=%d: %s",
			 	r, r < 0 ? modbus_strerror(errno) : "OK");

	/* assign addresses */
	attempts = 0;
	ctx->mb_max_addr = MBM_SLAVE_ADDR_MIN;
	do {
		usleep(50 * 1000); /* wait a bit to avoid errors w/o debug + by Semenov - 500*/

		/* set cur addr */
		r = modbus_write_register(ctx->mb, MBM_SET_ADDR_REG, ctx->mb_max_addr);
		if (r == 1) {
			log_debug("address %d assigned OK, going on..", ctx->mb_max_addr);
			attempts = 0;
			ctx->mb_max_addr++;
			if (ctx->mb_max_addr > MBM_SLAVE_ADDR_MAX) {
				log_debug("all possible addresses are assigned, the job's well done");
				break;
			}
		} else { /* assume r = -1 (error)*/
			attempts++;
			log_warn(mbm_str_warn_set_slave_addr, ctx->mb_max_addr, 
						attempts, modbus_strerror(errno));

			/* reset addr */
			r = modbus_write_register(ctx->mb, MBM_RESET_ADDR_REG, ctx->mb_max_addr);
			log_debug("attempt: %d - addr %d reset, rc(ignored)=%d: %s", 
					attempts, ctx->mb_max_addr, r, r < 0 ? modbus_strerror(errno) : "OK");

			if (attempts >= MBM_SET_SLAVE_ADDR_ATTEMPTS_MAX) {
				log_err(mbm_str_err_set_slave_addr, ctx->mb_max_addr);
				break;
			}
		}
	} while (1);

	/* correct max valid addr for both exit cases */
	ctx->mb_max_addr--;	
	count = ctx->mb_max_addr - (MBM_SLAVE_ADDR_MIN - 1);
	log_debug("addresses assigned for %d slaves (max_addr=%d)",
				count, ctx->mb_max_addr);

	if (count <= 0) {
		return -1;
	}
	
	/* verify addresses */
	for (addr = MBM_SLAVE_ADDR_MIN; addr <= ctx->mb_max_addr; addr++) {
		int i;
		uint16_t a;
		
		/* set slave addr: = current */
		r = modbus_set_slave(ctx->mb, addr);
		if (r < 0) {
			log_err(mbm_str_err_slave_addr_verify, addr, modbus_strerror(errno));
			continue;	/* not fatal: try check another addr */
		}

		for (i = 0; i < MBM_VERIFY_SLAVE_ADDR_COUNT; i++) {
			r = modbus_read_registers(ctx->mb, MBM_SET_ADDR_REG, 1, &a);
			log_debug("addr %d verification %d: rc=%d, val=%u", addr, i, r, a);
			if (r < 0 || a != addr) {
				break;
			}
		}

		if (r < 0 || a != addr) {
			log_err(mbm_str_err_slave_addr_verify, addr, 
				r < 0 ? modbus_strerror(errno) : mbm_str_received_addr_different);
			continue;
		}

		ctx->mb_slave[addr].flags.addr_check_passed = 1;
		ctx->mb_slaves_count++;

		log_debug("slave addr %d verified", addr);
	}

	log_info(mbm_str_slave_addrs_assigned, 
		MBM_SLAVE_ADDR_MIN, ctx->mb_max_addr, ctx->mb_slaves_count);

	return ctx->mb_slaves_count > 0 ? 0 : -1;
}

static void update_slave_status(mbm_context *ctx, int addr, uint16_t status)
{
	ctx->mb_slave[addr].status = status;

	ctx->mb_slave[addr].sensor_count = status >> MBM_ST_OFF_SENSOR_COUNT; 
	ctx->mb_slave[addr].flags.fail_flash = (status >> MBM_ST_OFF_FLASH) & 1;
	ctx->mb_slave[addr].flags.fail_radio = (status >> MBM_ST_OFF_RADIO) & 1;
	ctx->mb_slave[addr].flags.no_arc = (status >> MBM_ST_OFF_NO_ARC) & 1;
	ctx->mb_slave[addr].flags.no_mon_arc = (status >> MBM_ST_OFF_NO_MON_ARC) & 1;
}

static void fetch_slaves_info(mbm_context *ctx)
{
	int addr;

	/* read slaves' info */
	for (addr = MBM_SLAVE_ADDR_MIN; addr <= ctx->mb_max_addr; addr++) {
		uint16_t info[MBM_INFO_REG_COUNT];	/* name, SN, status */
		int r, i;

		if (!ctx->mb_slave[addr].flags.addr_check_passed) {
			continue;
		}

		/* read the slave's info */

		/* set slave addr: = current */
		r = modbus_set_slave(ctx->mb, addr);
		if (r < 0) {
			log_err(mbm_str_err_libmodbus, modbus_strerror(errno));
		} else {
//uncomment to see exact exchange when getting DevSN
//modbus_set_debug(ctx->mb, 1);
			r = modbus_read_registers(ctx->mb, MBM_INFO_REG, 
									MBM_INFO_REG_COUNT, info);
//modbus_set_debug(ctx->mb, 0);
			if (r < 0) {
				log_err(mbm_str_err_slave_info, addr, modbus_strerror(errno));
			}
		}

		if (r < 0) {
			/* should not happen, but if happen - mark the slave */
			sprintf(ctx->mb_slave[addr].dev_name, "Unk%03d", addr);
		} else {
			int j = 0;
			for (i = MBM_INFO_IDX_NAME; i < MBM_INFO_IDX_NAME + 3; i++) {
				ctx->mb_slave[addr].dev_name[j++] = MODBUS_GET_HIGH_BYTE(info[i]);
				ctx->mb_slave[addr].dev_name[j++] = MODBUS_GET_LOW_BYTE(info[i]);
			}
			/* MODBUS_GET_INT32_FROM_INT16: low register becomes high word in the result dword */
			ctx->mb_slave[addr].dev_sn = MODBUS_GET_INT32_FROM_INT16(info, 
														MBM_INFO_IDX_SN);
			update_slave_status(ctx, addr, info[MBM_INFO_IDX_STATUS]);
		}

		devsn_to_str(ctx->mb_slave[addr].dev_sn, ctx->mb_slave[addr].dev_sn_str);
		log_info(mbm_str_slave_found, addr, ctx->mb_slave[addr].dev_name, 
				ctx->mb_slave[addr].dev_sn_str, ctx->mb_slave[addr].status,
				ctx->mb_slave[addr].sensor_count, 
				ctx->mb_slave[addr].flags.fail_flash ? "FAIL" : "OK",
				ctx->mb_slave[addr].flags.fail_radio ? "FAIL" : "OK",
				ctx->mb_slave[addr].flags.no_arc ? "YES" : "NO",
				ctx->mb_slave[addr].flags.no_mon_arc ? "YES" : "NO");
	}
}

#if 0
static int fetch_slave_status(mbm_context *ctx, int addr)
{
	int r;
	uint16_t status;

	r = modbus_read_registers(ctx->mb, MBM_INFO_REG + MBM_INFO_IDX_STATUS, 
							1, &status);
	if (r < 0) {
		log_err(mbm_str_err_slave_info, addr, modbus_strerror(errno));
		return -1;
	}

	update_slave_status(ctx, addr, status);
	log_debug("fetched slave status: addr=%d, SN=%s, status=0x%04X "
		"(sensors: %d, flash: %s, radio: %s, op2: %s, op1: %s)", 
			addr, ctx->mb_slave[addr].dev_sn_str, 
			ctx->mb_slave[addr].status,
			ctx->mb_slave[addr].sensor_count, 
			ctx->mb_slave[addr].flags.fail_flash ? "FAIL" : "OK",
			ctx->mb_slave[addr].flags.fail_radio ? "FAIL" : "OK",
			ctx->mb_slave[addr].flags.no_arc ? "YES" : "NO",
			ctx->mb_slave[addr].flags.no_mon_arc ? "YES" : "NO");
	return 0;
}
#endif

int mbm_modbus_init(mbm_context *ctx)
{
	int r;
	mbm_config *cfg;

	cfg = &ctx->cfg;

	/* Modbus ops */
	ctx->mb = modbus_new_rtu(cfg->tty_dev, cfg->baud_rate, 
								cfg->parity, cfg->data_bits, cfg->stop_bits);
	if (!ctx->mb) {
		log_err(mbm_str_err_libmodbus, modbus_strerror(errno));
		goto err_new;
	}
	log_debug("modbus context created: %p", ctx->mb);

#ifdef DEBUG
	if (cfg->log_level >= APP_DEBUG) {
		modbus_set_debug(ctx->mb, 1);
	}
#endif

	r = modbus_rtu_get_serial_mode(ctx->mb);
	if (r == -1) {
		log_warn("failed to determine serial mode: %s", modbus_strerror(errno));
	} else {
		log_debug("serial mode: %s", 
			r == MODBUS_RTU_RS232 ? "RS232" :
			r == MODBUS_RTU_RS485 ? "RS485" : "invalid");
	}

#ifdef DEBUG
	{
		struct timeval tv;
		modbus_get_response_timeout(ctx->mb, &tv);
		log_debug("response timeout: %d sec, %d usec", tv.tv_sec, tv.tv_usec);
		modbus_get_byte_timeout(ctx->mb, &tv);
		log_debug("byte timeout: %d sec, %d usec", tv.tv_sec, tv.tv_usec);
	}
#endif

	/* connect */
	r = modbus_connect(ctx->mb);
	if (r) {
		log_err(mbm_str_err_libmodbus, modbus_strerror(errno));
		goto err_conn;
	}
	log_debug("modbus connection established");

	r = modbus_rtu_set_serial_mode(ctx->mb, MODBUS_RTU_RS485);
	if (r == -1) {
		log_err("failed to set RS485 serial mode: %s", modbus_strerror(errno));
		goto err_setmode;
		
	} else {
		log_debug("RS485 serial mode set");
	}

	r = assign_slave_addrs(ctx);
	if (r) {
		log_err(mbm_str_err_assign_addrs);
		goto err_addrs;
	}

	fetch_slaves_info(ctx);
	
	log_debug("mbm_modbus_init OK");

	return 0;
	
err_addrs:
err_setmode:
	modbus_close(ctx->mb);
err_conn:
	modbus_free(ctx->mb);
err_new:
	return -1;
}

void mbm_modbus_done(mbm_context *ctx)
{
	modbus_close(ctx->mb);
	log_debug("modbus connection closed");
	modbus_free(ctx->mb);
	log_debug("modbus context freed");
}

static int same_arc_filter(mbm_context *ctx, const struct dirent *entry)
{
	char *p;
	struct tm item_tm;
	time_t item_time;
	double time_shift;
	
	if ((entry->d_name[0] == '.') && 
		(entry->d_name[1] == '.' || entry->d_name[1] == 0)) {
		log_debug("item: '%s' - special - ignored", entry->d_name);
		return 0;
	}

	/* check id-part */
	if (memcmp(entry->d_name, ctx->id_str, 8) || (entry->d_name[8] != '-')) {
		log_debug("item: '%s' - is not for current arc id %s - ignored", 
			entry->d_name, ctx->id_str);
		return 0;
	}

	/* get date-time from the file name */
	memset(&item_tm, 0, sizeof(item_tm));
	p = strptime(&entry->d_name[9], MBM_DATETIME_FORMAT, &item_tm);

	/* sanity check */
	if (p && (*p == '-') && (p - &entry->d_name[9] == MBM_DATETIME_LEN)) {
		/* convert to time */
		item_tm.tm_isdst = ctx->start_tm.tm_isdst;	/* the same is_dst as for arc time conversion */
		item_time = mktime(&item_tm);
		log_debug("item: '%s' item_time=%ld", entry->d_name, (long)item_time);

		/* compare time */
		time_shift = difftime(item_time, ctx->filter_time);
		if (time_shift < 0) {
			time_shift = -time_shift;
		}
		
		if (time_shift < (MBM_SAME_ARC_TIME_SHIFT_MIN * 60)) {
			log_debug("item: '%s' detected as the same (time_shift=%d sec) - filtered", 
				entry->d_name, time_shift);
			return 1;
		}
		log_debug("item: '%s' NOT detected as the same - ignored", entry->d_name);
	} else {
		log_debug("item: '%s' has not correct arc name - ignored", entry->d_name);
	}

	return 0;
}

/* Assume: work_path is set to /root/arcs/arc-type", work_path_len is set properly too
 * returns count of fetched archives: 1 or 0
 * channel & mon_shift are used for logging only, mon_shift < 0 means that it should not be logged
 */
static int fetch_channel_archive(mbm_context *ctx, int addr, int channel, int mon_shift,
								int arc_header_reg, int file_no)
{
	int count = 0;	
	uint16_t arc_header[MBM_ARC_HEADER_REG_COUNT];
	uint32_t arc_id;
	struct tm filter_tm;
	time_t arc_expiration_time;
	int r;
	char arc_time_str[MBM_DATETIME_LEN + 1];

	r = modbus_read_registers(ctx->mb, arc_header_reg, 
			MBM_ARC_HEADER_REG_COUNT, arc_header);
	if (r < 0) {
		log_err(mbm_str_err_fetch_arc_header, ctx->mb_slave[addr].dev_sn_str, addr, 
					channel, mon_shift, modbus_strerror(errno));
		return 0;	/* no file fetched */
	}

	/*
	* MODBUS_GET_INT32_FROM_INT16: low register becomes high word in the result dword
	*/
	arc_id = MODBUS_GET_INT32_FROM_INT16(arc_header, MBM_ARC_IDX_ID);
	arcid_to_str(arc_id, ctx->id_str);
	
	log_debug("arc header: dev %s (addr=%d), channel=%d, mon=%d: "
		"arc_id=%s, %04u-%02u-%02u %02u:%02u:%02u, size=%u BYTES",
		ctx->mb_slave[addr].dev_sn_str, addr, channel, mon_shift,
		ctx->id_str, 
		arc_header[MBM_ARC_IDX_TIME + 5], arc_header[MBM_ARC_IDX_TIME + 4], 
		arc_header[MBM_ARC_IDX_TIME + 3],
		arc_header[MBM_ARC_IDX_TIME + 2], arc_header[MBM_ARC_IDX_TIME + 1],
		arc_header[MBM_ARC_IDX_TIME],
		arc_header[MBM_ARC_IDX_SIZE]);

	/* prepare filter time. Arc's time format is:
	 * sec 0..59
	 * min 0..59
	 * hour 0..23
	 * mday 1..31
	 * mon 1.12
	 * year 2010..2100 
	 */
	memset(&filter_tm, 0, sizeof(filter_tm));
	filter_tm.tm_isdst = ctx->start_tm.tm_isdst;	/* the same is_dst as for arc name's time conversion */
	filter_tm.tm_sec = arc_header[MBM_ARC_IDX_TIME];
	filter_tm.tm_min = arc_header[MBM_ARC_IDX_TIME + 1];
	filter_tm.tm_hour = arc_header[MBM_ARC_IDX_TIME + 2];
	filter_tm.tm_mday = arc_header[MBM_ARC_IDX_TIME + 3];
	filter_tm.tm_mon = arc_header[MBM_ARC_IDX_TIME + 4] - 1;		/* tm_mon - 0..11 */
	filter_tm.tm_year = arc_header[MBM_ARC_IDX_TIME + 5] - 1900;	/* tm_year - the number of years since 1900 */
	strftime(arc_time_str, sizeof(arc_time_str), MBM_DATETIME_FORMAT, &filter_tm);
	ctx->filter_time = mktime(&filter_tm);

	/* check whether arc is too old, if so, don't fetch it - 
	 * prevent senseless fetching, saving and deleting
	 */
	filter_tm.tm_mon += MBM_OLD_ARC_MONTH;
	arc_expiration_time = mktime(&filter_tm);
	if (arc_expiration_time < ctx->start_time) {
		log_debug("arc is too old - don't fetch it: dev %s (addr=%d), channel=%d, mon=%d: arc_id=%s",
			ctx->mb_slave[addr].dev_sn_str, addr, channel, mon_shift, ctx->id_str);
		return 0;
	}

	/* make id directory path and create the directory as need */
	r = mbm_init_subdir(ctx, ctx->work_path, ctx->id_str);
	if (r) {
		return 0;	/* no file fetched */
	}
	/* so work_path is set to "/root/arcs/arc-type/arc-id" directory, update path's len: 1 - slash, 8 - arc-id*/
	ctx->work_path_len +=  1 + 8;

	/* setup scanning directory */
	ctx->rec_len = ctx->fname_size_arc;	/* fixed rec len for archive files */
	ctx->rec_max_count = ctx->scan_buf_size / ctx->rec_len;

	log_debug("scandir for fetch arc prepared: rec_len=%d, rec_max_count=%d, "
				"arc time(filter time): %s", 
				(int)ctx->rec_len, (int)ctx->rec_max_count, arc_time_str);

	/* scan current dir to find at least an arc file which time is up to 15 minutes different
	 * with current archive's time 
	 */
	r = mbm_scan_dir(ctx, ctx->work_path, same_arc_filter, 1);
	if (r) {
		return 0;	/* no file fetched */
	}

	log_debug("same arc id=%s %sfound, %sfetch it", ctx->id_str,
		ctx->rec_count ? "" : "NOT ",
		ctx->rec_count ? "DON'T " : "");

	/* if item filtered, skip current arc, otherwise - fetch and store */
	if (!ctx->rec_count) {
		mbm_modbus_file arc_file;
		arc_file.addr = (uint8_t)addr;
		arc_file.file_no = (uint16_t)file_no;
		arc_file.rec_no = 0;
		/* confirmed by OWEN: TelegramSize in bytes, so convert them into regs, 
		* then, when saving file, convert back 
		*/
		arc_file.regs_count = arc_header[MBM_ARC_IDX_SIZE] / 2 +
						(arc_header[MBM_ARC_IDX_SIZE] & 1 ? 1 : 0);

		r = mbm_modbus_read_file(ctx, &arc_file);
		if (r < 0) {
			log_err(mbm_str_err_fetch_arc, ctx->mb_slave[addr].dev_sn_str, addr, 
					channel, mon_shift, modbus_strerror(errno));
			return 0;	/* no file fetched */
		}

		/* prepare work_path: "/root/arcs/arc-type/arc-id/arc-file-name" 
		* note: path length is checked in init_arc_fs()
		*/
		ctx->work_path[ctx->work_path_len] = '/';
		sprintf(&ctx->work_path[ctx->work_path_len + 1], "%s-%s-%s",
			ctx->id_str, arc_time_str, ctx->mb_slave[addr].dev_sn_str);

		log_debug("file name for arc %s built: %s", ctx->id_str, ctx->work_path);		

		/* correct file length as need, see arc_file.regs_count comments above */
		if (arc_header[MBM_ARC_IDX_SIZE] & 1) {
			/* we've read 1 byte more then actual file length */
			arc_file.data_len -= 1;
			log_debug("arc file length corrected by 1 byte: %u", arc_file.data_len);
		} else {
			log_debug("arc file length NOT corrected: %u", arc_file.data_len);
		}

		r = mbm_save_arc_file(ctx, (char *)arc_file.data, arc_file.data_len);
		if (!r) {
			log_info(mbm_str_arc_fetched, ctx->mb_slave[addr].dev_sn_str, 
					channel, mon_shift, &ctx->work_path[ctx->root_dir_len]);
			count = 1; /* OK */
		} else {
			log_err(mbm_str_err_save_arc, ctx->mb_slave[addr].dev_sn_str, addr, 
					channel, mon_shift, strerror(-r));
		}
	}
	
	return count;
}

/* Assume: work_path is set to /root/arcs/arc-type", work_path_len is set properly too
 * returns count of fetched archives: >= 0 
 */
static int fetch_archives_of_type(mbm_context *ctx, int arc_type)
{
	int r;
	int count = 0;	
	int addr;
	size_t arc_type_dir_len;
	int file_no;
	int channel;	/* the same as sensor order number */
	int mon_shift;
	int arc_header_reg;

	if (arc_type < 0 || arc_type >= MBM_ARC_TYPE_COUNT) {
		log_debug("%s: unsupported arc_type %d", arc_type);
		return 0;
	}

	arc_type_dir_len = ctx->work_path_len;

	/* for each valid slave: */
	for (addr = MBM_SLAVE_ADDR_MIN; addr <= ctx->mb_max_addr; addr++) {
		if (!ctx->mb_slave[addr].flags.addr_check_passed) {
			log_debug("skip addr %d (check not passed)", addr);
			continue;
		}

		/* target addr:=addr */
		r = modbus_set_slave(ctx->mb, addr);
		if (r < 0) {
			log_err(mbm_str_err_fetch_arcs, ctx->mb_slave[addr].dev_sn_str, addr, 
					modbus_strerror(errno));
			continue;	/* not fatal: try another device */
		}

		log_debug("fetch arcs of type %d from dev %s (addr=%d) - started",
					arc_type, ctx->mb_slave[addr].dev_sn_str, addr);

		switch (arc_type) {
		case MBM_ARC_TYPE_CUR:
			for (channel = 0; channel < MBM_ARC_CHANNEL_COUNT; channel++) {
				file_no = MBM_ARC_FILE_NO_BASE_CUR + channel;
				arc_header_reg = MBM_ARC_HEADER_BASE_CUR + 
								(MBM_ARC_HEADER_REG_COUNT) * channel;

				log_debug("fetch arcs of type 'CUR' from dev %s (addr=%d): "
					"channel=%d, arc_header_reg=0x%04X, file_no=%d",
							ctx->mb_slave[addr].dev_sn_str, addr, 
							channel, arc_header_reg, file_no);
				count += fetch_channel_archive(ctx, addr, channel, -1, 
												arc_header_reg, file_no);

				/* restore work_path */
				ctx->work_path[arc_type_dir_len] = 0;
				ctx->work_path_len = arc_type_dir_len;
			}
			break;

		case MBM_ARC_TYPE_MON:
			for (channel = 0; channel < MBM_ARC_CHANNEL_COUNT; channel++) {
				for (mon_shift = 0; mon_shift < MBM_ARC_MON_COUNT; mon_shift++) {
					file_no = MBM_ARC_FILE_NO_BASE_MON + 
							(MBM_ARC_MON_COUNT) * channel + 
							mon_shift;
					arc_header_reg = MBM_ARC_HEADER_BASE_MON + 
									(MBM_ARC_HEADER_REG_COUNT) * (
										(MBM_ARC_MON_COUNT) * channel + 
										mon_shift
									);
					log_debug("fetch arcs of type 'MON' from dev %s (addr=%d): "
						"channel=%d, arc_header_reg=0x%04X, file_no=%d",
								ctx->mb_slave[addr].dev_sn_str, addr, 
								channel, arc_header_reg, file_no);
					count += fetch_channel_archive(ctx, addr, channel, mon_shift, 
													arc_header_reg, file_no);

					/* restore work_path */
					ctx->work_path[arc_type_dir_len] = 0;
					ctx->work_path_len = arc_type_dir_len;
				}
			}
			break;
		}

		log_debug("fetch arcs of type %d from dev %s (addr=%d) - done",
					arc_type, ctx->mb_slave[addr].dev_sn_str, addr);
	}

	return count;
}

int mbm_fetch_archives(mbm_context *ctx)
{
	int count = 0;	
	int i;
	size_t arc_dir_len;

	log_info(mbm_str_fetch_archives_started);

	/* prepare root directory for archives */
	strcpy(ctx->work_path, ctx->root_dir);
	ctx->work_path[ctx->root_dir_len] = '/';
	strcpy(&ctx->work_path[ctx->root_dir_len + 1], SUBDIR_ARCHIVE);
	arc_dir_len = strlen(ctx->work_path); /* len is OK - checked in init_arc_fs*/

	log_debug("fetch archives: work path is set to arc root: '%s'", ctx->work_path);

	for (i = 0; i < MBM_ARC_TYPE_COUNT; i++) {
		/* set arc-type work path */
		ctx->work_path[arc_dir_len] = '/';
		strcpy(&ctx->work_path[arc_dir_len + 1], mbm_arc_subdirs[i]);
		ctx->work_path_len = arc_dir_len + 1 + strlen(mbm_arc_subdirs[i]);	/* len is OK - checked in init_arc_fs*/
		log_debug("fetch archives: work path is set to arc type dir: '%s'", ctx->work_path);

		count += fetch_archives_of_type(ctx, i);
		
		/* no need to restore work path - it will be set up correctly at the next iteration */
	}
	
	log_info(mbm_str_fetch_archives_stopped, count);
	return 0;
}

int mbm_sync_time(mbm_context *ctx)
{
	int addr;
	int count = 0;
	time_t cur_time;
	struct tm cur_tm;
	int r = 0;
	uint16_t calendar[6];

	log_info(mbm_str_sync_time_started);
	
	/* for each valid slave: */
	for (addr = MBM_SLAVE_ADDR_MIN; addr <= ctx->mb_max_addr; addr++) {
		if (!ctx->mb_slave[addr].flags.addr_check_passed) {
			log_debug("skip addr %d (check not passed)", addr);
			continue;
		}

		/* target addr:=addr */
		r = modbus_set_slave(ctx->mb, addr);
		if (r < 0) {
			log_err(mbm_str_err_sync_time, ctx->mb_slave[addr].dev_sn_str, addr, 
					modbus_strerror(errno));
			continue;	/* not fatal: try another device */
		}

		/* get current time */
		cur_time = time(NULL);
		cur_time += (MBM_TIME_CORRECTION_SEC);
		if (!localtime_r(&cur_time, &cur_tm)) {
			/* sys err */
			log_err(mbm_str_err_sys_time, strerror(errno));
			break;
		}

		/* Setup device calendar. The format is:
		 * sec 0..59
		 * min 0..59
		 * hour 0..23
		 * mday 1..31
		 * mon 1.12
		 * year 2010..2100 
		 */

		calendar[0] = cur_tm.tm_sec;
		calendar[1] = cur_tm.tm_min;
		calendar[2] = cur_tm.tm_hour;
		calendar[3] = cur_tm.tm_mday;
		calendar[4] = cur_tm.tm_mon + 1;		/* tm_mon 0..11 */
		calendar[5] = cur_tm.tm_year + 1900;	/* tm_year - the number of years since 1900 */

		/* do not use function 0x50 (SetTime) from owen doc - confirmed by Owen */
		r = modbus_write_registers(ctx->mb, MBM_CALENDAR_REG, 6, (uint16_t *)calendar);
		if (r < 0) {
			log_err(mbm_str_err_sync_time, ctx->mb_slave[addr].dev_sn_str, addr, 
					modbus_strerror(errno));
			continue;	/* not fatal: try another device */
		}

		count++;
		log_info(mbm_str_slave_time_synced, ctx->mb_slave[addr].dev_sn_str);
	}

	log_info(mbm_str_sync_time_stopped, count);
	
	return 0;
}

