#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <stdlib.h>

#include "mb_master.h"
#include "mbm_strings.h"
#include "app_log.h"

#include "mbm_args.h"

static void mbm_usage(mbm_context *ctx)
{
	mbm_config *dcfg = ctx->def_cfg;
	
	printf(
		APP_NAME " (" APP_VERSION "): perform modbus master's tasks\n"
		"Usage:\n"
		"   " APP_NAME " options\n"
		"\nOptions:\n"
		"  -R rootdir     root directory of the dir/file hierarchy on FTP (default: %s)\n"
		"\n"
		"  -t ttydev      tty device connected to the bus (default: %s)\n"
		"  -b baudrate    baud rate (default: %d)\n"
		"  -p N|O|E       parity, respectively: none, odd, even (default: %c)\n"
		"  -d databits    data bits (default: %d)\n"
		"  -s stopbits    stop bits (default: %d)\n"
		"\n"
		"  -l level       log level, default: INFO\n",
		dcfg->root_dir,
		dcfg->tty_dev, dcfg->baud_rate, dcfg->parity, 
		dcfg->data_bits, dcfg->stop_bits
	);
}

int mbm_parse_args(int argc, char *argv[], mbm_context *ctx)
{
	mbm_config *cfg;
	int opt;
	opterr = 0;
	
	cfg = &ctx->cfg;
	
	while ((opt = getopt(argc, argv, "hR:t:b:p:d:s:l:")) != -1) {
		switch (opt) {
		case 'h':
			ctx->flags.need_help = 1;
			break;
		case '?':
			pr_err("incorrect option '%c' - ignored\n", optopt);
			break;

		case 'R':
			cfg->root_dir = optarg;
			break;

		case 't':
			cfg->tty_dev = optarg;
			break;
		case 'b':
			cfg->baud_rate = atoi(optarg);
			break;
		case 'p':
			cfg->parity = *optarg;
			break;
		case 'd':
			cfg->data_bits = atoi(optarg);
			break;
		case 's':
			cfg->stop_bits = atoi(optarg);
			break;

		case 'l':
			cfg->log_level = atoi(optarg);
			app_log_set_level(cfg->log_level);
			break;
			
		default:
			/* ignore */
			break;
		} /* switch */
	} /* while */

	if (ctx->flags.need_help) {
		mbm_usage(ctx);
		return 0;
	}
	if (cfg->parity != 'N' && cfg->parity != 'E' &&
		cfg->parity != 'O') {
		pr_err("parity option is incorrect\n");
		mbm_usage(ctx);
		return -1;
	}
	return 0;
}

#ifdef DEBUG
void mbm_dump_config(mbm_context *ctx)
{
	mbm_config *cfg = &ctx->cfg;
	
	pr_debug("Used config:\n");
	pr_debug("root_dir=%s\n", cfg->root_dir);
	pr_debug("tty: device=%s, baud_rate=%d, parity=%c, data_bits=%d, stop_bits=%d\n",
		cfg->tty_dev, cfg->baud_rate, cfg->parity, cfg->data_bits, cfg->stop_bits);
}
#endif

