#ifndef _MBM_FS_H_
#define _MBM_FS_H_

#include <dirent.h>

/* names of arc-type subdirs */
typedef enum mbm_arc_type {
	MBM_ARC_TYPE_CUR = 0,
	MBM_ARC_TYPE_MON,

	MBM_ARC_TYPE_COUNT
} mbm_arc_type;

extern const char *mbm_arc_subdirs[MBM_ARC_TYPE_COUNT];

/** Initialize root_dir and check its existence. Doesn't create it.
 * @param ctx - app context
 * @return 0 - success, <0 - error
 * @note For log is not yet started prints errors to stderr in English
 */
extern int mbm_init_root_dir(mbm_context *ctx);

/** Create path of log directory, 
 * put the path into work_path with length in work_path_len;
 * put log file name into ctx->log_file_name with length in log_file_name_len
 * @param ctx - app context
 * @return 0 - success, <0 - error
 * @note For log is not yet started prints errors to stderr in English
 */
extern int mbm_init_log_fs(mbm_context *ctx);

/** Create dir structure for arcs: /archive/current|monthly
 * @param ctx - app context
 * return 0 - success, <0 - error
 */
extern int mbm_init_arc_fs(mbm_context *ctx);

/** Create  subdirectory name and ensure that the directory exists.
 * Create the subdirectory as need.
 * @param ctx - context - used for printing relative to root paths into log
 * @param root_dir - root directory assumed to exist
 * @param sub_name - sub-directory name 
 * @return 0 - success, <0 - error
 * @note Used when log is already started, so logs errors
 */
extern int mbm_init_subdir(mbm_context *ctx, char *root_dir, const char *sub_name);

typedef int (*mbm_filter_cb)(mbm_context *ctx, const struct dirent *entry);

/**
 * @param filter - callback - returns 1 if given dir entry should be added to the internal buffer of filtered items, 0 - otherwise
 * @param limit - filter no more entries then specified by limit
 */
extern int mbm_scan_dir(mbm_context *ctx, const char *dir, mbm_filter_cb filter, int limit);

/** Save data of archive file.
 * @param ctx - app context - ctx->work_path contains path of the file to be created and the data
 *                                          to be saved to.
 * @param data - pointer to the data buffer
 * @param len - length of the data to save
 * @return 0 - success, <0 - error (check errno)
 */
extern int mbm_save_arc_file(mbm_context *ctx, char *data, size_t len);

#endif /* _MBM_FS_H_ */
