#ifndef TELEGRAM_H
#define TELEGRAM_H

#include <stdint.h>
#include <stdio.h>

struct telegram_header_t 
{
	int16_t    rssi;       /* уровень сигнала при приёме этой телеграммы */
    /* begin of header */
	uint8_t     length;     /* Длинна посылки, без этого поля и CRC, 1 байт, формат hex. */
	uint8_t     type;       /* Тип телеграммы, 1 байт, формат hex. Для инсталляционной телеграммы значение 46h, для телеграммы с данными значение 44h. */
	uint16_t    vendor;     /* Код производителя, 2 байта формат hex. Значение EE3Eh. */
	uint32_t    serial;     /* Серийный номер прибора учета, подключенного к данному каналу измерения, 4 байта, формат BCD. */
	uint8_t     version;    /* Версия ПО БИА, 1 байт, формат hex. */
	uint8_t     phys;       /* Тип измеряемой среды, 1 байт, формат hex. Значения: 01h –нефть, 02h – электроэнергия, 03h – газ, 04h – тепло, 05h – пар, 06h – вода (температура 30-90˚С), 07h – вода, 09h – сжатый воздух. */
    /* end of header */
} __attribute__((packed));

struct telegram_data_common_t 
{
    /* common part for bia and bsrt */
	uint8_t     hdr_id;     /* Идентификатор заголовка, 1 байт, формат hex, значение 7Ah. */
	uint8_t     counter;    /* Счетчик телеграмм, 1 байт, формат hex. Инкрементируется при каждой отправке телеграммы. Сквозной для инсталляционных телеграмм и телеграмм с данными. */
	uint8_t     errcode;    /* Код ошибки прибора, 1 байт, формат hex. */
	uint16_t    encrypt_sign;   /* Сигнатура шифрования, 2 байта, формат hex. Значения 0000h – шифрование не применяется; 3005h – шифрование AES-128, 2 байта шифруется. */
	uint16_t    encrypt_token;  /* Маркер шифрования, 2 байта, формат hex, значение 2F2Fh. */
} __attribute__((packed));

struct datetime_t
{
    uint8_t     dim;
    uint8_t     type;
    uint32_t	data;
} __attribute__((packed));

struct date_t
{
	uint8_t 	dim;
	uint8_t 	type;
	uint16_t	data;
} __attribute__((packed));

struct bcd24_t
{
	uint8_t		dim;
	uint8_t		type;
	uint8_t		data[3];
} __attribute__((packed));

struct bcd32_t
{
	uint8_t		dim;
	uint8_t		type;
	uint8_t		data[4];
} __attribute__((packed));

struct lasterr_date_t
{
	uint16_t	dim;
	uint8_t		type;
	uint16_t	data;
} __attribute__((packed));

struct lasterr_t
{
	uint16_t	dim;
	uint16_t	type;
	uint8_t		data;
} __attribute__((packed));

struct temperature_t
{
	uint8_t		dim;
	uint8_t		type;
	uint8_t		data;
} __attribute__((packed));

struct telegram_record_bia_t 
{
	struct datetime_t 	  curtime;  	/* Текущее время прибора 4 байта, формат hex, значение вычисляется следующим образом: биты № 1..6 – минуты, 9...13 – часы, 17…21 – дни, 25…28 – месяцы, 22..24 и 29…32 – год. */
	struct bcd32_t		  value;	  	/* Текущее показание прибора, 4 байта, формат BCD, для получения показания прибора необходимо умножить это значение на множитель из таблицы А1. */
	struct bcd24_t		  optime;		/* Значение времени работы прибора в часах, 3 байта, формат BCD. */
	struct date_t		  date;			/* Расчетная дата прибора 2 байта, формат hex */
	struct bcd32_t		  dateval;		/* Показания прибора на расчетную дату, 4 байта, формат BCD (показания на расчетную дату), для получения показания прибора необходимо умножить это значение на множитель из таблицы А1. */
	struct lasterr_date_t lasterr_date; /* Дата информации  о последней ошибке прибора, 2 байта, формат hex */
	struct lasterr_t	  lasterr;		/* Информация  о последней ошибке прибора, 1 байта, формат hex, значения: 00h – ошибок не было, 02h – выход прибора учета, подключенного к данному каналу, находился в состоянии обрыва (для выходов типа NAMUR); 03h – выход прибора учета, подключенного к данному каналу, находился в состоянии КЗ (для выходов типа NAMUR); */
	uint32_t    		  serial;  		/* Серийный номер БИА */
} __attribute__((packed));

struct telegram_record_bsrt_t 
{
	struct bcd24_t		  value;		/* Текущее показание прибора, 3 байта, формат BCD. */
	struct date_t		  date;			/* Расчетная дата прибора 2 байта, формат hex */
	struct bcd24_t		  dateval;		/* Показания прибора на расчетную дату, 3 байта, формат BCD. */
	struct temperature_t  temperature;	/* Измеренная температура, в градусах, целое значение, 1 байт (unsigned char). */
	struct datetime_t 	  curtime;  	/* Текущее время прибора 4 байта, формат hex, значение вычисляется следующим образом: биты № 1..6 – минуты, 9...13 – часы, 17…21 – дни, 25…28 – месяцы, 22..24 и 29…32 – год. */
	struct bcd24_t		  optime;		/* Значение времени работы прибора в часах, 3 байта, формат BCD. */
	struct lasterr_date_t lasterr_date; /* Дата информации  о последней ошибке прибора, 2 байта, формат hex */
	struct lasterr_t	  lasterr;   	/* Информации  о последней ошибке прибора, 1 байта, формат hex; значения: 00h – ошибок не было, 01h – попытка демонтажа прибора */
	uint8_t     		  reserverd[3]; /* Три пустых байта, значение FFFFFFh. */
} __attribute__((packed));

struct telegram_data_t 
{
    struct telegram_data_common_t common;
    /* telegram payload; may be encrypted */
	union {
		struct  telegram_record_bia_t bia;
		struct  telegram_record_bsrt_t bsrt;
	} __attribute__((packed));
	/* end of payload */
} __attribute__((packed));

struct telegram_t 
{
    struct telegram_header_t hdr;
    struct telegram_data_t   data;
} __attribute__((packed));

/* Generic wrapper for telegram data */

struct report_rec_t 
{
    char         id[9];              // IDCounter: ID счётчика
    unsigned int type;               // CounterType: Тип счётчика (БИА, БСРТ, ТСУ и т.д.)
    int          rssi;               // RSSI: Уровень мощности принятого сигнала
    char         idpk[9];            // IDPK: ID этажного сетевого узла
    char         date[11];           // CounterDate: Штамп даты ЭСУ
    char         time[6];            // CounterTime: Штамп времени ЭСУ
    struct
    {
        char     date_in[11];        // CounterDateIn: Штамп даты СУ
        char     time_in[6];         // CounterTimeIn: Штамп времени СУ
        char     value[16];          // CounterData: Показания счётчика на дату и время
        char     *physical;          // CounterPhysical: Размерность показаний СУ
    } current,                       // На текущую дату
      report;                        // На рассчетную дату
    char         tmp_error_date[11]; // CounterTempDateError: Дата последней временной ошибки СУ
    unsigned int tmp_error_code;     // CounterTempErrorCode: Код последней временной ошибки СУ
    unsigned int fix_error_code;     // CounterFixErrorCode: Код постоянной ошибки СУ
    unsigned int optime;             // OperatingTime: Время работы прибора, часов
    char         note[129];          // Note: Комментарий
};

/* API functions */

int read_telegram(const char *name, struct report_rec_t *rec);

#endif /* TELEGRAM_H */
