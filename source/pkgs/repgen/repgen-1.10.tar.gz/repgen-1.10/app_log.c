/* Applcation logging functions  */

#include <unistd.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <stdarg.h>
#include <syslog.h>
#include <time.h>
#include <sys/stat.h>
#include <linux/limits.h>   /* for PATH_MAX      */
#include <bits/local_lim.h> /* for HOST_NAME_MAX */

#include <sys/types.h>

#include "app_log.h"

static int use_syslog = 0;
static FILE *log_file = NULL;
static char log_ident[64] = { 0 }; /* default - empty ident */
static int log_level = APP_INFO;

static int app2syslog[] = 
{
	[APP_ALWAYS]	= LOG_CRIT,
	[APP_ERR]	= LOG_ERR,
	[APP_WARN]	= LOG_NOTICE,
	[APP_INFO]	= LOG_INFO,
	[APP_DEBUG]	= LOG_DEBUG,
};

static inline int app2syslog_level(int level)
{
	if (level >= sizeof(app2syslog)/sizeof(int))
		return LOG_DEBUG;

	return app2syslog[level];
}

static int create_log_file(const char *path)
{
    int fd;
    unsigned int serial = 0;
    char hostname[HOST_NAME_MAX];
    char fname[PATH_MAX];
    int open_flags = O_WRONLY | O_CREAT | O_EXCL | O_APPEND;
    time_t curtime;
    struct tm *tm;

    if (gethostname(hostname, sizeof(hostname)) != 0)
    {
        strncpy(hostname, "unknown", sizeof(hostname));
    }

    time(&curtime);
    tm = localtime(&curtime);

    do
    {
        snprintf(fname, sizeof(fname), "%s/%04u-%02u-%02u-%s-%02u", path, 
                 tm->tm_year + 1900, 
                 tm->tm_mon + 1, 
                 tm->tm_mday,
                 hostname, serial);

        fd = open(fname, open_flags, S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH);
        if (fd == -1)
        {
            if (errno == EEXIST)
            {
                if (serial < 99)
                {
                    ++serial;
                } else
                {
                    open_flags &= ~O_EXCL;
                }
            } else
            {
                break;
            }
        }
    } while (fd < 0);

    return fd;
}

void app_log_set_level(int level)
{
	log_level = level;
}

int app_log_start(const char *path, const char *ident, const char *comment)
{
	use_syslog = 0;
	log_file = NULL;
	int fd;

	if (ident) {
		strncpy(log_ident, ident, sizeof(log_ident));
		log_ident[sizeof(log_ident) - 1] = '\0';
	} else {
		log_ident[0] = 0; /* empty */
	}

	if (path) {
		if (!strcmp(path, "syslog")) {
			use_syslog = 1;
			openlog(log_ident, 0, LOG_DAEMON);
		} else if (!strcmp(path, "stderr")) {
			// leave log_file empty, so stderr will be used
		} else {
			fd = create_log_file(path);
			if (fd < 0) {
			    return -1;
			}
			log_file = fdopen(fd, "a");
			if (log_file == NULL) {
				return -1;
			}
		}
	}

	log_info(comment);
	return 0;
}

void app_log_stop(const char *comment)
{
	log_info(comment);
	if (use_syslog) {
		closelog();
		use_syslog = 0;
	} else {
		if (log_file) {
			fclose(log_file);
			log_file = NULL;
		}
	}
}

static void vlog(int level, const char *format, va_list ap)
{
	if (use_syslog) {
		vsyslog(app2syslog_level(level), format, ap);
	} else {
		time_t t0;
		struct tm t;
		FILE *outfd;
		char timestr[32];

		outfd = log_file ? log_file : stderr;

		t0 = time(NULL);
		localtime_r(&t0, &t);
		/* 2012-03-25 14:31:55 */
		if (strftime(timestr, sizeof(timestr), "%Y-%m-%d %T", &t) == 0) {
			timestr[0] = '\0';
		}

		//fprintf(outfd, "%s %s<%01d>: ", timestr, log_ident, level);
		fprintf(outfd, "%s <%01d>: ", timestr, level);
		vfprintf(outfd, format, ap);
		fprintf(outfd, "\r\n");
		fflush(outfd);
	}
}

void app_log(int level, const char *format, ...)
{
	va_list ap;

	if (level > log_level) {
		return;
	}

	va_start(ap, format);
	vlog(level, format, ap);
	va_end(ap);
}

#define MAX_HEX_NUM_PER_STRING 16
void app_log_buffer(int level, const char *msg, unsigned char *buf, unsigned int length)
{
	char buf_hex[MAX_HEX_NUM_PER_STRING * 3 + 1]; // +1 for trailing 0
	int counter = 0;
	int i;
	int pos = 0;
	int msg_printed = 0;

	if (level > log_level) {
		return;
	}

	for (i = 0; i < length; i++) {
		pos = pos + sprintf(&buf_hex[pos], "%02X ", buf[i]);
		counter++;
		if (counter >= MAX_HEX_NUM_PER_STRING) {
			buf_hex[pos - 1] = 0;
			counter = 0;
			pos = 0;
			if (!msg_printed) {
				app_log(level, "%s: %s", msg, buf_hex);
				msg_printed = 1;
			} else {
				app_log(level, "%s", buf_hex);
			}
		}
	}
	if (pos) {
		buf_hex[pos - 1] = 0;
		if (!msg_printed) {
			app_log(level, "%s: %s", msg, buf_hex);
		} else {
			app_log(level, "%s", buf_hex);
		}
	}
}

