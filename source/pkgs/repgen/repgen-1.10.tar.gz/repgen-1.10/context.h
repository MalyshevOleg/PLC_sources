#ifndef CONTEXT_H
#define CONTEXT_H

#include <stdio.h>

struct context_t
{
    /* global parameters, unchanged during processing */
    char *cur_dir;          /* full path to current archive location               */
    char *mon_dir;          /* full path to monthly archive location               */
    FILE *output;           /* output file structure                               */
    int count;              /* number of IDs processed                             */
    int month_count;        /* number of monthes processed by each ID              */
    int monthly;            /* nonzero if monthly report, zero for current report  */
    /* local parameters, controls processing */
    int do_monthly;         /* nonzero if currently month archive is processed     */
    int processed;          /* nonzero if at least one archive is processed        */
    int fatal_error;        /* nonzero if any fatal error occured during process  */
    int last_month;         /* last year*12 + month processed */
};

int context_init(int argc, char *argv[], struct context_t *ctx);

void context_done(struct context_t *ctx);

#endif /* CONTEXT_H */
