#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>

#include "browser.h"

char *mkpath(const char *base, const char *file)
{
    /* 1 additional char for directory separator and 1 char for terminating zero */
    char *dest = malloc(strlen(base) + strlen(file) + 2 * sizeof(char));
    // TODO: handle out of memory error as fatal error (jump to exit)
    if (dest)
    {
        strcpy(dest, base);
        strcat(dest, "/");
        strcat(dest, file);
    }
    return dest;
}

#if (__GLIBC__ >= 2) && (__GLIBC_MINOR__ >= 10)
static int reversed_alphasort(const struct dirent **a, 
                              const struct dirent **b)
#else
static int reversed_alphasort(const void *a, 
                              const void *b)
#endif
{
    return -alphasort(a, b);
}

int parsedir(const char *path,
             int reversed,
             int (*filter)(const struct dirent *), 
             int (*callback)(const char *, const char *, void *), 
             void *arg)
{
    struct dirent **namelist;
    int entries;
    int i;
    char *full_path;
    char call_back = 1;

    entries = scandir(path, &namelist, filter, 
                      reversed ? reversed_alphasort : alphasort);

    if (entries == -1)
    {
        return -1;
    }

    for (i=0; i<entries; ++i) 
    {
        if (call_back)
        {
            full_path = mkpath(path, namelist[i]->d_name);
            if (full_path)
            {
                call_back = callback(namelist[i]->d_name, full_path, arg);
                free(full_path);
            }
        }
        free(namelist[i]);
    }
    free(namelist);

    return 0;
}
