#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <arpa/inet.h>    /* for ntohs() */
#include <errno.h>
#include <stdarg.h>

#include "app_log.h"
#include "msg_strings.h"
#include "telegram.h"

#define ARRAY_SIZE(x)    (sizeof(x)/sizeof(*(x)))

#define STATIC_ASSERT(e) ((void)sizeof(char[1 - 2*!(e)]))

#define DECIMAL_POINT   ","

#define ID_TYPE         0x44
#define ID_VENDOR       0x3EEE
#define ID_HDR          0x7A
#define ID_CRYPTO       0x2F2F

static const char REPORT_TIME[] = "23:59";

enum
{
    typeBSRT,
    typeBIA
};

/* Common parsing helpers */

static inline void strzero(char *s)
{
        *s = '\0';
}

static inline uint32_t bits(uint32_t value, int high, int low)
{
    return (value >> low) & ((1 << (high - low + 1)) - 1);
}

static inline int bcd8_to_uint(uint8_t data, unsigned int *result)
{
    unsigned int a, b;

    a = bits(data, 7, 4);
    b = bits(data, 3, 0);
    if (a > 9 || b > 9)
    {
        return 1;
    }
    *result = 10*a + b;

    return 0;
}

#if 0
static int bcd_to_str(const uint8_t *data, size_t length, char *str, size_t str_size)
{
    unsigned int n;
    int ret;

    while (length--) /* step backwards */
    {
            if (bcd8_to_uint(data[length], &n) != 0)
            {
                    return 1;
            }

            ret = snprintf(str, str_size, "%02u", n);
            if (ret > str_size)
            {
                    return 1;
            }
            str      += ret;
            str_size -= ret;
    }

    return 0;
}
#endif

static int bcd_to_uint(const uint8_t *data, size_t length, uint32_t *result)
{
    unsigned int n;

    *result = 0;
    while (length--) /* step backwards */
    {
        if (bcd8_to_uint(data[length], &n) != 0)
        {
                return 1;
        }
        *result *= 100;
        *result += n;
    }

    return 0;
}

static int optime_to_uint(const struct bcd24_t *value, unsigned int *result)
{
    if (value->dim  != 0x0B ||
            value->type != 0x26)
    {
            *result = 0;
            return 1;
    }

    if (bcd_to_uint(value->data, sizeof(value->data), result) != 0)
    {
            return 1;
    }

    return 0;
}

static int datetime_to_str(const struct datetime_t *datetime,
                           char *date, size_t date_size,
                           char *time, size_t time_size)
{
    unsigned int year, mon, day, hour, min;

    strzero(date);
    strzero(time);

    if (datetime->dim  != 0x04 || datetime->type != 0x6D)
    {
        return 1;
    }

    min  = bits(datetime->data,   5,  0);
    hour = bits(datetime->data,  12,  8);
    day  = bits(datetime->data,  20, 16);
    mon  = bits(datetime->data,  27, 24);
    year = (bits(datetime->data, 23, 21) |
           (bits(datetime->data, 31, 28) << 3)) + 2000;

    if (min > 59 || hour > 23 || day > 31 || mon > 12)
    {
        return 1;
    }

    if ((snprintf(date, date_size, "%02u.%02u.%04u", day, mon, year) > date_size) ||
        (snprintf(time, time_size, "%02u:%02u", hour, min) > time_size))
    {
        return 1;
    }

    return 0;
}

/* date[] size must be at least 11 chars */
static int date_to_str(uint16_t value, char *date, size_t date_size)
{
    unsigned int year, mon, day;

    day  = bits(value,  4,  0);
    mon  = bits(value, 11,  8);
    year = (bits(value, 7,  5) | (bits(value, 14, 12) << 3)) + 2000;

    if (day > 31 || mon > 12)
    {
        return 1;
    }

    if (snprintf(date, date_size, "%02u.%02u.%04u", day, mon, year) > date_size)
    {
        return 1;
    }

    return 0;
}

static int report_date_to_str(const struct date_t *report_date, char *date, size_t date_size)
{
    strzero(date);
    
    if (report_date->dim != 0x42 || report_date->type != 0x6C)
    {
        return 1;
    }
    
    return date_to_str(report_date->data, date, date_size);
}

static int lasterr_date_to_str(const struct lasterr_date_t *lasterr_date, char *date, size_t date_size)
{
    strzero(date);

    if (lasterr_date->dim != 0x8201 || lasterr_date->type != 0x6C)
    {
        return 1;
    }

    return date_to_str(lasterr_date->data, date, date_size);
}

static int lasterr_to_uint(const struct lasterr_t *lasterr, unsigned int *result)
{
    if (lasterr->dim != 0x8101 || lasterr->type != 0xFD17)
    {
            *result = 0;
            return 1;
    }

    *result = lasterr->data;

    return 0;
}

/* BSRT-specific helpers */
static int bsrt_value_to_str(const struct bcd24_t *value, unsigned int id_dim, char *str, size_t str_size)
{
    strzero(str);
    unsigned int n;

    if (value->dim != id_dim || value->type != 0x6E)
    {
        return 1;
    }

    if (bcd_to_uint(value->data, sizeof(value->data), &n) != 0)
    {
        return 1;
    }

    if (snprintf(str, str_size, "%u", n) > str_size)
    {
        return 1;
    }

    return 0;
}

static void __attribute__((format(printf, 5, 6)))
append_note(const char *id, char **note, size_t *space, int *nonempty, const char *fmt, ...)
{
    int ret;
    va_list ap;

    if (*nonempty)
    {
        ret = snprintf(*note, *space, "; ");
        if (ret <= *space)
        {
                *space -= ret;
                *note  += ret;
        } else
        {
                log_err(msg_note_overflow, id);
                return;
        }

    } else
    {
        *nonempty = 1;
    }

    va_start(ap, fmt);

    ret = vsnprintf(*note, *space, fmt, ap);
    if (ret <= *space)
    {
        *space -= ret;
        *note  += ret;
    } else
    {
        log_err(msg_note_overflow, id);
    }

    va_end(ap);
}

/* BRST parser */
static int parse_bsrt(const struct telegram_record_bsrt_t *bsrt, struct report_rec_t *rec)
{
    size_t note_space = ARRAY_SIZE(rec->note);
    char *note = rec->note;
    int nonempty = 0;

    strzero(rec->note);

    /* Текущее показание прибора */
    if (bsrt_value_to_str(&bsrt->value, 0x0B, rec->current.value, ARRAY_SIZE(rec->current.value)) != 0)
    {
        append_note(rec->id, &note, &note_space, &nonempty, msg_invalid_field, msg_field_value);
    }
    rec->current.physical = "HCA unit";

    /* Рассчетная дата */
    if (report_date_to_str(&bsrt->date, rec->report.date_in, ARRAY_SIZE(rec->report.date_in)) != 0)
    {
        append_note(rec->id, &note, &note_space, &nonempty, msg_invalid_field, msg_field_date);
    }
    strncpy(rec->report.time_in, REPORT_TIME, sizeof(REPORT_TIME));
    strzero(rec->report.time_in + sizeof(REPORT_TIME));

    /* Показания на расчетную дату */
    if (bsrt_value_to_str(&bsrt->dateval, 0x4B, rec->report.value, ARRAY_SIZE(rec->report.value)) != 0)
    {
        append_note(rec->id, &note, &note_space, &nonempty, msg_invalid_field, msg_field_dateval);
    }
    rec->report.physical = rec->current.physical;

    /* Текущее время */
    if (datetime_to_str(&bsrt->curtime, rec->current.date_in, ARRAY_SIZE(rec->current.date_in), 
                                        rec->current.time_in, ARRAY_SIZE(rec->current.time_in)) != 0)
    {
        append_note(rec->id, &note, &note_space, &nonempty, msg_invalid_field, msg_field_curtime);
    }

    /* Дата информации о последней ошибке прибора */
    if (lasterr_date_to_str(&bsrt->lasterr_date, rec->tmp_error_date, ARRAY_SIZE(rec->tmp_error_date)) != 0)
    {
        append_note(rec->id, &note, &note_space, &nonempty, msg_invalid_field, msg_field_lasterr);
    }

    /* Информация о последней ошибке прибора */
    if (lasterr_to_uint(&bsrt->lasterr, &rec->tmp_error_code) != 0)
    {
        append_note(rec->id, &note, &note_space, &nonempty, msg_invalid_field, msg_field_lasterr_date);
    }

    /* Don't display date if no temporary error occured */
    if (rec->tmp_error_code == 0)
    {
        strzero(rec->tmp_error_date);
    }

    /* Значение времени работы прибора */
    if (optime_to_uint(&bsrt->optime, &rec->optime) != 0)
    {
        append_note(rec->id, &note, &note_space, &nonempty, msg_invalid_field, msg_field_optime);
    }

    return 0;
}

/* BIA-related helpers */

static int bia_dimension(uint8_t dim, int *exp, char **quantity)
{
        /* dimension and quantity identification */
    static const struct
    {
        uint8_t      mask;      /* mask for dimension             */
        uint8_t      bits;      /* value for dimenstion signature */
        unsigned int exp;       /* factor value                   */
        char        *name;      /* name of quantity               */
    } qid[] = 
    {
        { .mask = 0xF8, .bits = 0x00, .exp = -3, .name = "Wh"    },
        { .mask = 0xF8, .bits = 0x08, .exp =  0, .name = "kal"   },
        { .mask = 0xF8, .bits = 0x10, .exp = -6, .name = "m^3"   },
        { .mask = 0xF8, .bits = 0x28, .exp = -3, .name = "W"     },
        { .mask = 0xF8, .bits = 0x30, .exp =  0, .name = "kal/h" },
        { .mask = 0xFC, .bits = 0x58, .exp = -3, .name = "°C"    },
        { .mask = 0xFC, .bits = 0x5C, .exp = -3, .name = "°C"    },
        { .mask = 0xFC, .bits = 0x64, .exp = -3, .name = "°C"    }
    };
    int i;

    for (i = 0; i < ARRAY_SIZE(qid); ++i)
    {
        if ((dim & qid[i].mask) == qid[i].bits)
        {
            *exp = (dim & ~qid[i].mask) + qid[i].exp;
            *quantity = qid[i].name;
            return 0;
        }
    }
    *quantity = "unknown";

    return 1;
}

static int bia_value_to_str(const struct bcd32_t *data,
                            unsigned int id_dim,
                            char *str, size_t str_size,
                            char **quantity)
{
    char svalue[9];
    unsigned int value;
    int exp = 0;
    int len;
    int ret;
    int zerocnt;
    char *p;

    strzero(str);

    /* Текущее показание прибора */
    if (data->dim != id_dim || bia_dimension(data->type, &exp, quantity) != 0)
    {
        return 1;
    }

    if (bcd_to_uint(data->data, ARRAY_SIZE(data->data), &value) != 0)
    {
        return 1;
    }

    if (value == 0)
    {
        ret = snprintf(str, str_size, "%u", value);
        if (ret > str_size)
        {
                return 1;
        }
        return 0;
    }

    len = snprintf(svalue, sizeof(svalue), "%u", value);
    if (len > sizeof(svalue))
    {
        return 1;
    }

    /* not optimal but it works */
    /* TODO: implement range checking */
    if (exp < 0)        /* shift decimal point left */
    {
        exp = -exp;
        if (exp < len)  /* no leading zeroes is required */
        {
            strncpy(str, svalue, len - exp);
            strzero(str + len - exp);
            /* count tailing zeroes */
            zerocnt = 0;
            for (p = svalue + len - 1; *p == '0' && p > svalue; --p)
            {
                ++zerocnt;
            }
            if (exp > zerocnt)
            {
                strcat(str, DECIMAL_POINT);
                strncat(str, &svalue[len - exp], exp - zerocnt);
            }
        } else          /* append leading zeroes */
        {
            strcpy(str, "0"DECIMAL_POINT);
            while (exp-- > len)
            {
                strcat(str, "0");
            }
            strcat(str, svalue);
        }
    } else              /* shift decimal point right */
    {
        strcpy(str, svalue);
        while (exp--)
        {
            strcat(str, "0");
        }
    }  

    return 0;
}

static void append_note_separator(const char *id, char **note, size_t *space, int nonempty)
{
    int ret;

    if (!nonempty)
    {
        ret = snprintf(*note, *space, " - ");
        if (ret <= *space)
        {
            *space -= ret;
            *note  += ret;
        } else
        {
            log_err(msg_note_overflow, id);
            return;
        }
    }
}

/* BIA-parser */

static int parse_bia(const struct telegram_record_bia_t *bia, struct report_rec_t *rec)
{
    size_t note_space = ARRAY_SIZE(rec->note);
    char *note = rec->note;
    int ret;
    int nonempty = 0;

    ret = snprintf(rec->note, note_space, "%08X", bia->serial);
    if (ret > note_space)
    {
        log_err(msg_note_overflow, rec->id);
        note_space = 0;
    } else
    {
        note_space -= ret;
        note += ret;
    }

    /* Текущее время */
    if (datetime_to_str(&bia->curtime,
                        rec->current.date_in, ARRAY_SIZE(rec->current.date_in),
                        rec->current.time_in, ARRAY_SIZE(rec->current.time_in)) != 0)
    {
        append_note_separator(rec->id, &note, &note_space, nonempty);
        append_note(rec->id, &note, &note_space, &nonempty, msg_invalid_field, msg_field_curtime);
    }

    /* Текущее показание прибора */
    if (bia_value_to_str(&bia->value, 0x0C, rec->current.value, ARRAY_SIZE(rec->current.value), &rec->current.physical) != 0)
    {
        append_note_separator(rec->id, &note, &note_space, nonempty);
        append_note(rec->id, &note, &note_space, &nonempty, msg_invalid_field, msg_field_value);
    }

    /* Значение времени работы прибора */
    if (optime_to_uint(&bia->optime, &rec->optime) != 0)
    {
        append_note_separator(rec->id, &note, &note_space, nonempty);
        append_note(rec->id, &note, &note_space, &nonempty, msg_invalid_field, msg_field_optime);
    }

    /* Рассчетная дата */
    if (report_date_to_str(&bia->date, rec->report.date_in, ARRAY_SIZE(rec->report.date_in)) != 0)
    {
        append_note(rec->id, &note, &note_space, &nonempty, msg_invalid_field, msg_field_date);
    }
    strncpy(rec->report.time_in, REPORT_TIME, sizeof(REPORT_TIME));
    strzero(rec->report.time_in + sizeof(REPORT_TIME));

    /* Показания на расчетную дату */
    if (bia_value_to_str(&bia->dateval, 0x4C, rec->report.value, ARRAY_SIZE(rec->report.value), &rec->report.physical) != 0)
    {
        append_note_separator(rec->id, &note, &note_space, nonempty);
        append_note(rec->id, &note, &note_space, &nonempty, msg_invalid_field, msg_field_dateval);
    }

    /* Дата информации о последней ошибке прибора */
    if (lasterr_date_to_str(&bia->lasterr_date, rec->tmp_error_date, ARRAY_SIZE(rec->tmp_error_date)) != 0)
    {
        append_note_separator(rec->id, &note, &note_space, nonempty);
        append_note(rec->id, &note, &note_space, &nonempty, msg_invalid_field, msg_field_lasterr);
    }

    /* Информация о последней ошибке прибора */
    if (lasterr_to_uint(&bia->lasterr, &rec->tmp_error_code) != 0)
    {
        append_note_separator(rec->id, &note, &note_space, nonempty);
        append_note(rec->id, &note, &note_space, &nonempty, msg_invalid_field, msg_field_lasterr_date);
    }

    /* Don't display date if no temporary error occured */
    if (rec->tmp_error_code == 0)
    {
        strzero(rec->tmp_error_date);
    }

    return 0;
}

static int parse_telegram(const struct telegram_t *telegram, int type, struct report_rec_t *rec)
{
    if (telegram->data.common.hdr_id        != ID_HDR     ||
        telegram->data.common.encrypt_sign  != 0          ||
        telegram->data.common.encrypt_token != ID_CRYPTO)
    {
        return 1;
    }

    snprintf(rec->id, sizeof(rec->id), "%08X", telegram->hdr.serial);

    rec->rssi = (int16_t)ntohs(telegram->hdr.rssi);
    rec->type = telegram->hdr.phys;

    rec->fix_error_code = telegram->data.common.errcode;

    switch (type)
    {
        case typeBSRT:
                return parse_bsrt(&telegram->data.bsrt, rec);

        case typeBIA:
                return parse_bia(&telegram->data.bia, rec);

        default:
                return 1;
    }

    return 0;
}

/*
 * read_telegram_file() reads telegram data from file and fills type field;
 */
static int read_telegram_file(const char *name, struct telegram_t *telegram, int *type)
{
    int fd;
    int ret;
    size_t data_len;
    int retval = -1;

    fd = open(name, O_RDONLY);
    if (fd == -1)
    {
        return -1;
    }

    ret = read(fd, &telegram->hdr, sizeof(telegram->hdr));
    if (ret == -1)
    {
        goto read_failed;
    }

    if (ret != sizeof(telegram->hdr))
    {
        errno = EILSEQ; /* ? */
        goto read_failed;
    }

    if (telegram->hdr.type       != ID_TYPE ||
        telegram->hdr.vendor != ID_VENDOR)
    {
        errno = EILSEQ; /* ? */
        goto read_failed;
    }

    if (telegram->hdr.phys == 0x08)
    {
        *type = typeBSRT;
        data_len = sizeof(telegram->data.bsrt);
    } else if (telegram->hdr.phys >= 0x01 && telegram->hdr.phys <= 0x09)
    {
        *type = typeBIA;
        data_len = sizeof(telegram->data.bia);
    }
    else
    {
        errno = EILSEQ; /* ? */
        goto read_failed;
    }

    if (telegram->hdr.length != sizeof(telegram->hdr)
                                - sizeof(telegram->hdr.rssi)
                                - sizeof(telegram->hdr.length)
                                + sizeof(telegram->data.common)
                                + data_len)
    {
        errno = EILSEQ; /* ? */
        goto read_failed;
    }

    ret = read(fd, &telegram->data, sizeof(telegram->data.common) + data_len);
    if (ret == -1)
    {
        goto read_failed;
    }

    if (ret != sizeof(telegram->data.common) + data_len)
    {
        errno = EILSEQ; /* ? */
        goto read_failed;
    }

    retval = 0;

read_failed:
    close(fd);

    return retval;
}

int read_telegram(const char *name, struct report_rec_t *rec)
{
    struct telegram_t telegram;
    int type;

    if (read_telegram_file(name, &telegram, &type) != 0)
    {
                return 1;
    }
    if (parse_telegram(&telegram, type, rec) != 0)
    {
        errno = EILSEQ;
        return 1;
    }

    return 0;
}
