#ifndef _APP_LOG_H_
#define _APP_LOG_H_

#define APP_ALWAYS	0	/* info to be logged in any case */
#define APP_ERR		1	/* error condition: fatal (program abort) or not */
#define APP_WARN	2	/* abnormal/unexpected condition */
#define APP_INFO	3	/* normal log messages */
#define APP_DEBUG	4	/* debug log messages */
#define APP_ALWAYS	0	// info to be logged in any case (like fatal level)

/** Set log level (default: LOG_INFO)
 * @param level - new level
 * If specified level is greater than max.possible then max. possible one is set.
 * Note: log level can be set before log initialization and after log de-initialization
 */
extern void app_log_set_level(int level);

/** Init and start logging to other place than stderr
 * @param path - path name of the log-file
 * @param ident - string - identification of the app, e.g. app name
 * @param comment - log this comment first
 * @return 0 - success, < 0 - error
 *
 * @note If applog_start was not called than app_log prints to stderr
 */
extern int app_log_start(const char *path, const char *ident, const char *comment);

/** Stop and cleanup logging (close file, etc.)
 * @param comment - log this comment last before closing the log
 */
extern void app_log_stop(const char *comment);

/** Write a message to the log
 * @todo: describe
 */
extern void app_log(int level, const char *format, ...);

/** Write a binary buffer contents into the log
 * @todo: describe
 */
extern void app_log_buffer(int level, const char *msg, unsigned char *buf, unsigned int length);

/* Marcoses for logging */
#define log_always(fmt, ...) \
	do {\
		app_log(APP_ALWAYS, fmt, ##__VA_ARGS__);\
	} while(0)

#define log_err(fmt, ...) \
	do {\
		app_log(APP_ERR, fmt, ##__VA_ARGS__);\
	} while(0)

#define log_warn(fmt, ...) \
	do {\
		app_log(APP_WARN, fmt, ##__VA_ARGS__);\
	} while(0)

#define log_info(fmt, ...) \
	do {\
		app_log(APP_INFO, fmt, ##__VA_ARGS__);\
	} while(0)

/* debug logging stuff */
#ifdef DEBUG
#define log_debug(fmt, ...) \
	do {\
		app_log(APP_DEBUG, "%s,%d,%s(): " fmt, \
				__FILE__, __LINE__, __FUNCTION__, ##__VA_ARGS__); \
	} while(0)

#define log_debug_buf(msg, buf, len) \
	do {\
		app_log_buffer(APP_DEBUG, msg, buf, len); \
	} while(0)

#else
#define log_debug(fmt, ...) \
	do { } while (0)

#define log_debug_buf(msg, buf, len) \
	do { } while (0)
#endif

#endif /*_APP_LOG_H_*/
