#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <stdio.h>
#include <errno.h>

#include "locks.h"

static int do_lock_file(const char *name, int operation, struct lock_t *lock)
{
    int fd;
    int len;
    char pid[16];

    fd = open(name, O_RDWR | O_CREAT, S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH);
    if (fd == -1)
    {
        return -1;
    }

    if (lockf(fd, operation, 0) == -1)
    {
        return (errno == EACCES || errno == EAGAIN) ? 1 : -1;
    }

    len = snprintf(pid, sizeof(pid), "%u\n", getpid());

    write(fd, pid, len);

    ftruncate(fd, len);

    if (lock)
    {
        lock->fd = fd;
    }

    return 0;
}

int lock_file(const char *name, struct lock_t *lock)
{
    return do_lock_file(name, F_LOCK, lock);
}

int trylock_file(const char *name, struct lock_t *lock)
{
    return do_lock_file(name, F_TLOCK, lock);
}

int unlock_file(const struct lock_t *lock)
{
    ftruncate(lock->fd, 0);
    lockf(lock->fd, F_ULOCK, 0);
    close(lock->fd);

    return 0;
}
