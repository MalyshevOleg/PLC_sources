#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>

#include "browser.h"
#include "filters.h"
#include "telegram.h"
#include "context.h"
#include "app_log.h"
#include "msg_strings.h"
#include "config.h"

static void report_line(FILE *f, struct report_rec_t *rec, int current)
{
    int ret;

    ret = fprintf(f, 
               "\"%s\";"        // IDCounter
               "%02u;"          // CounterType
               "%i;"            // RSSI
               "\"%s\";"        // IDPK
               "%s;"            // CounterDate
               "%s;"            // CounterTime
               "%s;"            // CounterDateIn
               "%s;"            // CounterTimeIn
               "%s;"            // CounterData
               "\"%s\";"        // CounterPhysical
               "%s;"            // CounterTempErrorDate
               "%02u;"          // CounterTempErrorCode
               "%02u;"          // CounterFixErrorCode
               "%05u;"          // OperatingTime
               "\"%s\""         // Note
               "\n",
               rec->id, 
               rec->type,
               rec->rssi, 
               rec->idpk, 
               rec->date, 
               rec->time,
               current ? rec->current.date_in  : rec->report.date_in,
               current ? rec->current.time_in  : rec->report.time_in,
               current ? rec->current.value    : rec->report.value,
               current ? rec->current.physical : rec->report.physical,
               rec->tmp_error_date,
               rec->tmp_error_code,
               rec->fix_error_code,
               rec->optime,
               rec->note
           );

    if (ret < 0)
    {
        log_err(msg_report_write_failed);
    }
}

static int file_callback(const char *name, const char *path, void *arg)
{
    struct context_t *ctx = arg;
    struct report_rec_t rec;
    char id[9], idpk[9];
    unsigned int year, month, day, hour, min;

    if (sscanf(name, "%8s-%4u-%2u-%2u-%2u-%2u-%8s",
        id, &year, &month, &day, &hour, &min, idpk) != 7)     /* number of fields */
    {
        log_warn(msg_invalid_archive_file_name, name);
        return 1;
    }

    /* skip files for month already processed */
    if (ctx->do_monthly && ctx->last_month == year*12 + (month-1))
    {
        return 1;
    }

    strncpy(rec.idpk, idpk, sizeof(rec.idpk));
    snprintf(rec.date, sizeof(rec.date), "%02u.%02u.%04u", day, month, year);
    snprintf(rec.time, sizeof(rec.time), "%02u:%02u", hour, min);

    if (read_telegram(path, &rec) != 0)
    {
        log_err(msg_archive_read_failed, path,
                errno == EILSEQ ? msg_invalid_archive_format : strerror(errno));
        return 1;
    }

    if (strcmp(rec.id, id) != 0)
    {
        log_err(msg_invalid_archive_name, id, rec.id);
        return 1;
    }

    /* include measured value for current date */
    report_line(ctx->output, &rec, 1);

    /* current archive also should be processed for monthly report: 
       include measured value for report date */
    if (ctx->monthly && !ctx->do_monthly)
    {
        report_line(ctx->output, &rec, 0);
    }

    ctx->processed = 1;

    if (ctx->do_monthly)
    {
        /* monthly archive is processed: limit with 18 monthes (records) */
        ctx->last_month = year*12 + (month-1);
        ++ctx->month_count;
        return ctx->month_count < MAX_MONTH_DEEP;
    } else
    {
        /* current archive is processed: limit with 1 record */
        return 0;
    }
}

static int check_dir_name(const char *name)
{
    const char *p;

    p = name;
    do {
        if (*p < '0' || *p > '9')
        {
            return 1;
        }
    } while (* ++p);

    return 0;
}

static int dir_callback(const char *name, const char *path, void *arg)
{
    struct context_t *ctx = arg;
    char *mon_path;

    /* skip hidden directories */
    if (name[0] == '.')
    {
        return 1;
    }

    if (check_dir_name(name))
    {
        log_warn(msg_invalid_archive_directory_name, name);
        return 1;
    }

    if (ctx->monthly)
    {
        ctx->month_count = 0;
    }

    ctx->processed = 0;
    /* process current archive in both cases */
    ctx->do_monthly = 0;

    if (parsedir(path, 1, file_filter, file_callback, ctx) != 0)
    {
        log_warn(msg_current_archive_read_failed, name, strerror(errno));
    }

    if (!ctx->processed)
    {
        log_warn(msg_no_current_archives, name);
        return 1;
    }

    /* process monthly archive for monthly report only */
    if (ctx->monthly)
    {
        ctx->do_monthly = 1;
        ctx->last_month = 0;
        mon_path = mkpath(ctx->mon_dir, name);

        if (mon_path)
        {
            if (parsedir(mon_path, 1, file_filter, file_callback, ctx) != 0)
            {
                log_warn(msg_monthly_archive_read_failed, name, strerror(errno));
            }
        }

        free(mon_path);
    }

    ++ctx->count;

    return ctx->count < MAX_RECORDS; /* don't process more than 3000 IDs */
}


int main(int argc, char *argv[])
{
    int ret = 0;
    struct context_t ctx;

    if (context_init(argc, argv, &ctx) != 0)
    {
        return 1;
    }

    if (parsedir(ctx.cur_dir, 0, dir_filter, dir_callback, &ctx) != 0)
    {
        log_warn(msg_parse_current_dir_failed, ctx.cur_dir, strerror(errno));
        ctx.fatal_error = 1;
        ret = 1;
    }

    log_info(ctx.fatal_error ? msg_report_complete_with_errors : msg_report_complete_successfull,
             ctx.monthly ? msg_monthly_name : msg_current_name);

    context_done(&ctx);

    return ret;
}
