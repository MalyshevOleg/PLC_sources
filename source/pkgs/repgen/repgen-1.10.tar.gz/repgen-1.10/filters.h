#ifndef FILTERS_H
#define FILTERS_H

#include <dirent.h>

/* 
 * dir_filter() 
 * returns nonzero for directories named as /^[0-9]+$/
 * returns zero otherwise
 */
int dir_filter(const struct dirent *dir);

/* 
 * file_filter() 
 *  returns nonzero for regular files
 *  returns zero otherwise
 */
int file_filter(const struct dirent *dir);

#endif /* FILTERS_H */
