#ifndef CONFIG_H
#define CONFIG_H

#define APP_NAME "repgen"
#define APP_VERSION "0.2.1"

#define LOCK_SELF_MONTHLY_FILE   "/var/lock/repgen_monthly.lock"
#define LOCK_SELF_CURRENT_FILE   "/var/lock/repgen_current.lock"
#define LOCK_COMMON_FILE         "/var/lock/dk_common.lock"

#define CURRENT_DIRNAME "current"
#define MONTHLY_DIRNAME "monthly"

/* Max number of IDs to process */
#define MAX_RECORDS     3000

/* Max number of monthes to process */
#define MAX_MONTH_DEEP  18

#endif /* CONFIG_H */
