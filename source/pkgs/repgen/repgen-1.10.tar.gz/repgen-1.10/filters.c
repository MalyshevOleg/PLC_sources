#include "filters.h"

int dir_filter(const struct dirent *dir) 
{
    return (dir->d_type == DT_DIR);
}

int file_filter(const struct dirent *dir)
{
    return (dir->d_type == DT_REG);
}
