#ifndef BROWSER_H
#define BROWSER_H

#include <dirent.h>

/*
 * Arguments:
 *  path:     path to be processed
 *  reversed: nonzero to process entries in reversed alphabetical order, zero otherwise;
 *  filter:   function to be passed as filter to scandir(3);
 *  callback: function to be called per each entry. first argument of callback()
 *      is basename of entry, second argument is full path including basename.
 *      callback() should return zero value to stop processing.
 *
 * Return value: 
 *  0 on success;
 *  -1 on error, errno indicates error code.
 */
int parsedir(const char *path, 
             int reversed,
             int (*filter)(const struct dirent *), 
             int (*callback)(const char *, const char *, void *), 
             void *arg);

/* 
 * mkpath concatenates `base' `file' strings and returns result as malloc()ed 
 * buffer
 */
char *mkpath(const char *base, const char *file);

#endif /* BROWSER_H */
