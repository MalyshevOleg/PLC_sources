#include <unistd.h>
#include <stdlib.h>
#include <libgen.h>
#include <string.h>
#include <errno.h>

#include "locks.h"
#include "browser.h"
#include "app_log.h"
#include "msg_strings.h"
#include "config.h"
#include "context.h"

struct options_t
{
    char *path;
    char *output_file;
    char *log_dir;
    int   monthly;
};

static void usage(char *progname)
{
    fprintf(stderr, "Usage: %s [ -c | -m ] [ -o file ] [ -l file ] <directory>\n",
            progname > 0 ? basename(progname) : "program");
}

static int parse_options(int argc, char *argv[], struct options_t *options)
{
    int opt;

    options->monthly = -1;

    while ((opt = getopt(argc, argv, "cmo:l:h")) != -1)
    {
        switch (opt)
        {
            case 'c':
            case 'm':
                if (options->monthly == -1)
                {
                    options->monthly = (opt == 'm');
                } else
                {
                    fprintf(stderr, "Options 'c' and 'm' are mutually exclusive\n");
                    usage(argv[0]);
                    return 1;
                }
                break;

            case 'o':
                options->output_file = optarg;
                break;

            case 'l':
                options->log_dir = optarg;
                break;

            default:
                usage(argv[0]);
                return 1;
        }
    }

    if (optind < argc)
    {
        options->path = argv[optind];
        ++optind;
    } else
    {
        fprintf(stderr, "Archive directory is not specified\n");
        usage(argv[0]);
        return 1;
    }

    while (optind < argc)
    {
        fprintf(stderr, "Unexpected option: '%s': ignored\n", argv[optind]);
        ++optind;
    }

    return 0;
}

static int perform_locks(struct context_t *ctx)
{
    int ret;
    char *lock_self_file;

    lock_self_file = ctx->monthly ? LOCK_SELF_MONTHLY_FILE : LOCK_SELF_CURRENT_FILE;

    ret = trylock_file(lock_self_file, NULL);
    if (ret < 0)
    {
        log_err(msg_lock_failed, lock_self_file, strerror(errno));
        return 1;
    }
    if (ret > 0)
    {
        log_warn(msg_already_running);
        return 1;
    }
    if (lock_file(LOCK_COMMON_FILE, NULL))
    {
        log_err(msg_lock_failed, LOCK_COMMON_FILE, strerror(errno));
        return 1;
    }

    return 0;
}

int context_init(int argc, char *argv[], struct context_t *ctx)
{
    struct options_t options = 
    {
        .path = NULL,
        .output_file = NULL,
        .log_dir = NULL
    };

    if (parse_options(argc, argv, &options) != 0)
    {
        return 1;
    }

    if (app_log_start(options.log_dir, APP_NAME, msg_log_started))
    {
        fprintf(stderr, "Failed to init log in '%s': %s\n", options.log_dir, strerror(errno));
        return 1;
    }

    /* default is "current" archive */
    ctx->monthly = (options.monthly == -1) ? 0 : options.monthly;

    log_info(msg_app_name, ctx->monthly ? msg_monthly_name : msg_current_name, APP_VERSION);

    ctx->fatal_error = 0;

    /* preliminary check for directory availability (unreliable) */
    if (access(options.path, R_OK) != 0)
    {
        log_err(msg_err_readdir, options.path, strerror(errno));
        goto failed;
    }
    ctx->cur_dir = mkpath(options.path, CURRENT_DIRNAME);
    ctx->mon_dir = mkpath(options.path, MONTHLY_DIRNAME);
    ctx->count = 0;
    ctx->output = stdout;

    if (options.output_file)
    {
        ctx->output = fopen(options.output_file, "w");
    }
    if (ctx->output == NULL)
    {
        log_err(ctx->monthly ? msg_current_report_create_failed : 
                               msg_current_report_create_failed, 
                options.output_file, strerror(errno));
        goto failed;
    }

    if (perform_locks(ctx) != 0)
    {
        goto failed;
    }

    return 0;

failed:
	app_log_stop(msg_log_stopped);
	return 1;
}

void context_done(struct context_t *ctx)
{
    free(ctx->mon_dir);
    free(ctx->cur_dir);
    fclose(ctx->output);
	app_log_stop(msg_log_stopped);
}
