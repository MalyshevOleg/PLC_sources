#include <unistd.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <net/if.h>

#include <linux/can.h>
#include <linux/can/raw.h>

#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <stdlib.h>

#include "linux_list.h"

#include "version.h"
#include "log.h"
int log_level = LEVEL_INFO;

#define AF_CAN          29      		/* Controller Area Network      */
#define PF_CAN          AF_CAN

typedef struct {
	struct llist_head list;
	struct can_frame frame;
} frame_item_t;

typedef struct {
	const char *dev_name;
	
	struct {
		unsigned send: 		1;	/* send specified frames */
		unsigned set_loopback:	1;
		unsigned set_recvown:	1;
		
		/* internal cases */
		unsigned use_sendto:	1;	/* use sendto instead of write/send */
		unsigned use_recvfrom:	1;	/* use recvfrom instead of read/recv */
		unsigned use_write:	1;	/* write instead of send (bind first in any case) */
		unsigned use_read:	1;	/* read instead of recv */
	} flags;
	
	int recv_mode;				/* receive mode, -1 - do not receive */
	int loopback;
	int recvown;
	
	struct llist_head send_frames;  	/* frames to be sent */
//	struct llist_head recv_filters;
} config_t;
typedef struct {
	config_t cfg;
	
	int sock;				/* using one socket for send and listen */
	
	struct {
		unsigned bound:		1;	/* socket is already bound */
		unsigned sig_int:	1;	/* SIGINT/TERM caught */
	} flags;
	
	struct sockaddr_can addr;
} context_t;

context_t ctx = {
	.cfg = {
		.dev_name		= "can0",
		
		.flags = {
			.send		= 0,
			.set_loopback	= 0,
			.set_recvown	= 0,
			
			.use_sendto	= 1,
			.use_recvfrom	= 1,
			.use_write	= 0,
			.use_read	= 1,
		},
		
		.recv_mode		= -1,
	},
	
	.sock			= -1,
	.flags = {
		.bound		= 0,
		.sig_int	= 0,
	},
	
	.addr = {
		.can_family	= AF_CAN,
		.can_ifindex	= -1,
	},
};

static void usage()
{
	printf(
	APP_NAME " (" APP_VERSION "): run tests for raw CAN protocol.\n"
	"Usage:\n"
	"   " APP_NAME " [-h] [-v] [-s frdef] [-r mode] [-o opt] [-d dev]\n"
	"\n"
	"   -h                   print this screen and exit\n"
	"   -v x N               increase verbosity level (e.g. -v -v is verbosity level +2)\n"
	"   -s frdef x N         specify a frame to be sent in quotes: \n"
	"                        'S/E III/IIIIIIII L DD DD DD.. DD', where\n"
	"                            S/E          - standard 11 bit ID or extended 29 bit ID\n"
	"                            III/IIIIIIII - 3/8 hex digits specifying CAN-ID,\n"
	"                            L            - 1 digit 0..8 - number of following data bytes\n"
	"                            DD            - 2 hex digits - specifying a DATA byte\n"
	"   -r mode              receive frames, where mode is:\n"
	"                            0   - print only received frames\n"
	"                            1   - print & echo received frames\n"
	"                            2   - print received frames & echo modified frames\n"
	"   -o opt x N           specify socket options:\n"
	"                            loopback=0|1  -> CAN_RAW_LOOPBACK=0|1(default)\n"
	"                            recvown=0|1  -> CAN_RAW_RECV_OWN_MSGS=0(default)|1\n"
#if 0
	"   -f fltdef x N        TODO:specify filters to be used when receive in quotes:\n"
	"                        ''\n"
#endif
	"   -d dev               specify can network device name to use (default: can0)\n"
	"\n"
	);
}

static int sprintf_can_frame_def(char *buf, struct can_frame *frame)
{
	int n;
	int i = 0;
	
	if (frame->can_id & CAN_EFF_FLAG) {
	    n = sprintf(buf, "E %08X %d",
			frame->can_id & CAN_EFF_MASK, frame->can_dlc);
	} else {
	    n = sprintf(buf, "S %03X %d",
			frame->can_id & CAN_SFF_MASK, frame->can_dlc);
	}

	if (frame->can_dlc) {
		for (i = 0; i < frame->can_dlc && i < 8; i++) {
			n += sprintf(&buf[n], " %02X", frame->data[i]);
		}
	}
	
	return n;
}

#ifdef DEBUG
static int sprintf_can_frame(char *buf, struct can_frame *frame)
{
	int n;
	int i = 0;
	
	if (frame->can_id & CAN_EFF_FLAG) {
	    n = sprintf(buf, "CAN-ID: 0x%08X (raw=0x%08X) DLC: %d DATA:",
			frame->can_id & CAN_EFF_MASK, frame->can_id, frame->can_dlc);
	} else {
	    n = sprintf(buf, "CAN-ID: 0x%03X (raw=0x%08X) DLC: %d DATA:",
			frame->can_id & CAN_SFF_MASK, frame->can_id, frame->can_dlc);
	}

	if (frame->can_dlc) {
		for (i = 0; i < frame->can_dlc && i < 8; i++) {
			n += sprintf(&buf[n], " %02X", frame->data[i]);
		}
	} else {
		n += sprintf(&buf[n], " -");
	}
	
	return n;
}
#endif

static int parse_can_frame_def(const char *frame_def, struct can_frame *frame)
{
	/* format: 
	   "E IIIIIIII L DD DD DD DD DD DD DD DD" - max str len is 12+8*3+1=37 bytes incl. 0
	   "S iii L DD DD DD DD DD DD DD DD" - max str len is 7+3*8+1=32 bytes incl. 0
	   count of DD equals to L value.
	 */
	char buf[40];
	char *ps, *pe;
	int i;
	int eff = 0;
	size_t len = strlen(frame_def);
	
	if (!len) {
		pr_err("empty frame definition\n");
		return -1;
	}

	strcpy(buf, frame_def);
	
	if (buf[0] != 'E' && buf[0] != 'S') {
		pr_err("E or S expected\n");
		return -1;
	}
	eff = buf[0] == 'E';
	
	if (eff) {
		if (len > 36) {
			pr_err("invalid definition length, max for EFF is 36\n");
			return -1;
		}
	} else {
		if (len > 31) {
			pr_err("invalid definition length, max for SFF is 31\n");
			return -1;
		}
	}
	if (buf[1] != ' ') {
		pr_err("whitespace expected after frame type\n");
		return -1;
	}

	ps = &buf[2];
	frame->can_id = strtol(ps, &pe, 16);
	if ((eff && pe - ps != 8) || (!eff && pe - ps != 3)) {
		pr_err("invalid CAN-ID length, should be %d hex digits for %s\n",
			eff ? 8 : 3, eff ? "EFF" : "SFF");
		return -1;
	}
	if (eff) {
		frame->can_id &= CAN_EFF_MASK;
		frame->can_id |= CAN_EFF_FLAG;
	} else {
		frame->can_id &= CAN_SFF_MASK;
	}
	
	if (*pe != ' ') {
		pr_err("a whitespace is expected after CAN-ID\n");
		return -1;
	}
	ps = pe + 1;
	
	frame->can_dlc = strtol(ps, &pe, 10);
	if (pe - ps != 1) {
		pr_err("invalid DLC length, should be 1 digit\n");
		return -1;
	}
	if (frame->can_dlc > 8) {
		pr_err("invalid DLC value %d: should be >=0 and <=8\n", 
			frame->can_dlc);
		return -1;
	}

	/* pe points to the first data byte's whitespace ot terminating 0 */
	ps = pe;
	pe += frame->can_dlc * 3;
	if (pe - buf != len) {
		pr_err("frame definition length does not match DLC value\n");
		return -1;
	}
	for (i = 0; i < frame->can_dlc; i++) {
		if (*ps != ' ') {
			pr_err("a whitespace is expected before DATA byte no %d\n", i);
			return -1;
		}
		ps++;
		frame->data[i] = strtol(ps, &pe, 16);
		if (pe - ps != 2) {
			pr_err("invalid DATA byte length, should be 2 hex digits\n");
			return -1;
		}
		ps = pe;
	}

#ifdef DEBUG
	{
		char str[255];
		sprintf_can_frame(str, frame);
		pr_debug2("FRAME: %s\n", str);
		sprintf_can_frame_def(str, frame);
		pr_debug2("FRAME_DEF: %s\n", str);
	}
#endif
	return 0;
}

static int parse_args(int argc, char *argv[]) 
{
	struct can_frame frame;
	frame_item_t *new_frame;
	int r;
	config_t *cfg = &ctx.cfg;
	
	int opt;
	opterr = 0;
	while ((opt = getopt(argc, argv, "hvs:r:o:d:")) != -1) {
		switch (opt) {
		case 'h':
			return 1; /* exit with 0 */
		case 'v':
			log_level++;
                        break;
		case 's':
			r = parse_can_frame_def(optarg, &frame);
			if (r != 0) {
				return -1;
			}
			cfg->flags.send = 1;
			
			new_frame = malloc(sizeof(*new_frame));
			if (!new_frame) {
				pr_err("not enough memory for new frame\n");
				return -1;
			}
			
			memcpy(&new_frame->frame, &frame, sizeof(new_frame->frame));
			llist_add_tail(&new_frame->list, &cfg->send_frames);
			break;
		case 'r':
			r = atoi(optarg);
			if (r < 0 || r > 2) {
				pr_err("wrong receive mode: %d\n", r);
				return -1;
			}
			cfg->recv_mode = r;
                        break;
		case 'o':
			if (strncmp(optarg, "loopback=", 9) == 0) {
				r = atoi(optarg + 9);
				cfg->flags.set_loopback = 1;
				cfg->loopback = r ? 1 : 0;
			} else if (strncmp(optarg, "recvown=", 8) == 0) {
				r = atoi(optarg + 8);
				cfg->flags.set_recvown = 1;
				cfg->recvown = r ? 1 : 0;
			} else {
				pr_err("unsupported option: '%s'\n", optarg);
				return -1;
			}
                        break;
		case 'd':
			cfg->dev_name = optarg;
                        break;
		case '?':
			pr_err("option '%c' requires an argument\n", optopt);
			return -1;
		default:
			pr_err("unkown option %c\n", optopt);
			return -1; /* exit with error */
		}
	} /* end while getopt */
	
	return 0;
}

static void cleanup()
{
	frame_item_t *frame, *tmp;
	config_t *cfg = &ctx.cfg;
	
	llist_for_each_entry_safe(frame, tmp, &cfg->send_frames, list) {
		llist_del(&frame->list);
#ifdef DEBUG		
		{
			char buf[255];
			sprintf_can_frame_def(buf, &frame->frame);
			pr_debug2("freeing: %s\n", buf);
		}
#endif
		free(frame);
	}
}

static int bind_if(int condition)
{
	config_t *cfg = &ctx.cfg;
	int r;
	
	if (condition && !ctx.flags.bound) {
		/* bind */
		r = bind(ctx.sock, (struct sockaddr *)&ctx.addr, sizeof(ctx.addr));
		if (r < 0) {
			pr_err("failed to bind socket to %s: %s (%d)\n", 
				cfg->dev_name, strerror(errno), errno);
			return -1;
		}
		ctx.flags.bound = 1;
		pr_debug2("socket bound\n");
	}
	return 0;
}

static int send_can_frame(struct can_frame *frame) 
{
	config_t *cfg = &ctx.cfg;
	int r;
	
#ifdef DEBUG
	const char *callname;

	if (cfg->flags.use_sendto) {
		callname = "sendto";
	} else if (cfg->flags.use_write) {
		callname = "write";
	} else {
		callname = "send";
	}
	pr_debug2("sending a frame with '%s()'..\n", callname);
#endif

	r = bind_if(!cfg->flags.use_sendto);
	if (r < 0) {
		return -1;
	}
	
	if (cfg->flags.use_sendto) {
		r = sendto(ctx.sock, frame, sizeof(*frame),
			    0, (struct sockaddr *)&ctx.addr, sizeof(ctx.addr));
	} else if (cfg->flags.use_write) {
		r = write(ctx.sock, frame, sizeof(*frame));
	} else {
		r = send(ctx.sock, frame, sizeof(*frame), 0);
	}
	if (r < 0) {
		pr_err("failed to send a frame: %s (%d)\n", 
			strerror(errno), errno);
		return -1;
	}
	return 0;
}

static int recv_can_frame(struct can_frame *frame) 
{
	config_t *cfg = &ctx.cfg;
	int r;
	struct sockaddr_can addr;
	socklen_t addr_len;
	
#ifdef DEBUG
	const char *callname;

	if (cfg->flags.use_recvfrom) {
		callname = "recvfrom";
	} else if (cfg->flags.use_read) {
		callname = "read";
	} else {
		callname = "recv";
	}
	pr_debug2("receiving a frame with '%s()'..\n", callname);
#endif

	r = bind_if(1);		// recvfrom also needs bound address
	if (r < 0) {
		return -1;
	}

	if (cfg->flags.use_recvfrom) {
		addr_len = sizeof(addr);
		r = recvfrom(ctx.sock, frame, sizeof(*frame), 0, 
				(struct sockaddr *)&addr, &addr_len);
	} else if (cfg->flags.use_read) {
		r = read(ctx.sock, frame, sizeof(*frame));
	} else {
		r = recv(ctx.sock, frame, sizeof(*frame), 0);
	}
	if (r < 0) {
		if (errno == EINTR) {
			pr_debug("receiving interrupted by a signal..\n");
			return -2;
		} else {
			pr_err("failed to receive a frame: %s (%d)\n", 
				strerror(errno), errno);
			return -1;
		}
	}
	return 0;
}


static int send_frames()
{
	int r;
	frame_item_t *frame;
	config_t *cfg = &ctx.cfg;
	char buf[255];

	llist_for_each_entry(frame, &cfg->send_frames, list) {
		
		sprintf_can_frame_def(buf, &frame->frame);
		pr_info("sending a frame: %s\n", buf);
		
		r = send_can_frame(&frame->frame);
		if (r < 0) {
			return -1;
		}
	}
	
	return 0;
}

static int recv_frames()
{
	int r;
	struct can_frame frame;
	config_t *cfg = &ctx.cfg;
	char buf[255];
	
	while (!ctx.flags.sig_int) {
		r = recv_can_frame(&frame);
		if (r < 0) {
			if (r == -2) {
				break;
			}
			return -1;
		}

		sprintf_can_frame_def(buf, &frame);
		pr_info("received: %s\n", buf);
		
		switch (cfg->recv_mode) {
		case 1:
			/* echo the same frame 
			   (actually send to initial address, instead of 
			   using the address got from recvfrom() function)
			 */
			pr_info("echo the same frame: %s\n", buf);
			r = send_can_frame(&frame);
			if (r < 0) {
				return -1;
			}
			break;
		case 2:
			if (frame.can_id & CAN_EFF_FLAG) {
				frame.can_id = ((frame.can_id & CAN_EFF_MASK) + 1) | CAN_EFF_FLAG;
			} else {
				frame.can_id = (frame.can_id & CAN_SFF_MASK) + 1;
			}
			
			sprintf_can_frame_def(buf, &frame);
			pr_info("echo the frame with CAN-ID=CAN-ID+1: %s\n", buf);
			
			r = send_can_frame(&frame);
			if (r < 0) {
				return -1;
			}
			break;
		default:
			break;
		}
	}
	
	return 0;
}

static int can_init()
{
	struct ifreq ifr;
	config_t *cfg = &ctx.cfg;
	int r;

	ctx.sock = socket(PF_CAN, SOCK_RAW, CAN_RAW);
	if (ctx.sock < 0) {
		pr_err("failed to open socket: %s (%d)\n", strerror(errno), errno);
		return -1;
	}
	
	strcpy(ifr.ifr_name, cfg->dev_name);
	r = ioctl(ctx.sock, SIOCGIFINDEX, &ifr);
	if (r < 0) {
		pr_err("failed to get index of %s: %s (%d)\n", cfg->dev_name, 
			strerror(errno), errno);
		return -1;
	}
	
	ctx.addr.can_ifindex = ifr.ifr_ifindex;
	
	/* set sock options */

	if (cfg->flags.set_recvown) {
		r = setsockopt(ctx.sock, SOL_CAN_RAW, CAN_RAW_RECV_OWN_MSGS,
				&cfg->recvown, sizeof(cfg->recvown));
		if (r < 0) {
			pr_err("failed set option CAN_RAW_RECV_OWN_MSGS: %s (%d)\n",
				strerror(errno), errno);
			return -1;
		}
	}
	
	if (cfg->flags.set_loopback) {
		r = setsockopt(ctx.sock, SOL_CAN_RAW, CAN_RAW_LOOPBACK, 
				&cfg->loopback, sizeof(cfg->loopback));
		if (r < 0) {
			pr_err("failed set option CAN_RAW_LOOPBACK: %s (%d)\n",
				strerror(errno), errno);
			return -1;
		}
	}

	return 0;
}

static void can_done()
{
	if (ctx.sock >= 0) {
		close(ctx.sock);
		pr_debug2("socket closed\n");
	}
}

#if 0
static void sig_handler(int signo)
{
	static int counter = 0;
	
	counter++;
	if (counter > 2) {
		pr_err("exiting immediately!");
		exit(1);
	}
	ctx.flags.sig_int = 1;
}
#endif                                                                    

int main(int argc, char *argv[]) 
{
	int r;
	config_t *cfg = &ctx.cfg;

	INIT_LLIST_HEAD(&cfg->send_frames);
	
	r = parse_args(argc, argv);
	
	if (r != 0 || (!cfg->flags.send && cfg->recv_mode < 0)) {
		usage();
		cleanup();
		return r < 0 ? : 0;
	}

	do {
		/* open socket, set options */
		r = can_init();
		if (r < 0) {
			break;
		}
	
		/* first send all frames */
		if (cfg->flags.send) {
			pr_info("sending frames..\n");
			r = send_frames();
			if (r < 0) {
				break;
			}
		}
	
		/* the switch to receive-answer mode */
		if (cfg->recv_mode >= 0) {
#if 0
			if (signal(SIGINT, sig_handler) == SIG_ERR) {
				pr_err("failed to set SIGINT handler\n");
				break;
			}
			if (signal(SIGTERM, sig_handler) == SIG_ERR) {
				pr_err("failed to set SIGTERM handler\n");
				break;
			}
#endif
		
			pr_info("receiving frames..\n");
			r = recv_frames();
			if (r < 0) {
				break;
			}
		}
	} while (0);
	
	can_done();
	
	cleanup();

	return r;
}
