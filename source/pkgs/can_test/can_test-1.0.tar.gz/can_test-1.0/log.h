#ifndef _LOG_H_
#define _LOG_H_

#include "version.h"

#define PFX "[" APP_NAME "]: "

#define LEVEL_INFO	1
#define LEVEL_INFO2	2
#define LEVEL_DEBUG	3
#define LEVEL_DEBUG2	4

extern int log_level;

#define pr_always(fmt, ...) \
	do {\
		printf(PFX fmt, ##__VA_ARGS__);\
	} while(0)

#define pr_err(fmt, ...) \
	do {\
		fprintf(stderr, PFX "Error(%s): " fmt, __func__, ##__VA_ARGS__);\
	} while(0)

#define pr_notice(fmt, ...) \
	do {\
		fprintf(stderr, PFX "Notice: " fmt, ##__VA_ARGS__);\
	} while(0)

#define pr_info(fmt, ...) \
	do {\
		if (log_level >= LEVEL_INFO) {\
			printf(PFX fmt, ##__VA_ARGS__);\
		}\
	} while(0)

#define pr_info2(fmt, ...) \
	do {\
		if (log_level >= LEVEL_INFO2) {\
			printf(PFX fmt, ##__VA_ARGS__);\
		}\
	} while(0)
	
#ifdef DEBUG
#define pr_debug(fmt, ...) \
	do {\
		if (log_level >= LEVEL_DEBUG) {\
			printf(PFX "%s: " fmt, __func__, ##__VA_ARGS__);\
		}\
	} while(0)
#define pr_debug2(fmt, ...) \
	do {\
		if (log_level >= LEVEL_DEBUG2) {\
			printf(PFX "%s: " fmt, __func__, ##__VA_ARGS__);\
		}\
	} while(0)
#else
#define pr_debug(fmt, ...)
#define pr_debug2(fmt, ...)
#endif

#endif /* _LOG_H_ */
